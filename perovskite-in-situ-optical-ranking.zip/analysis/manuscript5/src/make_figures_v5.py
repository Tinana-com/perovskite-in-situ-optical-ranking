"""Manuscript 5 figure updates from verified archived CSVs; no fitting."""
from pathlib import Path
import ast
import json
import os
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR'] = str(ROOT / 'RUN_RECEIPTS/mpl_cache')

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle, FancyArrowPatch, FancyBboxPatch
from PIL import Image
from scipy.stats import spearmanr

BLUE, ORANGE, GRAY = '#0072B2', '#D55E00', '#7C848C'
LIGHT, PALE, SLATE_SUB = '#DDE2E7', '#EAF3F8', 'black'
TEAL = '#009E73'
R1 = ROOT / 'INPUTS/workflow'
PROVENANCE = []
GEOMETRY = []
SEED = 20261019

plt.rcParams.update({
    'font.family': 'Arial', 'font.size': 7.7, 'axes.labelsize': 7.7,
    'xtick.labelsize': 7.0, 'ytick.labelsize': 7.0, 'text.color': 'black',
    'axes.labelcolor': 'black', 'axes.titlecolor': 'black', 'xtick.color': 'black',
    'ytick.color': 'black', 'legend.labelcolor': 'black', 'axes.edgecolor': 'black',
    'axes.linewidth': 0.65, 'axes.spines.top': False, 'axes.spines.right': False,
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.major.size': 2.5, 'ytick.major.size': 2.5,
    'pdf.fonttype': 42, 'svg.fonttype': 'none',
    'svg.hashsalt': 'PL_MANUSCRIPT5_FIGURE_REVISION_20261120',
    'savefig.facecolor': 'white', 'figure.facecolor': 'white',
    'axes.facecolor': 'white', 'axes.unicode_minus': True,
})


def read(name):
    d = pd.read_csv(ROOT / 'INPUTS' / name, float_precision='round_trip', dtype={'split_group': str})
    d['_row'] = np.arange(len(d)) + 2
    d.attrs['source'] = 'INPUTS/' + name
    return d


def read_ext(name):
    d = pd.read_csv(ROOT / 'EVIDENCE/extensions' / name, float_precision='round_trip', dtype={'split_group': str})
    d['_row'] = np.arange(len(d)) + 2
    d.attrs['source'] = 'EVIDENCE/extensions/' + name
    return d


def one(d, **filters):
    q = d
    for k, v in filters.items():
        q = q[q[k] == v]
    assert len(q) == 1, (d.attrs.get('source'), filters, len(q))
    r = q.iloc[0].to_dict()
    r['_source'] = d.attrs['source']
    return r


def save(fig, name, folder='MAIN', close=True):
    out = ROOT / ('FIGURES_MAIN' if folder == 'MAIN' else 'FIGURES_SI' if folder == 'SI' else folder)
    out.mkdir(parents=True, exist_ok=True)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    outside, nonblack = [], []
    ghost_ticks = set()
    for ax in fig.axes:
        for axis in [ax.xaxis, ax.yaxis]:
            lo, hi = sorted(axis.get_view_interval())
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                if tick.get_loc() < lo - 1e-9 or tick.get_loc() > hi + 1e-9:
                    ghost_ticks.update([tick.label1, tick.label2])
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text():
            continue
        if t in ghost_ticks:
            continue
        if matplotlib.colors.to_rgba(t.get_color())[:3] != (0.0, 0.0, 0.0):
            nonblack.append(t.get_text())
        if t.axes is not None and t.get_clip_on():
            continue
        b = t.get_window_extent(renderer)
        if b.x0 < -0.8 or b.y0 < -0.8 or b.x1 > fig.bbox.width + 0.8 or b.y1 > fig.bbox.height + 0.8:
            outside.append(t.get_text())
    GEOMETRY.append({
        'figure': name,
        'width_mm': fig.get_figwidth() * 25.4,
        'height_mm': fig.get_figheight() * 25.4,
        'outside_text': outside,
        'nonblack_text': nonblack,
    })
    for ext in ['pdf', 'svg', 'png']:
        kw = {'dpi': 600}
        if ext == 'pdf':
            kw['metadata'] = {'Title': name, 'Author': 'Yutian Chen', 'CreationDate': None, 'ModDate': None}
        fig.savefig(out / f'{name}.{ext}', **kw)
    fig.savefig(ROOT / 'PREVIEWS' / f'{name}.png', dpi=170)
    if close:
        plt.close(fig)


def panel(ax, letter, context=''):
    ax.text(0, 1.06, f'({letter})', transform=ax.transAxes, weight='bold', fontsize=10, va='bottom', color='black')
    if context:
        ax.text(1, 1.06, context, transform=ax.transAxes, ha='right', va='bottom', fontsize=7.7, color='black')


def grid(ax):
    ax.xaxis.grid(True, color='#E7EAED', lw=0.4)
    ax.set_axisbelow(True)


def dot(ax, x, y, lo, hi, color=BLUE, filled=True, marker='o', size=3.8):
    assert np.isfinite([x, lo, hi]).all() and lo <= x + 1e-10 and hi >= x - 1e-10, (x, lo, hi)
    ax.errorbar(
        x, y, xerr=[[max(0, x - lo)], [max(0, hi - x)]],
        fmt=marker, color=color, mfc=color if filled else 'white',
        mec=color, ms=size, lw=0.85, capsize=1.8, zorder=3,
    )


LEGACY = read('legacy/recomputed_macro_metrics.csv')
CENTERED = read('centered/model_summary.csv')
RAW = read('raw_control/MODEL_SUMMARY.csv')
EXP5 = read('extensions/exp5_controlled_loss_ablation.csv')
ABLATION = read('legacy/D2_ABLATION_MACRO.csv')
POS = read('legacy/V2_position_summary.csv')
BLEND_DELTA = read('centered/paired_deltas_vs_p6.csv')
TARGET_DELTA = read('raw_control/PAIRED_CTR_MINUS_RAW.csv')
PART2 = read('extensions/tabpfn_results_summary_part2.csv')
SIGN_DRIFT = read_ext('exp6_feature_within_unit_sign_drift.csv')
STRAT = read_ext('exp6_conditional_utility_stratified.csv')

LABELS = {}
tree = ast.parse((ROOT / 'src/original_polish_figures.py').read_text(encoding='utf-8'))
for n in tree.body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ['D1_SHORT', 'D2_SHORT']:
        LABELS[n.targets[0].id[:2]] = ast.literal_eval(n.value)
for ds in LABELS:
    LABELS[ds].update({
        'TAB_CTR': 'TabPFN · centered abs.',
        'TAB_FUS': 'BAR-Rank (Optical)',
        'TAB_RAW': 'TabPFN · raw targets',
        'TAB_ID': 'TabPFN · pos. + abs.',
        'TAB_ID_FUS': 'BAR-Rank (Joint)',
    })


def bootstrap(v):
    v = np.asarray(v, dtype=float)
    v = v[np.isfinite(v)]
    b = np.random.default_rng(SEED).choice(v, size=(10000, len(v)), replace=True).mean(axis=1)
    return float(v.mean()), *np.quantile(b, [0.025, 0.975])


def unit_stats(g, score):
    ids = g.sample_id.astype(str).to_numpy()
    s = g[score].to_numpy(float)
    y = g.target.to_numpy(float)
    k = max(1, int(np.ceil(len(g) * 0.25)))
    p = np.lexsort((ids, -s))[:k]
    t = np.lexsort((ids, -y))[:k]
    rho = float(spearmanr(y, s).statistic) if np.unique(y).size > 1 and np.unique(s).size > 1 else np.nan
    return {'gain_pp': float(y[p].mean() - y.mean()), 'rho': rho, 'overlap': len(set(ids[p]) & set(ids[t])) / k}


def prepare_joint():
    allp = read('extensions/tabpfn_predictions_part2.csv')
    p = allp[allp.method_id == 'D2_TABPFN_CTR_IDPL44'].copy()
    assert len(p) == 5857 and p.sample_id.is_unique
    rows, dates = [], []
    for phase, filename in [('development', 'd2_dev_oof_predictions.csv'), ('historical', 'd2_history_predictions.csv')]:
        base = read('extensions/' + filename)
        q = p[p.phase == phase][['sample_id', 'unit_id', 'split_group', 'score']].copy()
        assert set(q.sample_id) == set(base.sample_id)
        q = q.merge(base[['sample_id', 'target', 'PAIR_ABS', 'ID_PAIRWISE']], on='sample_id', validate='one_to_one')
        def z(col):
            return q.groupby('unit_id')[col].transform(lambda v: (v - v.mean()) / max(float(v.std(ddof=0)), 1e-12))
        q['fusion'] = 0.5 * z('score') + 0.5 * z('PAIR_ABS')
        gs = {}
        for mid, col in [('TAB_ID', 'score'), ('TAB_ID_FUS', 'fusion'), ('PAIR_ABS', 'PAIR_ABS'), ('ID_PAIRWISE', 'ID_PAIRWISE')]:
            u = pd.DataFrame([
                {'unit_id': uid, 'split_group': str(g.split_group.iloc[0]), **unit_stats(g, col)}
                for uid, g in q.groupby('unit_id', sort=True)
            ])
            d = u.groupby('split_group', sort=True)[['gain_pp', 'rho', 'overlap']].mean()
            gs[mid] = d
            mean, lo, hi = bootstrap(d.gain_pp)
            rows.append({'phase': phase, 'model': mid, 'gain_pp': mean, 'low': lo, 'high': hi,
                         'rho': d.rho.mean(), 'overlap': d.overlap.mean()})
        for date in gs['TAB_ID_FUS'].index:
            dates.append({
                'phase': phase, 'split_group': date,
                'delta_vs_P6': gs['TAB_ID_FUS'].loc[date, 'gain_pp'] - gs['PAIR_ABS'].loc[date, 'gain_pp'],
                'delta_vs_position': gs['TAB_ID_FUS'].loc[date, 'gain_pp'] - gs['ID_PAIRWISE'].loc[date, 'gain_pp'],
            })
    d = pd.DataFrame(rows)
    e = pd.DataFrame(dates)
    d['_row'] = np.arange(len(d)) + 2
    d.attrs['source'] = 'PLOT_DATA/joint_macro.csv'
    return d, e


JOINT, JOINT_DATES = prepare_joint()


def color(mid):
    return ORANGE if mid in ['ID_PAIRWISE', 'ID_PLUS_PL_PAIRWISE', 'ID_PRIOR', 'TAB_ID', 'TAB_ID_FUS'] or mid.endswith('_IDPL') else GRAY if mid in ['PL_INTENSITY', 'RANDOM_EXPECTATION'] else BLUE


def metric(ds, phase, mid):
    if mid in ['PAIR_ABS', 'ID_PAIRWISE', 'TAB_CTR', 'TAB_FUS']:
        name = {
            'PAIR_ABS': 'P6_PAIR_ABS',
            'ID_PAIRWISE': 'POSITION_PAIRWISE',
            'TAB_CTR': f'{ds}_TABPFN_CTR_ABS12',
            'TAB_FUS': f'{ds}_TABPFN_CTR_ABS12_BLEND50_PAIR_ABS',
        }[mid]
        r = one(CENTERED, dataset=ds, phase=phase, method_id=name)
        r.update(gain=r['top25_gain_pp'], low=r['gain_ci95_low'], high=r['gain_ci95_high'])
    elif mid == 'TAB_RAW':
        r = one(RAW, phase=phase, model='RAW')
        r.update(gain=r['gain_pp'], low=r['gain_ci95_low'], high=r['gain_ci95_high'])
    elif mid in ['TAB_ID', 'TAB_ID_FUS']:
        r = one(JOINT, phase=phase, model=mid)
        r.update(gain=r['gain_pp'], low=r['low'], high=r['high'])
    else:
        q = LEGACY[(LEGACY.dataset == ds) & (LEGACY.phase == phase) & (LEGACY.model_id == mid)]
        if len(q) == 1:
            r = one(LEGACY, dataset=ds, phase=phase, model_id=mid)
            r.update(gain=r['top25_gain_pp'], low=r['original_gain_CI_low'], high=r['original_gain_CI_high'])
        else:
            table = read(f'legacy/{ds.lower()}_macro_model_comparison.csv')
            scope = ('D1_DEVELOPMENT_PREVIOUSLY_ACCESSED' if phase == 'development' else 'D1_AUTHOR_TEST_PREVIOUSLY_INSPECTED') if ds == 'D1' else ('D2_DEVELOPMENT_REUSED_DATES' if phase == 'development' else 'D2_HISTORY_PREVIOUSLY_INSPECTED')
            r = one(table, scope=scope, model_id=mid)
            r.update(gain=r['top25_gain_pp'], low=r['top25_gain_pp_ci95_low'], high=r['top25_gain_pp_ci95_high'])
    r.update(dataset=ds, phase=phase, model_id=mid)
    return r


def add_cohort_and_shape_legend(fig, anchor_y=0.992):
    handles = [
        Line2D([], [], ls='', marker='o', color='black', ms=4.2, label='Development'),
        Line2D([], [], ls='', marker='o', color='black', mfc='white', ms=4.2, label='History (previously viewed)'),
        Line2D([], [], ls='', marker='^', color='black', ms=4.2, label='TabPFN'),
        Line2D([], [], ls='', marker='D', color='black', ms=4.0, label='BAR-Rank (50/50 fusion)'),
    ]
    fig.legend(
        handles=handles, loc='upper center', bbox_to_anchor=(0.56, anchor_y),
        ncol=4, frameon=False, fontsize=7.2, columnspacing=1.2, handletextpad=0.35,
    )


def figure2():
    fig = plt.figure(figsize=(178 / 25.4, 134 / 25.4))
    axes = [fig.add_axes([0.245, 0.12, 0.235, 0.72]), fig.add_axes([0.755, 0.12, 0.235, 0.72])]
    ids = ['PAIR_ABS', 'TAB_CTR', 'TAB_FUS', 'PL_PAIRWISE', 'LGBM_PL', 'EXTRATREES_PL',
           'HISTGB_PL', 'RIDGE_PL', 'AUX', 'ID_PLUS_PL_PAIRWISE', 'ID_PAIRWISE', 'PL_INTENSITY']
    for ax, ds, letter in zip(axes, ['D1', 'D2'], 'ab'):
        mids = [('AUTHOR_KNN_AUX' if ds == 'D1' else 'F2_RIDGE_AUX') if x == 'AUX' else x for x in ids]
        ax.axhspan(-0.45, 2.45, color='#F0F6FA', zorder=0)
        for j, mid in enumerate(mids):
            for phase, offset in [('development', -0.12), ('historical', 0.12)]:
                r = metric(ds, phase, mid)
                marker = 'D' if mid == 'TAB_FUS' else '^' if mid == 'TAB_CTR' else 'o'
                dot(ax, r['gain'], j + offset, r['low'], r['high'], color(mid), phase == 'development',
                    marker, 4.1 if mid == 'TAB_FUS' else 3.5)
        ax.set_yticks(range(len(mids)), [LABELS[ds][m] for m in mids], fontsize=7.0)
        ax.set_ylim(len(mids) - 0.5, -0.65)
        ax.tick_params(axis='y', length=0, pad=4)
        ax.set_xlim((-0.25, 1.85) if ds == 'D1' else (-1.7, 2.15))
        ax.set_xlabel('Top25% PCE gain (pp)')
        ax.axvline(0, color=GRAY, ls='--', lw=0.6)
        grid(ax)
        panel(ax, letter, ds)
    add_cohort_and_shape_legend(fig, anchor_y=0.988)
    save(fig, 'Figure2')


def figure3():
    fig, axs = plt.subplots(2, 2, figsize=(178 / 25.4, 146 / 25.4))
    fig.subplots_adjust(left=0.255, right=0.98, bottom=0.10, top=0.90, wspace=0.92, hspace=0.58)

    # Panel (a): Matched pairwise increments AND verified D2 joint TabPFN fusion over position
    ax = axs[0, 0]
    for j, (ds, ph) in enumerate([('D1', 'development'), ('D1', 'historical'), ('D2', 'development'), ('D2', 'historical')]):
        r = one(POS, dataset=ds, phase=ph)
        dot(ax, r['delta'], j, r['low'], r['high'], BLUE if r['delta'] >= 0 else ORANGE, ph == 'development', 'o', 3.6)
    # Add D2 Position + abs. optical TabPFN fusion − Position-only (Part 2 verified)
    for j, ph in [(4, 'development'), (5, 'historical')]:
        r = one(PART2, dataset='D2', method_id='D2_TABPFN_CTR_IDPL44_BLEND50_PAIR_ABS', phase=ph)
        val = r['delta_vs_ID_PAIRWISE']
        dot(ax, val, j, r['delta_vs_ID_ci_lo'], r['delta_vs_ID_ci_hi'],
            BLUE if val >= 0 else ORANGE, ph == 'development', 'D', 4.0)
    ax.axhline(3.5, color='#D0D5DC', lw=0.55, ls=':')
    ax.set_yticks(range(6), [
        'D1 dev · matched pair.',
        'D1 hist · matched pair.',
        'D2 dev · matched pair.',
        'D2 hist · matched pair.',
        'D2 dev · BAR-Rank (Joint)',
        'D2 hist · BAR-Rank (Joint)',
    ], fontsize=6.7)
    ax.set_ylim(5.55, -0.55)
    ax.set_xlim(-0.85, 0.85)
    ax.set_xticks([-0.8, -0.4, 0, 0.4, 0.8])
    ax.set_xlabel('Position + optical − position (pp)', fontsize=7.2)
    ax.axvline(0, color=GRAY, ls='--', lw=0.6)
    grid(ax)
    panel(ax, 'a')

    # Panel (b): Exp 5 controlled linear objective decomposition
    ax = axs[0, 1]
    labels_b = []
    for j, (ds, name, contrast) in enumerate([
        ('D1', 'ctr. − raw Ridge', 'CENTERED_RIDGE_MINUS_RAW_RIDGE'),
        ('D1', 'pair. − ctr. Ridge', 'PAIRWISE_TOL05_MINUS_CENTERED_RIDGE'),
        ('D2', 'ctr. − raw Ridge', 'CENTERED_RIDGE_MINUS_RAW_RIDGE'),
        ('D2', 'pair. − ctr. Ridge', 'PAIRWISE_TOL05_MINUS_CENTERED_RIDGE'),
    ]):
        r = one(EXP5, dataset=ds, feature_set='ABS_12F', reg_mode='INNER_CV_TUNED',
                phase='development', objective='CONTRAST_' + contrast)
        dot(ax, r['top25_gain_pp'], j, r['gain_ci95_low'], r['gain_ci95_high'], BLUE, True, 'o', 3.6)
        labels_b.append(ds + ' · ' + name)
    ax.set_yticks(range(4), labels_b, fontsize=6.8)
    ax.set_ylim(3.5, -0.5)
    ax.axvline(0, color=GRAY, ls='--', lw=0.6)
    ax.set_xlim(-0.1, 0.85)
    ax.set_xlabel('Controlled PCE gain increment (pp)', fontsize=7.2)
    grid(ax)
    panel(ax, 'b')

    # Panel (c): TabPFN target centering & optical-only fusion vs P6
    ax = axs[1, 0]
    r = one(TARGET_DELTA, phase='development', metric='gain_pp')
    dot(ax, r['mean_delta'], 0, r['ci95_low'], r['ci95_high'], BLUE, True, '^', 3.9)
    for j, ds in enumerate(['D1', 'D2'], 1):
        r = one(BLEND_DELTA, dataset=ds, phase='development', method_id=f'{ds}_TABPFN_CTR_ABS12_BLEND50_PAIR_ABS')
        dot(ax, r['mean_delta'], j, r['ci95_low'], r['ci95_high'], BLUE, True, 'D', 4.0)
    ax.set_yticks(range(3), ['D2 · CTR − RAW TabPFN', 'D1 · BAR-Rank − pair.', 'D2 · BAR-Rank − pair.'], fontsize=6.8)
    ax.set_ylim(2.55, -0.55)
    ax.set_xlim(-0.12, 0.64)
    ax.set_xticks([-0.1, 0, 0.2, 0.4, 0.6])
    ax.axvline(0, color=GRAY, ls='--', lw=0.6)
    ax.set_xlabel('Paired PCE gain increment (pp)', fontsize=7.2)
    grid(ax)
    panel(ax, 'c')

    # Panel (d): D2 temporal slope vs static levels
    ax = axs[1, 1]
    for j, v in enumerate(['FULL4', 'LEVEL8', 'SLOPE4']):
        r = one(ABLATION, scope='D2_DEVELOPMENT_REUSED_DATES', input_mode='OPTICAL_ONLY_REL', variant=v)
        dot(ax, r['gain_pp'], j, r['gain_pp_ci_low'], r['gain_pp_ci_high'], BLUE, True, 'o', 3.6)
    ax.set_yticks(range(3), ['All statistics (12)', 'Intensity level (8)', 'Temporal slope (4)'], fontsize=6.8)
    full = one(ABLATION, scope='D2_DEVELOPMENT_REUSED_DATES', input_mode='OPTICAL_ONLY_REL', variant='FULL4')['gain_pp']
    ax.axvline(full, color=GRAY, ls='--', lw=0.6)
    ax.set_ylim(2.55, -0.55)
    ax.set_xlim(0.1, 1.17)
    ax.set_xlabel('D2 Top25% PCE gain (pp)', fontsize=7.2)
    grid(ax)
    panel(ax, 'd')

    fig.legend(
        handles=[
            Line2D([], [], ls='', marker='o', color='black', ms=3.8, label='Development'),
            Line2D([], [], ls='', marker='o', color='black', mfc='white', ms=3.8, label='History (previously viewed)'),
            Line2D([], [], ls='', marker='^', color='black', ms=4.0, label='TabPFN'),
            Line2D([], [], ls='', marker='D', color='black', ms=3.9, label='BAR-Rank (50/50 fusion)'),
        ],
        loc='upper center', bbox_to_anchor=(0.56, 0.985), ncol=4, frameon=False, fontsize=7.0,
    )
    save(fig, 'Figure3')


def figure_s2():
    fig = plt.figure(figsize=(178 / 25.4, 210 / 25.4))
    axes = [
        fig.add_axes([0.285, 0.565, 0.20, 0.335]),
        fig.add_axes([0.78, 0.565, 0.20, 0.335]),
        fig.add_axes([0.285, 0.085, 0.20, 0.335]),
        fig.add_axes([0.78, 0.085, 0.20, 0.335]),
    ]
    for ax, (ds, phase), letter in zip(axes, [('D1', 'development'), ('D1', 'historical'), ('D2', 'development'), ('D2', 'historical')], 'abcd'):
        original = read(f'legacy/{ds.lower()}_macro_model_comparison.csv')
        scope = 'D1_DEVELOPMENT_PREVIOUSLY_ACCESSED' if ds == 'D1' and phase == 'development' else 'D1_AUTHOR_TEST_PREVIOUSLY_INSPECTED' if ds == 'D1' else 'D2_DEVELOPMENT_REUSED_DATES' if phase == 'development' else 'D2_HISTORY_PREVIOUSLY_INSPECTED'
        mids = original[original.scope == scope].model_id.sort_values().tolist()
        mids = ['PAIR_ABS', 'TAB_CTR', 'TAB_FUS'] + [m for m in mids if m != 'PAIR_ABS']
        if ds == 'D2':
            mids.insert(1, 'TAB_RAW')
            mids += ['TAB_ID', 'TAB_ID_FUS']
        for j, mid in enumerate(mids):
            r = metric(ds, phase, mid)
            dot(ax, r['gain'], j, r['low'], r['high'], color(mid), phase == 'development',
                'D' if mid in ['TAB_FUS', 'TAB_ID_FUS'] else '^' if mid in ['TAB_CTR', 'TAB_ID'] else 'o', 2.9)
        ax.set_yticks(range(len(mids)), [LABELS[ds][m] for m in mids], fontsize=6.6)
        ax.tick_params(axis='y', length=0, pad=4)
        ax.set_ylim(len(mids) - 0.55, -0.7)
        ax.set_xlim((-0.4, 1.95) if ds == 'D1' else (-1.7, 2.15))
        ax.axvline(0, color=GRAY, ls='--', lw=0.55)
        ax.set_xlabel('Top25% PCE gain (pp)', fontsize=7.4)
        grid(ax)
        panel(ax, letter, ds + ' ' + ('development' if phase == 'development' else 'history'))
    add_cohort_and_shape_legend(fig, anchor_y=0.985)
    save(fig, 'FigureS2', 'SI')


def figure_s11():
    """D2 channel-wise within-unit sign drift (Exp 6) & post-hoc position stratification."""
    fig, (ax_l, ax_r) = plt.subplots(1, 2, figsize=(178 / 25.4, 98 / 25.4))
    fig.subplots_adjust(left=0.145, right=0.98, top=0.81, bottom=0.14, wspace=0.45)

    # Panel (a): 12 D2 features dev vs hist mean within-unit rho
    d2 = SIGN_DRIFT[SIGN_DRIFT.dataset == 'D2'].copy()
    order = [
        'LP725_mean', 'LP725_last', 'LP725_slope',
        'LP780_mean', 'LP780_last', 'LP780_slope',
        'SP775_mean', 'SP775_last', 'SP775_slope',
        'ND_mean', 'ND_last', 'ND_slope',
    ]
    d2 = d2.set_index('feature').loc[order].reset_index()
    y_pos = np.arange(len(d2))
    h = 0.34
    ax_l.barh(y_pos - h / 2, d2.dev_mean_within_unit_rho, height=h, color=BLUE, edgecolor=BLUE, lw=0.6, label='Development (14 dates)')
    ax_l.barh(y_pos + h / 2, d2.hist_mean_within_unit_rho, height=h, color='white', edgecolor=ORANGE, lw=0.9, label='History (3 dates)')
    ax_l.axvline(0, color='black', lw=0.7)
    for sep in [2.5, 5.5, 8.5]:
        ax_l.axhline(sep, color='#E2E6EC', lw=0.5)
    ax_l.set_yticks(y_pos, order, fontsize=6.7)
    ax_l.set_ylim(len(d2) - 0.4, -0.6)
    ax_l.set_xlim(-0.56, 0.24)
    ax_l.set_xlabel('Mean within-experiment Spearman rho', fontsize=7.3)
    grid(ax_l)
    panel(ax_l, 'a', 'D2 optical channels')
    ax_l.legend(loc='lower left', bbox_to_anchor=(0.0, 1.13), ncol=2, frameon=False, fontsize=6.6, columnspacing=0.9)

    # Panel (b): D2 post-hoc stratification by position performance (measured PCE conditioned)
    strata = [
        ('POS_WEAK_OR_FAIL (ID_gain<=0)', 'Pos. gain <= 0\n(n=31)'),
        ('POS_BOTTOM_HALF (ID_gain<median)', 'Pos. bottom half\n(n=79)'),
        ('ALL_UNITS', 'All units\n(n=158)'),
        ('POS_TOP_HALF (ID_gain>=median)', 'Pos. top half\n(n=79)'),
    ]
    s_df = STRAT[(STRAT.dataset == 'D2') & (STRAT.phase == 'development')].set_index('stratum')
    x = np.arange(len(strata))
    w = 0.34
    id_vals = [s_df.loc[k, 'mean_gain_ID'] for k, _ in strata]
    opt_vals = [s_df.loc[k, 'mean_gain_PAIR_ABS'] for k, _ in strata]
    ax_r.bar(x - w / 2, id_vals, width=w, color=ORANGE, edgecolor=ORANGE, lw=0.6, label='Position-only')
    ax_r.bar(x + w / 2, opt_vals, width=w, color=BLUE, edgecolor=BLUE, lw=0.6, label='Absolute optical')
    ax_r.axhline(0, color='black', lw=0.7)
    ax_r.set_xticks(x, [lbl for _, lbl in strata], fontsize=6.7)
    ax_r.set_ylim(-0.72, 1.55)
    ax_r.set_ylabel('Mean Top25% PCE gain (pp)', fontsize=7.3)
    ax_r.yaxis.grid(True, color='#E7EAED', lw=0.4)
    ax_r.set_axisbelow(True)
    panel(ax_r, 'b', 'D2 dev · post hoc strata')
    ax_r.legend(loc='lower left', bbox_to_anchor=(0.0, 1.13), ncol=2, frameon=False, fontsize=6.6, columnspacing=0.9)

    save(fig, 'FigureS11', 'SI')


def graphical_abstract():
    fig = plt.figure(figsize=(200 / 25.4, 92 / 25.4))
    a = fig.add_axes([0, 0, 1, 1])
    a.set(xlim=(0, 200), ylim=(92, 0))
    a.axis('off')
    a.text(100, 3, 'Regional performance ranking from in situ optical monitoring',
           ha='center', va='top', fontsize=10.8, weight='bold', color='black')
    for x, c, fill, title in [
        (2, BLUE, '#E6F2FB', '1  Optical monitoring'),
        (69, '#9478B2', '#EEE6F6', '2  Group-isolated analysis'),
        (136, '#BC9D79', '#FFF0DF', '3  D2 selection evidence'),
    ]:
        a.add_patch(FancyBboxPatch((x, 13), 62, 77, boxstyle='round,pad=0,rounding_size=1.4',
                                   fc=fill, ec=c, lw=0.8, zorder=0))
        a.text(x + 31, 16, title, ha='center', va='top', fontsize=8.5, weight='bold', color='black')

    im = Image.open(R1 / 'Optical_Acquisition_Selected.png')
    a.imshow(im, extent=(6, 60, 56, 23), aspect='auto', zorder=1)
    a.text(33, 59, 'D1: LP725 PL', ha='center', va='top', fontsize=7.4, color='black')
    a.text(33, 65, 'D2: PL + reflection', ha='center', va='top', fontsize=7.4, color='black')
    for j, label in enumerate(['LP725', 'LP780', 'SP775', 'ND']):
        x = 7 + j * 13
        a.add_patch(Rectangle((x, 72), 12, 6, fc='#E6F2FB', ec=BLUE, lw=0.7, zorder=2))
        a.text(x + 6, 74, label, ha='center', va='top', fontsize=6.4, color='black')
    a.text(33, 83, '5,487 development regions', ha='center', va='top', fontsize=7.3, color='black')
    for x in [64.6, 131.6]:
        a.add_patch(FancyArrowPatch((x, 49), (x + 3.8, 49), arrowstyle='-|>',
                                    mutation_scale=6, color=BLUE, lw=0.7, shrinkA=0, shrinkB=0))

    internal_border = '#9478B2'
    def box(x, y, w, h):
        a.add_patch(Rectangle((x, y), w, h, fc='#EEE6F6', ec=internal_border, lw=0.75, zorder=2))
    def line(points):
        a.plot(*zip(*points), color=internal_border, lw=0.7, solid_capstyle='butt', zorder=3)
    def arrow(x, y0, y1):
        a.add_patch(FancyArrowPatch((x, y0), (x, y1), arrowstyle='-|>', mutation_scale=6,
                                    color=internal_border, lw=0.7, shrinkA=0, shrinkB=0, zorder=3))

    box(77, 25, 46, 11)
    for row in range(2):
        for col in range(3):
            a.add_patch(Rectangle((80 + col * 2.6, 27.7 + row * 2.7), 1.9, 1.9,
                                  fc='white', ec=internal_border, lw=0.5, zorder=3))
    a.text(105, 30.5, 'Optical descriptors', ha='center', va='center', fontsize=7.3, color='black')
    line([(100, 36), (100, 40), (86, 40)])
    line([(100, 40), (117, 40)])
    arrow(86, 40, 44)
    arrow(117, 40, 44)
    for x in [74, 105]:
        box(x, 44, 24, 18)
    for x, label in [(79, 'i'), (88.2, 'j')]:
        a.add_patch(Rectangle((x, 47), 4.8, 4.8, fc='white', ec=internal_border, lw=0.6, zorder=3))
        a.text(x + 2.4, 49.4, label, ha='center', va='center', fontsize=6.3, color='black', zorder=4)
    a.text(86, 49.4, '>', ha='center', va='center', fontsize=7.8, color='black', zorder=4)
    for row in range(2):
        for col in range(3):
            a.add_patch(Rectangle((113 + col * 2.8, 46.5 + row * 2.6), 2.1, 1.8,
                                  fc='white', ec=internal_border, lw=0.5, zorder=3))
    a.text(86, 56, 'Pairwise ranker', ha='center', va='center', fontsize=7, color='black')
    a.text(117, 54.5, 'TabPFN', ha='center', va='center', fontsize=7, color='black')
    a.text(117, 59, 'Centered targets', ha='center', va='center', fontsize=6.1, color='black')
    for center in [86, 117]:
        line([(center, 62), (center, 74), (100, 74)])
    a.text(101.5, 70.5, 'Score z-scaling', ha='center', va='center', fontsize=7.1, color='black')
    arrow(100, 74, 80)
    box(76, 80, 48, 7)
    a.text(100, 83.5, 'BAR-Rank · 50/50 fusion', ha='center', va='center', fontsize=7.0, color='black')

    for j, w in enumerate([11, 8, 5]):
        a.add_patch(Rectangle((159, 25 + j * 1.9), w, 1.2, fc=BLUE if j < 2 else GRAY, ec='none'))
    a.text(173, 26, 'Top25%', fontsize=7.1, va='center', color='black')
    a.add_patch(Rectangle((138.5, 32), 57.5, 47, fc='white', ec='#CCD2D8', lw=0.55, zorder=1))
    ax = fig.add_axes([0.800, 0.25, 0.170, 0.39])
    ax.set_facecolor('white')
    for j, mid in enumerate(['TAB_RAW', 'TAB_CTR', 'PAIR_ABS', 'TAB_FUS']):
        r = metric('D2', 'development', mid)
        c = ORANGE if mid == 'TAB_FUS' else BLUE
        dot(ax, r['gain'], j, r['low'], r['high'], c, True, 'D' if mid == 'TAB_FUS' else 'o', 4.0)
        ax.text(r['high'] + 0.04, j, f"{r['gain']:.3f}", va='center', ha='left', fontsize=6.3, color='black',
                weight='bold' if mid == 'TAB_FUS' else 'normal')
    ax.set_yticks(range(4), ['Raw targets', 'Centered targets', 'Pairwise ranker', 'BAR-Rank (Opt.)'], fontsize=6.9)
    ax.set_ylim(3.6, -0.6)
    ax.set_xlim(0, 1.54)
    ax.set_xticks([0, 0.5, 1.0])
    ax.set_xlabel('Top25% PCE gain (pp)', fontsize=7.2)
    ax.xaxis.grid(True, color='#D2D7DD', lw=0.55)
    ax.set_axisbelow(True)
    ax.tick_params(axis='x', labelsize=7.0)
    ax.tick_params(axis='y', length=0, pad=3)
    a.text(167, 83, '14 dates · optical-only (Joint: 0.951 pp)', ha='center', va='top', fontsize=6.5, color='black')
    save(fig, 'Graphical_Abstract', 'FIGURES_MAIN')


def figure1():
    source = (ROOT / 'src/original_polish_figures.py').read_text(encoding='utf-8')
    tree = ast.parse(source)
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'draw_figure1_r2')
    code = ast.get_source_segment(source, fn)
    code = code.replace("R1 / 'sources/", "R1 / '")
    start = code.index('    # Stage 3\n')
    end = code.index('    # Stage 4:', start)
    replacement = '''    # Parallel predictors; target centering belongs only to the TabPFN branch.
    txt(91.7, 20.0, 'Parallel predictors', 6.4, 'bold', ha='center')
    rct(80, 27, 11.5, 12, BLUE, '#EEE6F6', .7)
    rct(93, 27, 11.5, 12, BLUE, '#EEE6F6', .7)
    txt(85.75, 29.4, 'Pairwise\\nranker', 5.8, ha='center')
    txt(98.75, 28.5, 'TabPFN', 5.8, ha='center')
    txt(98.75, 32.6, 'Centered\\ntargets', 5.8, ha='center')
    ln([(77,45),(78.3,45),(78.3,24),(98.75,24)], BLUE, .65)
    arw((85.75,24),(85.75,27),BLUE,.65,ms=5)
    arw((98.75,24),(98.75,27),BLUE,.65,ms=5)
    ln([(85.75,39),(85.75,43),(98.75,43),(98.75,39)], BLUE, .65)
    arw((92,43),(92,48),BLUE,.7,ms=5)
    rct(80.8,48,22,7.0,BLUE,'#EEE6F6',.7)
    txt(91.8,50,'BAR-Rank fusion',6.2,ha='center')
    arw((92,55),(92,59.3),BLUE,.7,ms=5)
    for i,f in enumerate([1.,.77,.55,.32]):
        rct(81.5,61+i*3.1,20*f,1.8,c=BLUE if i<2 else GRAY,
            fill=BLUE if i<2 else '#C8CDD2',lw=0)
    txt(91.7,75.2,'Within-group order',6.2,ha='center')
    ln([(103,66),(108,66),(108,45)],BLUE,.8)
    arw((108,45),(111,45),BLUE,.95)

'''
    code = code[:start] + replacement + code[end:]
    code = code.replace("'Top-decile recall'", "'Champion regret'")
    code = code.replace(
        "    MAIN_DIR.mkdir(parents=True, exist_ok=True)\n    for ext in ['svg', 'pdf', 'png']:\n        fig.savefig(MAIN_DIR / f'Figure1_Final.{ext}', dpi=600)\n    plt.close(fig)",
        "    save(fig, 'Figure1')",
    )
    ns = globals().copy()
    exec(code, ns)
    ns['draw_figure1_r2']()
    plt.rcParams.update({'font.size': 7.7, 'axes.labelsize': 7.7, 'xtick.labelsize': 7.0, 'ytick.labelsize': 7.0})


def figure_s10():
    fig = plt.figure(figsize=(178 / 25.4, 98 / 25.4))
    left = fig.add_axes([0.235, 0.24, 0.24, 0.54])
    right = fig.add_axes([0.59, 0.24, 0.39, 0.54])
    mids = ['PAIR_ABS', 'ID_PAIRWISE', 'TAB_ID', 'TAB_ID_FUS']
    for j, mid in enumerate(mids):
        for phase, offset in [('development', -0.12), ('historical', 0.12)]:
            r = metric('D2', phase, mid)
            dot(left, r['gain'], j + offset, r['low'], r['high'], color(mid), phase == 'development',
                'D' if mid == 'TAB_ID_FUS' else '^' if mid == 'TAB_ID' else 'o')
    left.set_yticks(range(4), ['Absolute ranker', 'Position ranker', 'TabPFN · pos. + abs.', 'BAR-Rank (Joint)'])
    left.tick_params(axis='y', length=0, pad=4)
    left.set_ylim(3.5, -0.5)
    left.set_xlim(0.1, 2.35)
    left.set_xlabel('Top25% PCE gain (pp)')
    grid(left)
    panel(left, 'a')
    d = JOINT_DATES.copy()
    x = np.arange(len(d))
    bars = right.bar(x, d.delta_vs_P6, width=0.72, color=ORANGE, edgecolor=ORANGE, lw=0.8)
    for i, b in enumerate(bars):
        if d.phase.iloc[i] == 'historical':
            b.set_facecolor('white')
    right.axhline(0, color='black', lw=0.6)
    right.axvline(13.5, color=GRAY, ls=':', lw=0.6)
    right.set_xticks(x, [s[4:6] + '/' + s[6:] for s in d.split_group], rotation=65, ha='right', fontsize=6.6)
    right.set_ylabel('BAR-Rank (Joint) − abs. ranker (pp)')
    right.yaxis.grid(True, color='#E7EAED', lw=0.4)
    right.set_axisbelow(True)
    panel(right, 'b')
    add_cohort_and_shape_legend(fig, anchor_y=0.99)
    save(fig, 'FigureS10', 'SI')


def main():
    for fn in [figure1, figure2, figure3, figure_s2, figure_s10, figure_s11, graphical_abstract]:
        fn()
    for ext in ['png', 'svg', 'pdf']:
        (ROOT / f'Graphical_Abstract.{ext}').write_bytes((ROOT / 'FIGURES_MAIN' / f'Graphical_Abstract.{ext}').read_bytes())
    (ROOT / 'RUN_RECEIPTS/geometry_v5.json').write_text(json.dumps(GEOMETRY, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps([{'figure': x['figure'], 'outside': x['outside_text'], 'nonblack': x['nonblack_text']} for x in GEOMETRY], indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
