"""Manuscript2 figures from supplied frozen CSVs. No model fitting."""
from pathlib import Path
import importlib.util, json, string, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, Ellipse, FancyArrowPatch, FancyBboxPatch
from matplotlib.lines import Line2D
from matplotlib.colors import ListedColormap

B=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('screen',B/'DATA/SUP/OUTPUT/source_code/make_figures.py')
S=importlib.util.module_from_spec(spec);spec.loader.exec_module(S)
S.ROOT=B;S.OUT=B/'FIGURES';S.DATA=B/'DATA/SUP/INPUT/DATA/CODEX'
BLUE,ORANGE,GRAY,GREEN=S.BLUE,S.ORANGE,S.GRAY,'#009E73'
S.style();plt.rcParams.update({'font.size':8.,'axes.labelsize':8.,'xtick.labelsize':7.2,'ytick.labelsize':7.2})
PROV=[]
NAMES={'PAIR_ABS':'Absolute optical ranker','PL_PAIRWISE':'Reference optical ranker',
 'ID_PLUS_PL_PAIRWISE':'Position + optical ranker','ID_PAIRWISE':'Position-only ranker',
 'ID_PRIOR':'Shrunk position prior','LGBM_PL':'LambdaRank · optical','LGBM_IDPL':'LambdaRank + position',
 'EXTRATREES_PL':'ExtraTrees · optical','EXTRATREES_IDPL':'ExtraTrees + position',
 'HISTGB_PL':'Histogram boosting · optical','HISTGB_IDPL':'Histogram boosting + position',
 'RIDGE_PL':'Ridge · reference optical','RIDGE_IDPL':'Ridge + position',
 'AUTHOR_KNN_AUX':'Published-source kNN','F2_RIDGE_AUX':'Ridge · absolute optical',
 'PL_INTENSITY':'Single-intensity rule','RANDOM_EXPECTATION':'Random expectation',
 'PAIR_DYNAMIC':'Ranker · dynamic summaries','PAIR_LEVEL':'Ranker · intensity levels',
 'PAIR_REL':'Ranker · relative features','PAIR_BOTH':'Ranker · combined features',
 'PAIR_EARLY25':'Ranker · first-quarter frames','PAIR_LATE25':'Ranker · last-quarter frames'}
SHORT={**NAMES,'PAIR_ABS':'Ranker · absolute','PL_PAIRWISE':'Ranker · reference',
 'ID_PLUS_PL_PAIRWISE':'Ranker · position + optical','ID_PAIRWISE':'Ranker · position',
 'HISTGB_PL':'Histogram boosting','HISTGB_IDPL':'Histogram + position','EXTRATREES_PL':'ExtraTrees',
 'LGBM_PL':'LambdaRank','PAIR_DYNAMIC':'Ranker · dynamic','PAIR_LEVEL':'Ranker · levels',
 'PAIR_REL':'Ranker · relative','PAIR_BOTH':'Ranker · combined','PAIR_EARLY25':'Ranker · first 25% frames',
 'PAIR_LATE25':'Ranker · last 25% frames','RIDGE_PL':'Ridge · reference','F2_RIDGE_AUX':'Ridge · absolute'}

def read(path,**kw):
 p=B/path;d=pd.read_csv(p,float_precision='round_trip',**kw);d['_row']=np.arange(len(d))+2;d.attrs['source']=path;return d
def code(name,**kw):return read('DATA/CODE/ANALYSIS/'+name,**kw)
def sup(name,**kw):return read('DATA/SUP/INPUT/DATA/CODEX/'+name,**kw)
def record(d,fig,panel,cols):
 for _,r in d.iterrows():
  for col in cols:
   if col in r and pd.notna(r[col]):
    PROV.append({'figure':fig,'panel':panel,'source_csv':d.attrs['source'],'source_row':int(r['_row']),
                 'dataset':r.get('dataset','D1'),'cohort':r.get('phase',r.get('scope','development')),
                 'metric':col,'value':r[col],'model_source_id':r.get('model_id',''),
                 'sample_or_group':r.get('sample_id',r.get('split_group',''))})
def save(fig,name,folder='MAIN'):
 S.save(fig,name,folder)
def label(a,l,txt=None):
 S.letter(a,l)
 if txt:a.text(1,1.065,txt,transform=a.transAxes,ha='right',va='bottom',fontsize=8.)
def grid(a):a.xaxis.grid(True,color='#E7EAED',lw=.4);a.set_axisbelow(True)
def color(mid):return ORANGE if mid in ['ID_PAIRWISE','ID_PLUS_PL_PAIRWISE','ID_PRIOR'] or mid.endswith('_IDPL') else GRAY if mid in ['PL_INTENSITY','RANDOM_EXPECTATION'] else BLUE
def arrow(ax,xy,xy2,c=GRAY,style='-|>',lw=.9):
 ax.add_patch(FancyArrowPatch(xy,xy2,arrowstyle=style,mutation_scale=8,linewidth=lw,color=c))

def figure1():
 fig=plt.figure(figsize=(178/25.4,124/25.4));a=fig.add_axes([.025,.025,.95,.95]);a.set(xlim=(0,1),ylim=(0,1));a.axis('off')
 a.text(.01,.98,'(a)',fontweight='bold',fontsize=10.5,va='top');a.text(.52,.98,'(b)',fontweight='bold',fontsize=10.5,va='top')
 a.text(.065,.947,'D1 · LP725 photoluminescence',fontsize=8.6,fontweight='bold')
 a.text(.575,.947,'D2 · Photoluminescence + reflection',fontsize=8.6,fontweight='bold')
 # Original vector blade, wet film and measurement icons. Spatial shapes are schematic.
 def film(x,y,w=.24):
  a.add_patch(Polygon([(x,y),(x+w,y),(x+w+.035,y+.075),(x+.035,y+.075)],facecolor='#F1F4F6',edgecolor=GRAY,lw=.7))
  a.add_patch(Polygon([(x+.012,y+.015),(x+w-.012,y+.015),(x+w+.016,y+.061),(x+.041,y+.061)],facecolor='#DCECF5',edgecolor=BLUE,lw=.55))
  a.plot([x+.01,x+w-.02],[y+.08,y+.08],color=GRAY,lw=2.4)
  a.add_patch(Ellipse((x+.11,y+.074),.10,.018,facecolor='#0072B2',edgecolor='none',alpha=.35))
  arrow(a,(x-.018,y+.092),(x+.055,y+.092),GRAY)
  for dx in [.055,.12,.185]:
   a.add_patch(Polygon([(x+dx-.018,y+.024),(x+dx+.022,y+.024),(x+dx+.033,y+.045),(x+dx-.007,y+.045)],facecolor='white',edgecolor=BLUE,lw=.6))
 def camera(x,y):
  a.add_patch(FancyBboxPatch((x-.031,y),.062,.035,boxstyle='round,pad=.001,rounding_size=.004',facecolor='white',edgecolor=GRAY,lw=.8))
  a.add_patch(Ellipse((x,y-.003),.025,.013,facecolor='#DCECF5',edgecolor=GRAY,lw=.7))
  a.plot([x-.009,x-.035],[y-.013,y-.070],color=BLUE,lw=.6,alpha=.7)
  a.plot([x+.009,x+.035],[y-.013,y-.070],color=BLUE,lw=.6,alpha=.7)
 film(.055,.775);camera(.185,.889);a.text(.05,.746,'Device-associated regions',fontsize=7.6)
 a.text(.05,.714,'Substrate-isolated validation',fontsize=7.5)
 # D1 recorded trajectory, no synthetic data curves.
 t=code('real_LP725_examples.csv');r=t[t.sample_id=='D1::ACD::43']
 mini=fig.add_axes([.335,.752,.135,.12]);mini.plot(r.frame_index,r.LP725_intensity,color=BLUE,lw=.9)
 mini.set(xlim=(0,718),ylim=(0,4000));mini.set_xticks([0,718]);mini.set_yticks([]);mini.tick_params(labelsize=6.9,length=2,pad=1)
 mini.set_xlabel('Recorded frame',fontsize=6.8,labelpad=1);mini.spines['left'].set_visible(False)
 arrow(a,(.305,.82),(.327,.82));record(r,'Figure1','a',['frame_index','LP725_intensity'])
 film(.565,.775);camera(.69,.889)
 a.text(.56,.746,'ROI identities · experiment groups',fontsize=7.6);a.text(.56,.714,'Date-isolated validation',fontsize=7.5)
 # The channel rack conveys signal identity, not a calibrated ray-tracing diagram.
 for j,(text,c) in enumerate([('LP725',BLUE),('LP780',BLUE),('SP775',BLUE),('ND',GRAY)]):
  y=.888-j*.041;a.add_patch(Rectangle((.865,y-.012),.10,.028,facecolor='white',edgecolor=c,lw=.65));a.text(.915,y+.002,text,ha='center',va='center',fontsize=6.9)
 arrow(a,(.825,.83),(.85,.83));a.plot([.85,.85],[.766,.90],color=GRAY,lw=.6)
 for y in [.888,.847,.806,.765]:a.plot([.85,.865],[y,y],color=GRAY,lw=.6)
 # A shared analysis description is applied independently to each dataset.
 a.plot([.015,.985],[.683,.683],color='#CCD3D8',lw=.6)
 a.text(.01,.654,'(c)',fontweight='bold',fontsize=10.5)
 a.text(.5,.655,'Separate dataset models · group-isolated validation',ha='center',fontsize=8.2)
 arrow(a,(.25,.703),(.25,.585));arrow(a,(.75,.703),(.75,.585))
 for j,txt in enumerate(['Optical trajectories','Statistical descriptors','Within-group ranking']):
  x=.165+j*.32
  a.text(x,.544,txt,ha='center',fontsize=8.)
  if j<2:arrow(a,(x+.11,.49),(x+.21,.49))
  if j==0:
   # Abstract line glyphs are explicitly schematic.
   for off in [0,.022,.044]:a.plot([x-.075,x-.04,x-.015,x+.02,x+.075],[.445+off,.445+off,.485+off,.466+off,.472+off],color=BLUE,lw=.9)
  elif j==1:
   for k,height in enumerate([.045,.073,.058]):a.add_patch(Rectangle((x-.065+k*.045,.445),.025,height,facecolor='#DCECF5',edgecolor=BLUE,lw=.6))
  else:
   for k,w in enumerate([.13,.105,.075,.045]):a.add_patch(Rectangle((x-.065,.515-k*.022),w,.012,facecolor=BLUE if k<2 else '#BFC9D0',edgecolor='none'))
 arrow(a,(.49,.43),(.64,.39),BLUE)
 a.add_patch(Rectangle((.355,.363),.13,.034,facecolor='white',edgecolor=ORANGE,lw=.75));a.text(.42,.38,'Region identity',ha='center',va='center',fontsize=7.3)
 arrow(a,(.485,.38),(.64,.38),ORANGE);a.text(.67,.38,'Matched position controls',fontsize=7.3,va='center')
 # Three measured questions; geometric glyphs illustrate endpoints, not new results.
 a.plot([.015,.985],[.326,.326],color='#CCD3D8',lw=.6);a.text(.01,.298,'(d)',fontweight='bold',fontsize=10.5)
 for x,title in [(.18,'Budget-dependent selection'),(.51,'Temporal information'),(.83,'Optical–electrical discordance')]:
  arrow(a,(x,.335),(x,.273));a.text(x,.077,title,fontsize=7.5,ha='center')
 a.plot([.10,.10,.27],[.12,.246,.246],color=GRAY,lw=.65)
 a.plot([.11,.145,.19,.23,.265],[.137,.188,.218,.215,.16],color=BLUE,lw=1.1,marker='o',ms=2.5)
 a.plot([.43,.59],[.13,.13],color=GRAY,lw=.65)
 a.plot([.44,.50,.57],[.17,.17,.17],color=GRAY,lw=1.3);a.plot([.44,.50,.57],[.135,.19,.238],color=BLUE,lw=1.3)
 a.add_patch(Rectangle((.77,.14),.035,.095,facecolor=BLUE,edgecolor='none'));a.add_patch(Rectangle((.84,.14),.035,.026,facecolor=ORANGE,edgecolor='none'))
 a.text(.787,.113,'Optical',ha='center',fontsize=6.8);a.text(.857,.113,'PCE',ha='center',fontsize=6.8)
 save(fig,'Figure1')

def figure2():
 m=code('recomputed_macro_metrics.csv');fig,axs=plt.subplots(1,2,figsize=(178/25.4,99/25.4))
 fig.subplots_adjust(left=.22,right=.98,top=.83,bottom=.14,wspace=.96)
 shared=['PAIR_ABS','PL_PAIRWISE','ID_PLUS_PL_PAIRWISE','LGBM_PL','EXTRATREES_PL','RIDGE_PL','ID_PAIRWISE','PL_INTENSITY']
 for a,ds,l in zip(axs,['D1','D2'],'ab'):
  ids=shared[:6]+['AUTHOR_KNN_AUX' if ds=='D1' else 'F2_RIDGE_AUX']+shared[6:]
  for phase,off in [('development',-.12),('historical',.12)]:
   for y,mid in enumerate(ids):
    q=m[(m.dataset==ds)&(m.phase==phase)&(m.model_id==mid)];r=q.iloc[0];c=color(mid)
    a.errorbar(r.top25_gain_pp,y+off,xerr=[[r.top25_gain_pp-r.original_gain_CI_low],[r.original_gain_CI_high-r.top25_gain_pp]],fmt='o',color=c,markerfacecolor=c if phase=='development' else 'white',ms=3.9,lw=.85,capsize=1.8)
    record(q,'Figure2',l,['top25_gain_pp','original_gain_CI_low','original_gain_CI_high'])
  a.set_yticks(range(len(ids)),[SHORT[i] for i in ids]);a.set_ylim(len(ids)-.4,-.7)
  a.set_xlabel('Top25% PCE enrichment (pp)');a.axvline(0,color=GRAY,ls=(0,(3,3)),lw=.6);grid(a);label(a,l,ds)
  a.set_xlim((-.2,1.75) if ds=='D1' else (-1.7,2.05));a.tick_params(axis='y',length=0,pad=5)
 fig.legend(handles=[Line2D([],[],marker='o',ls='',color='black',label='Development'),Line2D([],[],marker='o',ls='',color='black',mfc='white',label='Previously inspected history')],ncol=2,loc='upper center',bbox_to_anchor=(.59,.99),frameon=False,fontsize=8.)
 save(fig,'Figure2')

def figure3():
 fig,axs=plt.subplots(2,2,figsize=(178/25.4,127/25.4));fig.subplots_adjust(left=.19,right=.98,bottom=.11,top=.91,wspace=.72,hspace=.67)
 pos=code('V2_position_summary.csv');p=code('paired_gain_comparisons.csv');a=axs[0,0]
 for y,(ds,phase) in enumerate([('D1','development'),('D1','historical'),('D2','development'),('D2','historical')]):
  q=pos[(pos.dataset==ds)&(pos.phase==phase)];r=q.iloc[0];c=BLUE if r.delta>=0 else ORANGE
  a.errorbar(r.delta,y,xerr=[[r.delta-r.low],[r.high-r.delta]],fmt='o',color=c,mfc=c if phase=='development' else 'white',ms=4,lw=1.,capsize=2)
  record(q,'Figure3','a',['delta','low','high'])
 a.set_yticks(range(4),['D1 development','D1 history','D2 development','D2 history']);a.set_ylim(3.5,-.5);a.set_xlim(-.8,.8);a.set_xticks([-.8,-.4,0,.4,.8]);a.set_xlabel('Optical increment over position (pp)');a.axvline(0,color=GRAY,lw=.6,ls='--');grid(a);label(a,'a')
 a=axs[0,1];q=p[(p.phase=='development')&(p.method_a=='PL_PAIRWISE')&(p.method_b=='RIDGE_PL')]
 for y,ds in enumerate(['D1','D2']):
  d=q[q.dataset==ds];r=d.iloc[0];a.errorbar(r.delta_gain_pp,y,xerr=[[r.delta_gain_pp-r.CI_low],[r.CI_high-r.delta_gain_pp]],fmt='o',color=BLUE,lw=1.,capsize=2,ms=4);record(d,'Figure3','b',['delta_gain_pp','CI_low','CI_high'])
 a.set_yticks([0,1],['D1','D2']);a.set_ylim(1.5,-.5);a.set_xlim(-.03,.65);a.set_xlabel('Pairwise − Ridge enrichment (pp)');a.axvline(0,color=GRAY,lw=.6,ls='--');grid(a);label(a,'b')
 abl=sup('D2_ABLATION_MACRO.csv');d=abl[(abl.scope=='D2_DEVELOPMENT_REUSED_DATES')&(abl.input_mode=='OPTICAL_ONLY_REL')]
 for a,vs,labs,l in [(axs[1,0],['FULL4','PL3','ND1'],['PL + reflection','PL only','Reflection only'],'c'),(axs[1,1],['FULL4','LEVEL8','SLOPE4'],['All statistics','Intensity level','Temporal slope'],'d')]:
  for y,v in enumerate(vs):
   q=d[d.variant==v];r=q.iloc[0];a.errorbar(r.gain_pp,y,xerr=[[r.gain_pp-r.gain_pp_ci_low],[r.gain_pp_ci_high-r.gain_pp]],fmt='o',color=BLUE,ms=4,lw=1.,capsize=2);record(q,'Figure3',l,['gain_pp','gain_pp_ci_low','gain_pp_ci_high'])
  a.axvline(d[d.variant=='FULL4'].gain_pp.iloc[0],color=GRAY,ls=(0,(3,3)),lw=.65)
  a.set_yticks(range(3),labs);a.set_ylim(2.6,-.6);a.set_xlim(.1,1.17);a.set_xticks([.2,.5,.8,1.1]);a.set_xlabel('D2 Top25% PCE enrichment (pp)');grid(a);label(a,l)
 save(fig,'Figure3')

def figure4():
 t=code('real_LP725_examples.csv');meta=code('real_LP725_example_metadata.csv');reg=sup('AEM_ALL_REGIONS.csv');sen=sup('AEM_SINGLE_POINT_FILTER.csv')
 fig,axs=plt.subplots(2,2,figsize=(178/25.4,129/25.4));fig.subplots_adjust(left=.10,right=.98,bottom=.13,top=.86,hspace=.66,wspace=.42)
 for a,sid,l in zip(axs[0],['ACD','AEM'],'ab'):
  q=meta[meta.substrate==sid]
  for _,r in q.iterrows():
   d=t[t.sample_id==r.sample_id];c=BLUE if r.extremum=='highest_PCE' else ORANGE
   a.plot(d.frame_index,d.LP725_intensity,color=c,lw=1.05);record(d,'Figure4',l,['frame_index','LP725_intensity'])
  a.set(xlim=(0,718),ylim=(0,4100),xlabel='Recorded frame',ylabel='LP725 intensity (a.u.)');a.set_yticks([0,2000,4000]);a.set_xticks([0,200,400,600]);label(a,l,sid)
  if sid=='AEM':a.text(.98,.82,'AEM::21 · PCE 0.455%\nPredicted rank 2/32',ha='right',va='top',transform=a.transAxes,fontsize=7.)
 a=axs[1,0];selected=reg.selected_top25.astype(bool)
 a.scatter(reg.PAIR_ABS_rank,reg.target,c=np.where(selected,BLUE,GRAY),s=15,lw=0,zorder=3)
 r=reg[reg.sample_id=='D1::AEM::21'].iloc[0];a.scatter([r.PAIR_ABS_rank],[r.target],s=58,facecolor='none',edgecolor=ORANGE,lw=1.1,zorder=4)
 a.annotate('AEM::21',(r.PAIR_ABS_rank,r.target),xytext=(8,2.2),arrowprops={'arrowstyle':'-','color':ORANGE,'lw':.8},fontsize=7.5)
 a.axvline(8.5,color=GRAY,lw=.55);original=sen[sen.scenario=='ALL_REGIONS'].iloc[0]
 a.axhline(original.reference_mean,color='black',ls=(0,(3,3)),lw=.65);a.set(xlim=(0,33),ylim=(-.5,15),xlabel='Predicted rank (1 = highest)',ylabel='Measured PCE (%)');a.set_xticks([1,8,16,24,32]);a.set_yticks([0,5,10,15]);label(a,'c','AEM · all 32 regions');record(reg,'Figure4','c',['target','PAIR_ABS_rank'])
 a=axs[1,1]
 for i,scenario in enumerate(['ALL_REGIONS','POSTHOC_REMOVE_AEM_21']):
  q=sen[sen.scenario==scenario];r=q.iloc[0];c=BLUE if i==0 else ORANGE
  a.plot([i,i],[0,r.gain_pp],color=c,lw=1.1);a.scatter([i],[r.gain_pp],color=c if i==0 else 'white',edgecolor=c,s=35,lw=1.3,zorder=3)
  a.annotate(f'{r.gain_pp:+.3f}',(i,r.gain_pp),xytext=(0,7),textcoords='offset points',ha='center',fontsize=8.)
  record(q,'Figure4','d',['gain_pp','n','k','reference_mean','selected_mean'])
 a.set_xticks([0,1],['All regions\nn = 32; k = 8','Exclude AEM::21\nn = 31; k = 8']);a.tick_params(axis='x',labelsize=7.1,pad=6,length=0)
 a.set(xlim=(-.55,1.55),ylim=(-.7,1.1),ylabel='Top25% PCE enrichment (pp)');a.set_yticks([-.5,0,.5,1]);a.axhline(0,color='black',ls=(0,(3,3)),lw=.65);label(a,'d','Post hoc exclusion')
 fig.legend(handles=[Line2D([],[],color=BLUE,label='Higher-PCE trace'),Line2D([],[],color=ORANGE,label='Lower-PCE trace')],ncol=2,loc='upper center',bbox_to_anchor=(.54,.99),frameon=False,fontsize=8.)
 save(fig,'Figure4')

def figure_s1():
 cnt=code('dataset_counts.csv');g=code('group_characteristics.csv',dtype={'split_group':str})
 fig,axs=plt.subplots(2,2,figsize=(178/25.4,113/25.4),gridspec_kw={'height_ratios':[1.5,.5]});fig.subplots_adjust(left=.10,right=.98,top=.87,bottom=.20,wspace=.34,hspace=1.0)
 for j,ds in enumerate(['D1','D2']):
  a=axs[0,j];q=cnt[cnt.dataset==ds]
  vals=[q[q.phase==p].regions.iloc[0] for p in ['development','historical']]
  bars=a.bar([0,1],vals,width=.52,color=[BLUE,'white'],edgecolor=BLUE,lw=.9)
  for bar,v in zip(bars,vals):a.text(bar.get_x()+bar.get_width()/2,v+max(vals)*.04,f'{v:,}',ha='center',fontsize=8.)
  a.set_xticks([0,1],['Development','History']);a.set_ylim(0,max(vals)*1.25);a.set_ylabel('Labeled regions');label(a,chr(97+j),ds);record(q,'FigureS1',chr(97+j),['regions','selection_units','independent_evaluation_groups'])
  a=axs[1,j];q=g[(g.dataset==ds)&(g.phase=='development')][['dataset','phase','split_group','outer_fold','_row']].drop_duplicates('split_group').sort_values('split_group');q.attrs=g.attrs.copy()
  # Light categorical fold fills keep every numeric fold label black.
  palette=['#F3F5F7','#E4ECF2','#D6E5EF','#EAE4D9','#F4E5DC','#E1ECE6','#ECE7EF']
  for x,fold in enumerate(q.outer_fold):a.add_patch(Rectangle((x-.5,-.5),1,1,facecolor=palette[int(fold)],edgecolor='white',lw=.5))
  a.set_xlim(-.5,len(q)-.5);a.set_ylim(.5,-.5)
  for x,fold in enumerate(q.outer_fold):a.text(x,0,str(fold),ha='center',va='center',fontsize=6.7,color='black')
  labels=q.split_group if ds=='D1' else [s[4:6]+'/'+s[6:] for s in q.split_group]
  a.set_xticks(range(len(q)),labels,rotation=90 if ds=='D1' else 65,fontsize=6.9);a.set_yticks([]);a.tick_params(length=0,pad=3)
  for sp in a.spines.values():sp.set_visible(False)
  label(a,chr(99+j),'D1 substrate folds' if ds=='D1' else 'D2 date folds');record(q,'FigureS1',chr(99+j),['outer_fold'])
 save(fig,'FigureS1','SI')

def figure_s2():
 fig,axs=plt.subplots(2,2,figsize=(178/25.4,183/25.4));fig.subplots_adjust(left=.25,right=.985,top=.955,bottom=.075,wspace=1.30,hspace=.25)
 for a,(ds,phase),l in zip(axs.flat,[('D1','development'),('D1','historical'),('D2','development'),('D2','historical')],'abcd'):
  d=read(f'DATA/CODE/SOURCE_DATA/P6/{ds.lower()}_macro_model_comparison.csv')
  q=d[d.scope.str.contains('DEVELOPMENT' if phase=='development' else 'AUTHOR_TEST' if ds=='D1' else 'HISTORY')].sort_values('model_id')
  for y,(_,r) in enumerate(q.iterrows()):
   c=color(r.model_id);a.errorbar(r.top25_gain_pp,y,xerr=[[r.top25_gain_pp-r.top25_gain_pp_ci95_low],[r.top25_gain_pp_ci95_high-r.top25_gain_pp]],fmt='o',color=c,mfc=c if phase=='development' else 'white',ms=3,lw=.65,capsize=1.5)
  a.set_yticks(range(len(q)),[SHORT[i] for i in q.model_id],fontsize=7.0);a.tick_params(axis='y',length=0,pad=4);a.set_ylim(len(q)-.5,-.8);a.set_xlabel('Top25% enrichment (pp)',fontsize=7.4);a.axvline(0,color=GRAY,lw=.6,ls='--');grid(a);label(a,l,ds+' '+('development' if phase=='development' else 'history'));record(q,'FigureS2',l,['top25_gain_pp','top25_gain_pp_ci95_low','top25_gain_pp_ci95_high'])
 save(fig,'FigureS2','SI')

def group_figure(phase,name):
 d=code('recomputed_independent_group_metrics.csv',dtype={'split_group':str});fig,axs=plt.subplots(1,2,figsize=(178/25.4,83/25.4));fig.subplots_adjust(left=.10,right=.98,top=.83,bottom=.28,wspace=.32)
 for a,ds,l in zip(axs,['D1','D2'],'ab'):
  q=d[(d.dataset==ds)&(d.phase==phase)&(d.model_id=='PAIR_ABS')].sort_values('split_group');x=np.arange(len(q))
  a.bar(x,q.top25_gain_pp,color=[BLUE if v>=0 else ORANGE for v in q.top25_gain_pp],width=.72,edgecolor=None)
  if phase=='historical':
   for bar in a.patches:bar.set_fill(False);bar.set_edgecolor(ORANGE if bar.get_height()<0 else BLUE);bar.set_linewidth(.9)
  a.set_xticks(x,q.split_group if ds=='D1' else [s[4:6]+'/'+s[6:] for s in q.split_group],rotation=90 if ds=='D1' else 55,fontsize=6.9 if ds=='D1' else 7.)
  a.set_ylabel('Top25% PCE enrichment (pp)');a.axhline(0,color='black',lw=.6);label(a,l,ds);record(q,name,l,['top25_gain_pp'])
 save(fig,name,'SI')

def figure_s5():
 d=sup('D2_ABLATION_MACRO.csv');m=code('recomputed_macro_metrics.csv');ids=['FULL4','PL3','ND1','LEVEL8','SLOPE4'];labs=['PL + reflection','PL only','Reflection only','Intensity level','Temporal slope']
 fig,axs=plt.subplots(1,2,figsize=(178/25.4,100/25.4));fig.subplots_adjust(left=.19,right=.98,top=.78,bottom=.21,wspace=.70)
 for a,scope,phase,l in zip(axs,['D2_DEVELOPMENT_REUSED_DATES','D2_HISTORY_PREVIOUSLY_INSPECTED'],['development','historical'],'ab'):
  for j,mode in enumerate(['OPTICAL_ONLY_REL','POSITION_PLUS_OPTICAL_REL']):
   for i,v in enumerate(ids):
    q=d[(d.scope==scope)&(d.input_mode==mode)&(d.variant==v)];r=q.iloc[0];c=BLUE if j==0 else ORANGE
    a.errorbar(r.gain_pp,4-i+(.12 if j==0 else -.12),xerr=[[r.gain_pp-r.gain_pp_ci_low],[r.gain_pp_ci_high-r.gain_pp]],fmt='o' if j==0 else 's',color=c,mfc=c if phase=='development' else 'white',ms=4,lw=.9,capsize=2);record(q,'FigureS5',l,['gain_pp','gain_pp_ci_low','gain_pp_ci_high'])
  baseline=m[(m.dataset=='D2')&(m.phase==phase)&(m.model_id=='ID_PAIRWISE')];v=baseline.top25_gain_pp.iloc[0]
  a.axvline(v,color=GRAY,ls=(0,(4,3)),lw=1.0,zorder=0)
  a.text(v,4.78,'Position only',ha='center',va='bottom',fontsize=7.,rotation=0)
  a.set_yticks(range(4,-1,-1),labs);a.set_ylim(-.55,5.25);a.tick_params(axis='y',length=0,pad=4)
  a.set_xlim(0,1.25) if phase=='development' else a.set_xlim(-.05,2.0)
  a.set_xticks([0,.4,.8,1.2] if phase=='development' else [0,.5,1,1.5,2])
  a.set_xlabel('Top25% PCE enrichment (pp)');grid(a);label(a,l,'Development · 14 dates' if phase=='development' else 'History · 3 dates');record(baseline,'FigureS5',l,['top25_gain_pp'])
 handles=[Line2D([],[],color=BLUE,marker='o',label='Optical only (relative)',lw=1),Line2D([],[],color=ORANGE,marker='s',label='Position + optical (relative)',lw=1)]
 fig.legend(handles=handles,ncol=2,loc='upper center',bbox_to_anchor=(.56,.99),frameon=False,fontsize=8.)
 fig.text(.55,.055,'Historical optical increment over position: −0.304 pp [−0.736, −0.023]',ha='center',fontsize=7.6)
 save(fig,'FigureS5','SI')

def figure_s6():
 fig=plt.figure(figsize=(178/25.4,125/25.4));axs=[fig.add_axes([.10,.59,.40,.28]),fig.add_axes([.61,.59,.37,.28]),fig.add_axes([.30,.13,.52,.28])]
 for a,ds,l in zip(axs[:2],['D1','D2'],'ab'):
  frames=[]
  for phase in (['development'] if ds=='D1' else ['development','historical']):
   q=code(f'{ds}_{phase}_position_paired.csv',dtype={'split_group':str});q['phase']=phase;frames.append(q)
  q=pd.concat(frames,ignore_index=True);q.attrs=frames[0].attrs.copy()
  a.bar(range(len(q)),q.delta,color=[BLUE if v>=0 else ORANGE for v in q.delta],width=.72)
  if ds=='D2':
   for i,p in enumerate(a.patches):
    if q.phase.iloc[i]=='historical':p.set_fill(False);p.set_edgecolor(ORANGE);p.set_linewidth(1)
  a.set_xticks(range(len(q)),q.split_group if ds=='D1' else [s[4:6]+'/'+s[6:] for s in q.split_group],rotation=90 if ds=='D1' else 65,fontsize=6.4);a.set_ylabel('Optical increment (pp)');a.axhline(0,color='black',lw=.6);label(a,l,ds)
  for f in frames:record(f,'FigureS6',l,['delta'])
 a=axs[2];m=code('recomputed_macro_metrics.csv');labels=['Dual-view representation','Gated residual correction','Trajectory-shape extension']
 for j,(stage,mid) in enumerate([('P7','DVR_SELECTED'),('P8','P8_SELECTED'),('P9','M1')]):
  path=f'DATA/CODE/SOURCE_DATA/{stage}/'+('dataset_macro_metrics.csv' if stage=='P9' else 'macro_model_comparison.csv');d=read(path)
  q=d[d.model_id==mid]
  if 'scope' in q:q=q[q.scope.str.contains('DEVELOPMENT')]
  for off,ds,c,mark in [(-.12,'D1',BLUE,'o'),(.12,'D2',GREEN,'s')]:
   r=q[q.dataset==ds];base=m[(m.dataset==ds)&(m.phase=='development')&(m.model_id=='PAIR_ABS')].top25_gain_pp.iloc[0]
   a.scatter(r.top25_gain_pp.iloc[0]-base,j+off,c=c,marker=mark,s=23)
   record(r,'FigureS6','c',['top25_gain_pp'])
 a.set_yticks(range(3),labels);a.set_ylim(2.6,-.6);a.set_xlim(-.17,.12);a.set_xlabel('Enrichment difference from absolute ranker (pp)');a.axvline(0,color=GRAY,ls='--',lw=.6);grid(a);label(a,'c')
 a.legend(handles=[Line2D([],[],marker='o',color=BLUE,ls='',label='D1'),Line2D([],[],marker='s',color=GREEN,ls='',label='D2')],loc='upper right',frameon=False,ncol=2,fontsize=7.)
 save(fig,'FigureS6','SI')

def figure_s7():
 m=code('recomputed_macro_metrics.csv');fig,axs=plt.subplots(1,2,figsize=(178/25.4,91/25.4));fig.subplots_adjust(left=.10,right=.98,top=.83,bottom=.31,wspace=.38)
 for ds,c,marker in [('D1',BLUE,'o'),('D2',GREEN,'s')]:
  ids=['PAIR_ABS','PAIR_REL','PL_PAIRWISE'] if ds=='D1' else ['PAIR_ABS','PL_PAIRWISE','PAIR_BOTH']
  q=m[(m.dataset==ds)&(m.phase=='development')].set_index('model_id').loc[ids].reset_index();q.attrs=m.attrs.copy()
  x=np.arange(3)+(-.08 if ds=='D1' else .08);axs[0].plot(x,q.top25_gain_pp,marker=marker,color=c,lw=1.,ms=4,label=ds);record(q,'FigureS7','a',['top25_gain_pp'])
 axs[0].set_xticks(range(3),['Absolute','Relative','Combined']);axs[0].set_ylabel('Top25% enrichment (pp)');axs[0].legend(frameon=False);label(axs[0],'a')
 ids=['PAIR_EARLY25','PAIR_LATE25','PL_PAIRWISE','PAIR_LEVEL','PAIR_DYNAMIC'];q=m[(m.dataset=='D1')&(m.phase=='development')].set_index('model_id').loc[ids].reset_index();q.attrs=m.attrs.copy()
 axs[1].bar(range(5),q.top25_gain_pp,color=[GRAY,GRAY,BLUE,GRAY,BLUE],width=.65)
 axs[1].set_xticks(range(5),['First 25%\nframes','Last 25%\nframes','Full\ntrace','Intensity\nlevel','Dynamic\nstatistics'],rotation=25,ha='right',fontsize=7.);axs[1].set_ylabel('Top25% enrichment (pp)');label(axs[1],'b','D1');record(q,'FigureS7','b',['top25_gain_pp'])
 save(fig,'FigureS7','SI')

def main():
 for fn in [figure1,figure2,figure3,figure4,figure_s1,figure_s2,lambda:group_figure('development','FigureS3'),lambda:group_figure('historical','FigureS4'),figure_s5,figure_s6,figure_s7]:fn()
 S.STYLES['PL_INTENSITY']=(GRAY,'^',(0,(5,2)),'Single-intensity rule')
 S.STYLES['PAIR_ABS']=(BLUE,'o','-','Absolute optical ranker')
 S.STYLES['ID_PAIRWISE']=(ORANGE,'s','-','Position-only ranker')
 tri=S.read('TRIAGE_MACRO_SUMMARY.csv');cul=S.read('CULLING_MACRO_MICRO.csv')
 S.curves(tri,'gain_pp',('gain_pp_ci_low','gain_pp_ci_high'),'recall_truth_top10',('recall_truth_top10_ci_low','recall_truth_top10_ci_high'),'Figure5')
 # Reduced opacity for sparse D1 low-PCE events without changing uncertainty.
 import inspect
 src=inspect.getsource(S.curves).replace("color=BLUE, alpha=.11","color=BLUE, alpha=.07")
 exec(src,S.__dict__)
 S.curves(cul,'kept_gain_pp',('kept_gain_pp_ci_low','kept_gain_pp_ci_high'),'micro_recall_low_pce',('micro_recall_CI_low','micro_recall_CI_high'),'FigureS8',True)
 for r in S.NUMBERS:
  r['source_csv']='DATA/SUP/INPUT/'+r['source_csv'];PROV.append(r)
 pd.DataFrame(PROV).to_csv(B/'FIGURE_DATA_PROVENANCE.csv',index=False,float_format='%.17g')
 pd.DataFrame([{'source_id':i,'publication_name':v,'short_figure_label':SHORT[i]} for i,v in NAMES.items()]).to_csv(B/'REPRODUCIBILITY_MODEL_MAP.csv',index=False)
 (B/'RUN_RECEIPTS/figure_geometry.json').write_text(json.dumps(S.GEOMETRY,indent=2))
 print('Created 5 main + 8 SI plates, all 3 formats; no fitting')

if __name__=='__main__':main()
