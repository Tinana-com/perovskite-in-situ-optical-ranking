"""Generate polished R2 figures in D:\\论文\\PL\\manuscript2_polish_r2\\figures without modifying original files."""
from pathlib import Path
import importlib.util
import shutil
import numpy as np
import pandas as pd
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch
from matplotlib.lines import Line2D

R2 = Path(r'D:\论文\PL\manuscript2_polish_r2')
FIGS = R2 / 'figures'
MAIN_DIR = FIGS / 'MAIN'
SI_DIR = FIGS / 'SI'
R1 = Path(r'D:\论文\PL\figure1_redesign_r1')
ASSETS = Path(r'D:\论文\PL\manuscript2_assets')

spec = importlib.util.spec_from_file_location('screen', ASSETS / 'DATA/SUP/OUTPUT/source_code/make_figures.py')
S = importlib.util.module_from_spec(spec)
spec.loader.exec_module(S)
S.ROOT = ASSETS
S.OUT = FIGS
S.DATA = ASSETS / 'DATA/SUP/INPUT/DATA/CODEX'

BLUE, ORANGE, GRAY, GREEN = S.BLUE, S.ORANGE, S.GRAY, '#009E73'
LIGHT, PALE = '#DDE2E7', '#EAF3F8'
SLATE_SUB = '#4A5568'

D1_SHORT = {
    'PAIR_ABS': 'Pairwise · absolute',
    'PL_PAIRWISE': 'Pairwise · combined',
    'ID_PLUS_PL_PAIRWISE': 'Pairwise · combined + pos.',
    'LGBM_PL': 'LambdaRank · combined',
    'LGBM_IDPL': 'LambdaRank · comb. + pos.',
    'EXTRATREES_PL': 'ExtraTrees · combined',
    'EXTRATREES_IDPL': 'ExtraTrees · comb. + pos.',
    'HISTGB_PL': 'HistGB · combined',
    'HISTGB_IDPL': 'HistGB · comb. + pos.',
    'RIDGE_PL': 'Ridge · combined',
    'RIDGE_IDPL': 'Ridge · comb. + pos.',
    'AUTHOR_KNN_AUX': 'Author-derived kNN',
    'ID_PAIRWISE': 'Pairwise · position only',
    'ID_PRIOR': 'Shrunk position prior',
    'PL_INTENSITY': 'Single-intensity rule',
    'RANDOM_EXPECTATION': 'Random expectation',
    'PAIR_DYNAMIC': 'Pairwise · dynamic (comb.)',
    'PAIR_LEVEL': 'Pairwise · levels (comb.)',
    'PAIR_REL': 'Pairwise · relative',
    'PAIR_EARLY25': 'Pairwise · first 25% frames',
    'PAIR_LATE25': 'Pairwise · last 25% frames',
}

D2_SHORT = {
    'PAIR_ABS': 'Pairwise · absolute',
    'PL_PAIRWISE': 'Pairwise · relative',
    'ID_PLUS_PL_PAIRWISE': 'Pairwise · relative + pos.',
    'LGBM_PL': 'LambdaRank · relative',
    'EXTRATREES_PL': 'ExtraTrees · relative',
    'EXTRATREES_IDPL': 'ExtraTrees · rel. + pos.',
    'HISTGB_PL': 'HistGB · relative',
    'HISTGB_IDPL': 'HistGB · rel. + pos.',
    'RIDGE_PL': 'Ridge · relative',
    'F2_RIDGE_AUX': 'Ridge · absolute',
    'ID_PAIRWISE': 'Pairwise · position only',
    'ID_PRIOR': 'Shrunk position prior',
    'PAIR_BOTH': 'Pairwise · combined',
    'PL_INTENSITY': 'Single-intensity rule',
    'RANDOM_EXPECTATION': 'Random expectation',
}


def read_code(name, **kw):
    return pd.read_csv(ASSETS / 'DATA/CODE/ANALYSIS' / name, float_precision='round_trip', **kw)


def read_sup(name, **kw):
    return pd.read_csv(ASSETS / 'DATA/SUP/INPUT/DATA/CODEX' / name, float_precision='round_trip', **kw)


def color_of(mid):
    if mid in ['ID_PAIRWISE', 'ID_PLUS_PL_PAIRWISE', 'ID_PRIOR'] or mid.endswith('_IDPL'):
        return ORANGE
    if mid in ['PL_INTENSITY', 'RANDOM_EXPECTATION']:
        return GRAY
    return BLUE


def draw_figure1_r2():
    """Minimal readability polish of R1 Option B workflow without changing geometry or palette."""
    plt.rcParams.update({
        'font.family': 'Arial', 'font.size': 7.2, 'text.color': 'black',
        'axes.labelcolor': 'black', 'xtick.color': 'black', 'ytick.color': 'black',
        'pdf.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white'
    })
    trace = pd.read_csv(R1 / 'sources/Measured_D1_ACD43_LP725.csv', float_precision='round_trip')
    trace = trace[trace.sample_id == 'D1::ACD::43'].copy()
    assert len(trace) == 719

    H = 109
    fig = plt.figure(figsize=(178 / 25.4, H / 25.4))
    a = fig.add_axes([0, 0, 1, 1])
    a.set(xlim=(0, 178), ylim=(H, 0))
    a.axis('off')

    def txt(x, y, s, size=7.2, weight='normal', ha='left', va='top', color='black'):
        a.text(x, y, s, fontsize=size, fontweight=weight, ha=ha, va=va, color=color, linespacing=1.15)

    def ln(pts, c=GRAY, lw=.75, ls='-'):
        a.plot(*zip(*pts), c=c, lw=lw, ls=ls, solid_capstyle='round', zorder=1)

    def arw(p, q, c=BLUE, lw=1.0, ls='-', ms=8):
        a.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=ms, color=c, lw=lw,
                                    linestyle=ls, shrinkA=0, shrinkB=0, zorder=2))

    def rct(x, y, w, h, c=GRAY, fill='white', lw=.7, ls='-'):
        a.add_patch(Rectangle((x, y), w, h, facecolor=fill, edgecolor=c, lw=lw, linestyle=ls, zorder=0))

    starts = [.5, 41.5, 77, 111, 148.5]
    widths = [36.5, 30.5, 29.5, 31.5, 29]
    bottoms = [91.5, 80, 80, 80, 105]
    fills = ['#E6F2FB', '#E6F3EE', '#EEE6F6', '#E7EEF6', '#FFF0DF']
    borders = ['#6C9FBE', '#76A493', '#9980B4', '#8A9CB2', '#BC9D79']
    labels = [
        'Optical\nacquisition',
        'Optical\nrepresentation',
        'Regional\nranking',
        'Group-isolated\nevaluation',
        'Decision-oriented\nanalyses',
    ]

    rct(39.6, 1.6, 104.5, 91.2, c=GRAY, lw=.75, ls=(0, (3, 2)), fill='none')
    for i, (x, w, b, fill, border, lab) in enumerate(zip(starts, widths, bottoms, fills, borders, labels), 1):
        rct(x, 3, w, b - 3, c=border, lw=.8, fill=fill)
        ln([(x, 15.3), (x + w, 15.3)], border, .65)
        txt(x + 1.4, 5.3, str(i), 8.6, 'bold')
        txt(x + 6.1, 5.4, lab, 7.1, 'bold')

    # Stage 1: D1 + D2 (cleaner D2 box alignment & bus line)
    txt(2, 19.2, 'D1', 7.7, 'bold')
    txt(8.5, 19.2, 'LP725 PL', 7.0)
    im = Image.open(R1 / 'sources/Optical_Acquisition_Selected.png')
    a.imshow(im, extent=(1.8, 35.4, 52.4, 30), aspect='auto', zorder=0)
    txt(2, 26, 'Blade coating', 6.3)
    ln([(9, 29), (9, 41)], GRAY, .5)
    txt(34.5, 26, 'PL imaging', 6.3, ha='right')
    ln([(27.5, 29), (21.5, 34.5)], GRAY, .5)
    txt(5, 55.6, 'Thin film', 6.3)
    ln([(17, 56.4), (20, 52)], GRAY, .5)
    txt(2, 60.5, 'Substrate groups', 6.6)
    ln([(1.8, 65.4), (35.4, 65.4)], '#BDD6E8', .55)

    txt(2, 67.6, 'D2', 7.7, 'bold')
    txt(8.5, 67.6, 'PL + reflection', 6.8)
    for i, lab in enumerate(['LP725', 'LP780', 'SP775', 'ND']):
        xx = 2.0 + i * 8.1
        rct(xx, 74.2, 7.3, 5.5, BLUE if i < 3 else GRAY, 'white', .6)
        txt(xx + 3.65, 75.8, lab, 6.0, ha='center')
    # Clean horizontal bus under/from D2 channel tiles without colliding with ND border
    ln([(5.65, 79.7), (5.65, 81.3), (35.3, 81.3), (35.3, 78.2)], '#6C9FBE', .55)
    for i in range(1, 4):
        cx = 2.0 + i * 8.1 + 3.65
        ln([(cx, 79.7), (cx, 81.3)], '#6C9FBE', .55)
    txt(2, 84.2, 'Experiment / date groups', 6.25)

    ln([(35.4, 43), (38.1, 43), (38.1, 45)], BLUE, .9)
    ln([(35.3, 78.2), (38.1, 78.2), (38.1, 45)], BLUE, .9, (0, (2, 1.4)))
    arw((38.1, 45), (41.5, 45), BLUE, .95)

    # Stage 2
    txt(56.7, 21, 'Recorded trajectories', 6.6, 'bold', ha='center')
    v = trace.LP725_intensity.to_numpy()
    xx = 44 + trace.frame_index.to_numpy() / 718 * 25
    yy = 27 + 12 - (v - v.min()) / (v.max() - v.min()) * 12
    ln([(44, 27), (44, 39), (69, 39)], GRAY, .5)
    ln(list(zip(xx, yy)), BLUE, .8)
    arw((56.5, 40.5), (56.5, 44), BLUE, .7, ms=6)
    txt(56.7, 46, 'Statistical descriptors', 6.6, 'bold', ha='center')
    for row in range(3):
        for col in range(4):
            rct(51 + col * 3.3, 54 + row * 4.1, 2.5, 2.8, BLUE, PALE, .6)
    txt(43, 51, 'Absolute', 6.3)
    ln([(50.8, 53), (54, 55.2)], GRAY, .5)
    txt(70.3, 68.5, 'Dynamics', 6.3, ha='right')
    ln([(63, 59), (66, 66.8)], GRAY, .5)
    txt(43, 74, 'Relative', 6.3)
    ln([(49.5, 72.8), (53, 64.2)], GRAY, .5)
    ln([(72, 59), (74.5, 59), (74.5, 45)], BLUE, .9)
    arw((74.5, 45), (77, 45), BLUE, .9)

    # Stage 3
    txt(91.7, 21, 'Linear pairwise ranker', 6.6, 'bold', ha='center')
    for i, f in enumerate([1., .82, .64, .48, .30]):
        rct(80, 36 + i * 24 / 5, 22 * f, 24 / 5 * .55, c=BLUE if i < 2 else GRAY,
            fill=BLUE if i < 2 else '#C8CDD2', lw=0)
    ln([(80 + 23.7, 35), (80 + 25, 35), (80 + 25, 36 + 24 / 5 * 1.8 - 1), (80 + 23.7, 36 + 24 / 5 * 1.8 - 1)], BLUE, .75)
    txt(104.8, 29, 'Top-ranked', 6.1, ha='right')
    ln([(100, 32), (104.5, 35.7)], GRAY, .5)
    txt(91.7, 64, 'Within-group order', 6.5, ha='center')
    ln([(80, 70), (83, 68.5), (87, 70), (91, 67.7)], GRAY, .65)
    for px, py_ in [(80, 70), (83, 68.5), (87, 70), (91, 67.7)]:
        a.plot(px, py_, 'o', ms=1.6, color=GRAY)
    ln([(96, 70.5), (98, 67.5), (100.5, 68), (104, 70)], GRAY, .7)
    txt(79.3, 75, 'Regression', 6.0)
    txt(104.8, 75, 'Intensity', 6.0, ha='right')
    arw((106.5, 45), (111, 45), BLUE, .95)

    # Stage 4: Clear D1 & D2 isolation hierarchy BOTH above the shared train/held-out schematic
    txt(126.8, 18.6, 'D1: substrate isolation', 6.3, 'bold', ha='center')
    txt(126.8, 23.2, 'D2: date isolation', 6.3, 'bold', ha='center')
    txt(126.8, 27.3, '(within-experiment ranks)', 5.8, ha='center', color=SLATE_SUB)
    ln([(113, 32.0), (140.7, 32.0)], LIGHT, .65)

    txt(113, 35.2, 'Train groups', 6.5)
    for j in range(4):
        rct(113 + j * 4.2, 40.8, 3.1, 6.0, BLUE, PALE, .6)
    arw((130.5, 43.8), (134.1, 43.8), BLUE, .65, ms=5)
    txt(135, 42.4, 'Fit', 6.5)

    ln([(113, 52.0), (140.7, 52.0)], LIGHT, .65)
    txt(113, 55.4, 'Held-out groups', 6.5)
    for j in range(2):
        rct(113 + j * 4.2, 61.6, 3.1, 6.0, GRAY, 'white', .65)
    arw((122.4, 64.6), (132, 64.6), GRAY, .65, ms=5)
    txt(133, 63.1, 'Score', 6.5)

    arw((142.5, 45), (145.2, 45), BLUE, .95)

    # Softer footer label weight inside CV box
    txt(91.5, 84.3, 'Outer grouped CV · separate D1 and D2 models', 6.4, 'normal', ha='center', color=SLATE_SUB)
    txt(91.5, 88.8, 'Training groups fit; held-out groups score', 5.9, 'normal', ha='center', color=SLATE_SUB)

    # Stage 5
    ln([(145.2, 45), (145.2, 34), (148.4, 34)], BLUE, .85)
    ln([(145.2, 45), (145.2, 62), (148.4, 62)], BLUE, .85)
    ln([(145.2, 45), (145.2, 91), (148.4, 91)], BLUE, .85)
    for yy in [34, 62, 91]:
        arw((146.6, yy), (149.8, yy), BLUE, .8, ms=6)

    txt(163, 20, 'Budget-dependent\nselection', 6.6, 'bold', ha='center')
    for j in range(4):
        rct(158 + j * 2.8, 32, 1.8, 7, BLUE, BLUE if j < 2 else 'white', .5)
    txt(151, 30, 'Top-q', 6.1)
    ln([(156.5, 32), (158, 35)], GRAY, .45)
    txt(176, 42, 'Enrichment', 6.1, ha='right')
    txt(152, 47, 'Top-decile recall', 6.1)
    ln([(151, 52), (175.5, 52)], LIGHT, .6)

    txt(163, 54, 'Temporal\ninformation', 6.6, 'bold', ha='center')
    ln([(159, 69), (161, 68), (164, 64), (169, 62)], BLUE, .85)
    ln([(159, 69), (162, 67.7), (166, 66.5), (169, 65.8)], GRAY, .65)
    txt(151, 61, 'PL', 6.1)
    txt(151, 67, 'ND', 6.1)
    txt(176, 74, 'Level / slope', 6.1, ha='right')
    ln([(151, 80), (175.5, 80)], LIGHT, .6)

    txt(163, 82, 'Optical–electrical\ndiscordance', 6.6, 'bold', ha='center')
    rct(159, 90, 3.3, 7, BLUE, PALE, .6)
    rct(166, 93, 3.3, 4, ORANGE, 'white', .6)
    ln([(163.1, 92.9), (165.1, 94.2)], GRAY, .55)
    txt(151, 93, 'Optical', 6.1)
    txt(176, 95, 'PCE', 6.1, ha='right')
    txt(163, 101, 'Formation → device', 6.1, ha='center')

    # Position-only control bypass (orange matching Figs 2-5, S2, S5, S8)
    py = 101.1
    rct(1, 95.5, 35, 10.5, c=ORANGE, lw=.65, fill='#FFE9D1')
    rct(77, 95.5, 33, 10.5, c=ORANGE, lw=.65, fill='#FFE9D1')
    txt(3, 98.2, 'Region identity', 6.9, 'bold')
    arw((36, py), (77, py), ORANGE, .85)
    txt(55, 96, 'Non-optical input', 6.3, ha='center')
    txt(79, 98.2, 'Position-only control', 6.9, 'bold')
    ln([(110, py), (128, py), (128, 86.8)], ORANGE, .85)
    arw((128, 86.8), (128, 80), ORANGE, .85, ms=6)

    MAIN_DIR.mkdir(parents=True, exist_ok=True)
    for ext in ['svg', 'pdf', 'png']:
        fig.savefig(MAIN_DIR / f'Figure1_Final.{ext}', dpi=600)
    plt.close(fig)


def draw_figure2_r2():
    """Explicit dataset-accurate optical representation labels (removing vague 'reference')."""
    S.style()
    plt.rcParams.update({'font.size': 8., 'axes.labelsize': 8., 'xtick.labelsize': 7.2, 'ytick.labelsize': 7.2})
    m = read_code('recomputed_macro_metrics.csv')
    fig, axs = plt.subplots(1, 2, figsize=(178 / 25.4, 99 / 25.4))
    fig.subplots_adjust(left=.23, right=.98, top=.83, bottom=.14, wspace=1.08)
    shared = ['PAIR_ABS', 'PL_PAIRWISE', 'ID_PLUS_PL_PAIRWISE', 'LGBM_PL', 'EXTRATREES_PL', 'RIDGE_PL', 'ID_PAIRWISE', 'PL_INTENSITY']

    for a, ds, l in zip(axs, ['D1', 'D2'], 'ab'):
        ids = shared[:6] + ['AUTHOR_KNN_AUX' if ds == 'D1' else 'F2_RIDGE_AUX'] + shared[6:]
        labmap = D1_SHORT if ds == 'D1' else D2_SHORT
        for phase, off in [('development', -.12), ('historical', .12)]:
            for y, mid in enumerate(ids):
                q = m[(m.dataset == ds) & (m.phase == phase) & (m.model_id == mid)]
                r = q.iloc[0]
                c = color_of(mid)
                a.errorbar(
                    r.top25_gain_pp, y + off,
                    xerr=[[r.top25_gain_pp - r.original_gain_CI_low], [r.original_gain_CI_high - r.top25_gain_pp]],
                    fmt='o', color=c, markerfacecolor=c if phase == 'development' else 'white',
                    ms=3.9, lw=.85, capsize=1.8
                )
        a.set_yticks(range(len(ids)), [labmap[i] for i in ids])
        a.set_ylim(len(ids) - .4, -.7)
        a.set_xlabel('Top25% PCE enrichment (pp)')
        a.axvline(0, color=GRAY, ls=(0, (3, 3)), lw=.6)
        a.xaxis.grid(True, color='#E7EAED', lw=.4)
        a.set_axisbelow(True)
        S.letter(a, l)
        a.text(1, 1.065, ds, transform=a.transAxes, ha='right', va='bottom', fontsize=8.)
        a.set_xlim((-.2, 1.75) if ds == 'D1' else (-1.7, 2.05))
        a.tick_params(axis='y', length=0, pad=5)

    fig.legend(
        handles=[
            Line2D([], [], marker='o', ls='', color='black', label='Development'),
            Line2D([], [], marker='o', ls='', color='black', mfc='white', label='Historical (held-out dates/substrates)'),
        ],
        ncol=2, loc='upper center', bbox_to_anchor=(.57, .99), frameon=False, fontsize=7.8
    )
    S.save(fig, 'Figure2', 'MAIN')


def draw_figure4_r2():
    """Standardize AEM/21 notation consistently with prose and captions."""
    S.style()
    plt.rcParams.update({'font.size': 8., 'axes.labelsize': 8., 'xtick.labelsize': 7.2, 'ytick.labelsize': 7.2})
    t = read_code('real_LP725_examples.csv')
    meta = read_code('real_LP725_example_metadata.csv')
    reg = read_sup('AEM_ALL_REGIONS.csv')
    sen = read_sup('AEM_SINGLE_POINT_FILTER.csv')
    fig, axs = plt.subplots(2, 2, figsize=(178 / 25.4, 129 / 25.4))
    fig.subplots_adjust(left=.10, right=.98, bottom=.13, top=.86, hspace=.66, wspace=.42)

    for a, sid, l in zip(axs[0], ['ACD', 'AEM'], 'ab'):
        q = meta[meta.substrate == sid]
        for _, r in q.iterrows():
            d = t[t.sample_id == r.sample_id]
            c = BLUE if r.extremum == 'highest_PCE' else ORANGE
            a.plot(d.frame_index, d.LP725_intensity, color=c, lw=1.05)
        a.set(xlim=(0, 718), ylim=(0, 4100), xlabel='Recorded frame', ylabel='LP725 intensity (a.u.)')
        a.set_yticks([0, 2000, 4000])
        a.set_xticks([0, 200, 400, 600])
        S.letter(a, l)
        a.text(1, 1.065, sid, transform=a.transAxes, ha='right', va='bottom', fontsize=8.)
        if sid == 'AEM':
            a.text(.98, .82, 'AEM/21 · PCE 0.455%\nPredicted rank 2/32', ha='right', va='top',
                   transform=a.transAxes, fontsize=7.)

    a = axs[1, 0]
    selected = reg.selected_top25.astype(bool)
    a.scatter(reg.PAIR_ABS_rank, reg.target, c=np.where(selected, BLUE, GRAY), s=15, lw=0, zorder=3)
    r = reg[reg.sample_id == 'D1::AEM::21'].iloc[0]
    a.scatter([r.PAIR_ABS_rank], [r.target], s=58, facecolor='none', edgecolor=ORANGE, lw=1.1, zorder=4)
    a.annotate('AEM/21', (r.PAIR_ABS_rank, r.target), xytext=(8, 2.2),
               arrowprops={'arrowstyle': '-', 'color': ORANGE, 'lw': .8}, fontsize=7.5)
    a.axvline(8.5, color=GRAY, lw=.55)
    original = sen[sen.scenario == 'ALL_REGIONS'].iloc[0]
    a.axhline(original.reference_mean, color='black', ls=(0, (3, 3)), lw=.65)
    a.set(xlim=(0, 33), ylim=(-.5, 15), xlabel='Predicted rank (1 = highest)', ylabel='Measured PCE (%)')
    a.set_xticks([1, 8, 16, 24, 32])
    a.set_yticks([0, 5, 10, 15])
    S.letter(a, 'c')
    a.text(1, 1.065, 'AEM · all 32 regions', transform=a.transAxes, ha='right', va='bottom', fontsize=8.)

    a = axs[1, 1]
    for i, scenario in enumerate(['ALL_REGIONS', 'POSTHOC_REMOVE_AEM_21']):
        q = sen[sen.scenario == scenario]
        r = q.iloc[0]
        c = BLUE if i == 0 else ORANGE
        a.plot([i, i], [0, r.gain_pp], color=c, lw=1.1)
        a.scatter([i], [r.gain_pp], color=c if i == 0 else 'white', edgecolor=c, s=35, lw=1.3, zorder=3)
        a.annotate(f'{r.gain_pp:+.3f}', (i, r.gain_pp), xytext=(0, 7),
                   textcoords='offset points', ha='center', fontsize=8.)
    a.set_xticks([0, 1], ['All regions\nn = 32; k = 8', 'Exclude AEM/21\nn = 31; k = 8'])
    a.tick_params(axis='x', labelsize=7.1, pad=6, length=0)
    a.set(xlim=(-.55, 1.55), ylim=(-.7, 1.1), ylabel='Top25% PCE enrichment (pp)')
    a.set_yticks([-.5, 0, .5, 1])
    a.axhline(0, color='black', ls=(0, (3, 3)), lw=.65)
    S.letter(a, 'd')
    a.text(1, 1.065, 'Post hoc exclusion', transform=a.transAxes, ha='right', va='bottom', fontsize=8.)

    fig.legend(
        handles=[Line2D([], [], color=BLUE, label='Higher-PCE trace'),
                 Line2D([], [], color=ORANGE, label='Lower-PCE trace')],
        ncol=2, loc='upper center', bbox_to_anchor=(.54, .99), frameon=False, fontsize=8.
    )
    S.save(fig, 'Figure4', 'MAIN')


def draw_figure_s2_r2():
    """Explicit dataset-accurate representation names in full SI comparison plate."""
    S.style()
    plt.rcParams.update({'font.size': 8., 'axes.labelsize': 8., 'xtick.labelsize': 7.2, 'ytick.labelsize': 7.2})
    fig, axs = plt.subplots(2, 2, figsize=(178 / 25.4, 183 / 25.4))
    fig.subplots_adjust(left=.265, right=.985, top=.935, bottom=.075, wspace=1.38, hspace=.26)
    for a, (ds, phase), l in zip(axs.flat, [('D1', 'development'), ('D1', 'historical'),
                                            ('D2', 'development'), ('D2', 'historical')], 'abcd'):
        d = pd.read_csv(ASSETS / f'DATA/CODE/SOURCE_DATA/P6/{ds.lower()}_macro_model_comparison.csv',
                        float_precision='round_trip')
        q = d[d.scope.str.contains('DEVELOPMENT' if phase == 'development' else
                                   'AUTHOR_TEST' if ds == 'D1' else 'HISTORY')].sort_values('model_id')
        labmap = D1_SHORT if ds == 'D1' else D2_SHORT
        for y, (_, r) in enumerate(q.iterrows()):
            c = color_of(r.model_id)
            a.errorbar(
                r.top25_gain_pp, y,
                xerr=[[r.top25_gain_pp - r.top25_gain_pp_ci95_low], [r.top25_gain_pp_ci95_high - r.top25_gain_pp]],
                fmt='o', color=c, mfc=c if phase == 'development' else 'white',
                ms=3, lw=.65, capsize=1.5
            )
        a.set_yticks(range(len(q)), [labmap[i] for i in q.model_id], fontsize=6.7)
        a.tick_params(axis='y', length=0, pad=4)
        a.set_ylim(len(q) - .5, -.8)
        a.set_xlabel('Top25% enrichment (pp)', fontsize=7.4)
        a.axvline(0, color=GRAY, lw=.6, ls='--')
        a.xaxis.grid(True, color='#E7EAED', lw=.4)
        a.set_axisbelow(True)
        S.letter(a, l)
        a.text(1, 1.065, ds + ' ' + ('development' if phase == 'development' else 'history'),
               transform=a.transAxes, ha='right', va='bottom', fontsize=8.)
    S.save(fig, 'FigureS2', 'SI')


def copy_unchanged_figures():
    for folder, names in [('MAIN', ['Figure3', 'Figure5']),
                          ('SI', ['FigureS1', 'FigureS3', 'FigureS4', 'FigureS5', 'FigureS6', 'FigureS7', 'FigureS8'])]:
        (FIGS / folder).mkdir(parents=True, exist_ok=True)
        for name in names:
            for ext in ['png', 'pdf', 'svg']:
                src = ASSETS / 'FIGURES' / folder / f'{name}.{ext}'
                if src.exists():
                    shutil.copy2(src, FIGS / folder / f'{name}.{ext}')


def main():
    draw_figure1_r2()
    draw_figure2_r2()
    draw_figure4_r2()
    draw_figure_s2_r2()
    copy_unchanged_figures()
    print('Built Figure1_Final, Figure2, Figure4, FigureS2 and copied remaining figures into', FIGS)


if __name__ == '__main__':
    main()
