"""Publication figure revision from archived CSVs and saved scores; no fitting."""
from pathlib import Path
import ast
import hashlib
import json
import shutil
import sys
sys.dont_write_bytecode=True
import os
ROOT=Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR']=str(ROOT/'RUN_RECEIPTS/mpl_cache')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle,FancyArrowPatch,FancyBboxPatch
from PIL import Image
from scipy.stats import spearmanr

BLUE,ORANGE,GRAY='#0072B2','#D55E00','#7C848C'
LIGHT,PALE,SLATE_SUB='#DDE2E7','#EAF3F8','black'
MAIN_DIR=ROOT/'FIGURES_MAIN'
R1=ROOT/'INPUTS/workflow'
PROVENANCE=[];GEOMETRY=[]
SEED=20261019
plt.rcParams.update({'font.family':'Arial','font.size':7.7,'axes.labelsize':7.7,
 'xtick.labelsize':7.,'ytick.labelsize':7.,'text.color':'black','axes.labelcolor':'black',
 'axes.titlecolor':'black','xtick.color':'black','ytick.color':'black','legend.labelcolor':'black',
 'axes.edgecolor':'black','axes.linewidth':.65,'axes.spines.top':False,'axes.spines.right':False,
 'xtick.major.width':.6,'ytick.major.width':.6,'xtick.major.size':2.5,'ytick.major.size':2.5,
 'pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'PL_MANUSCRIPT3_FIGURE_REVISION_20261120',
 'savefig.facecolor':'white','figure.facecolor':'white','axes.facecolor':'white','axes.unicode_minus':True})

def read(name):
    d=pd.read_csv(ROOT/'INPUTS'/name,float_precision='round_trip',dtype={'split_group':str})
    d['_row']=np.arange(len(d))+2;d.attrs['source']='INPUTS/'+name
    return d

def one(d,**filters):
    q=d
    for k,v in filters.items():q=q[q[k]==v]
    assert len(q)==1,(d.attrs.get('source'),filters,len(q))
    r=q.iloc[0].to_dict();r['_source']=d.attrs['source'];return r

def record(fig,panel,r,metric='gain',low='low',high='high'):
    source=r.get('_source','');factor=1.
    if source.endswith('recomputed_macro_metrics.csv'):columns=('top25_gain_pp','original_gain_CI_low','original_gain_CI_high')
    elif source.endswith('_macro_model_comparison.csv'):columns=('top25_gain_pp','top25_gain_pp_ci95_low','top25_gain_pp_ci95_high')
    elif source.endswith('centered/model_summary.csv'):columns=('top25_gain_pp','gain_ci95_low','gain_ci95_high')
    elif source.endswith('raw_control/MODEL_SUMMARY.csv'):columns=('gain_pp','gain_ci95_low','gain_ci95_high')
    elif source.endswith('V2_position_summary.csv'):columns=('delta','low','high')
    elif source.endswith('PAIRED_CTR_MINUS_RAW.csv'):columns=('mean_delta','ci95_low','ci95_high')
    elif source.endswith('paired_deltas_vs_p6.csv'):columns=('mean_delta','ci95_low','ci95_high')
    elif source.endswith('exp5_controlled_loss_ablation.csv'):columns=('top25_gain_pp','gain_ci95_low','gain_ci95_high')
    elif source.endswith('D2_ABLATION_MACRO.csv'):columns=('gain_pp','gain_pp_ci_low','gain_pp_ci_high')
    elif source.endswith('exp6_decision_utility_and_regret.csv'):columns=('mean_max_regret_pp','regret_ci95_low','regret_ci95_high')
    elif source.endswith('TRIAGE_MACRO_SUMMARY.csv'):
        columns=('recall_truth_top10','recall_truth_top10_ci_low','recall_truth_top10_ci_high') if fig=='FigureS9' else ('gain_pp','gain_pp_ci_low','gain_pp_ci_high')
        factor=100. if fig=='FigureS9' else 1.
    elif source.endswith('joint_macro.csv'):columns=('gain_pp','low','high')
    else:raise ValueError('Missing provenance column map: '+source)
    PROVENANCE.append({'figure':fig,'panel':panel,'source':r.get('_source',''),
        'source_row':r.get('_row',''),'dataset':r.get('dataset',''),'phase':r.get('phase',''),
        'method':r.get('model_id',r.get('method_id',r.get('model',''))),
        'metric':metric,'value':r[metric],'ci_low':r.get(low,np.nan),'ci_high':r.get(high,np.nan),
        'source_value_column':columns[0],'source_low_column':columns[1],'source_high_column':columns[2],'scale_factor':factor})

def save(fig,name,folder='MAIN',close=True):
    out=ROOT/('FIGURES_MAIN' if folder=='MAIN' else 'FIGURES_SI' if folder=='SI' else folder)
    out.mkdir(parents=True,exist_ok=True)
    fig.canvas.draw();renderer=fig.canvas.get_renderer();outside=[];nonblack=[]
    ghost_ticks=set()
    for ax in fig.axes:
        for axis in [ax.xaxis,ax.yaxis]:
            lo,hi=sorted(axis.get_view_interval())
            for tick in axis.get_major_ticks()+axis.get_minor_ticks():
                if tick.get_loc()<lo-1e-9 or tick.get_loc()>hi+1e-9:
                    ghost_ticks.update([tick.label1,tick.label2])
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text():continue
        if t in ghost_ticks:continue
        if matplotlib.colors.to_rgba(t.get_color())[:3]!=(0.,0.,0.):nonblack.append(t.get_text())
        if t.axes is not None and t.get_clip_on():continue
        b=t.get_window_extent(renderer)
        if b.x0<-.8 or b.y0<-.8 or b.x1>fig.bbox.width+.8 or b.y1>fig.bbox.height+.8:outside.append(t.get_text())
    GEOMETRY.append({'figure':name,'width_mm':fig.get_figwidth()*25.4,'height_mm':fig.get_figheight()*25.4,
                     'outside_text':outside,'nonblack_text':nonblack})
    for ext in ['pdf','svg','png']:
        kw={'dpi':600}
        if ext=='pdf':kw['metadata']={'Title':name,'Author':'Yutian Chen','CreationDate':None,'ModDate':None}
        fig.savefig(out/f'{name}.{ext}',**kw)
    fig.savefig(ROOT/'PREVIEWS'/f'{name}.png',dpi=170)
    if close:plt.close(fig)

def panel(ax,letter,context=''):
    ax.text(0,1.06,f'({letter})',transform=ax.transAxes,weight='bold',fontsize=10,va='bottom',color='black')
    if context:ax.text(1,1.06,context,transform=ax.transAxes,ha='right',va='bottom',fontsize=7.7,color='black')

def grid(ax):
    ax.xaxis.grid(True,color='#E7EAED',lw=.4);ax.set_axisbelow(True)

def dot(ax,x,y,lo,hi,color=BLUE,filled=True,marker='o',size=3.8):
    assert np.isfinite([x,lo,hi]).all() and lo<=x+1e-10 and hi>=x-1e-10,(x,lo,hi)
    ax.errorbar(x,y,xerr=[[max(0,x-lo)],[max(0,hi-x)]],fmt=marker,color=color,
                mfc=color if filled else 'white',mec=color,ms=size,lw=.85,capsize=1.8,zorder=3)

LEGACY=read('legacy/recomputed_macro_metrics.csv')
CENTERED=read('centered/model_summary.csv')
RAW=read('raw_control/MODEL_SUMMARY.csv')
EXP5=read('extensions/exp5_controlled_loss_ablation.csv')
REGRET=read('extensions/exp6_decision_utility_and_regret.csv')
TRIAGE=read('legacy/TRIAGE_MACRO_SUMMARY.csv')
POS=read('legacy/V2_position_summary.csv')
BLEND_DELTA=read('centered/paired_deltas_vs_p6.csv')
TARGET_DELTA=read('raw_control/PAIRED_CTR_MINUS_RAW.csv')
ABLATION=read('legacy/D2_ABLATION_MACRO.csv')
LABELS={}
tree=ast.parse((ROOT/'src/original_polish_figures.py').read_text(encoding='utf-8'))
for n in tree.body:
    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['D1_SHORT','D2_SHORT']:
        LABELS[n.targets[0].id[:2]]=ast.literal_eval(n.value)
for ds in LABELS:
    LABELS[ds].update({'TAB_CTR':'TabPFN · centered abs.','TAB_FUS':'Fixed fusion · absolute',
       'TAB_RAW':'TabPFN · raw targets','TAB_ID':'TabPFN · pos. + abs.','TAB_ID_FUS':'Fusion · pos. + abs.'})

def color(mid):
    return ORANGE if mid in ['ID_PAIRWISE','ID_PLUS_PL_PAIRWISE','ID_PRIOR','TAB_ID','TAB_ID_FUS'] or mid.endswith('_IDPL') else GRAY if mid in ['PL_INTENSITY','RANDOM_EXPECTATION'] else BLUE

def metric(ds,phase,mid):
    if mid in ['PAIR_ABS','ID_PAIRWISE','TAB_CTR','TAB_FUS']:
        name={'PAIR_ABS':'P6_PAIR_ABS','ID_PAIRWISE':'POSITION_PAIRWISE',
              'TAB_CTR':f'{ds}_TABPFN_CTR_ABS12','TAB_FUS':f'{ds}_TABPFN_CTR_ABS12_BLEND50_PAIR_ABS'}[mid]
        r=one(CENTERED,dataset=ds,phase=phase,method_id=name)
        r.update(gain=r['top25_gain_pp'],low=r['gain_ci95_low'],high=r['gain_ci95_high'])
    elif mid=='TAB_RAW':
        r=one(RAW,phase=phase,model='RAW');r.update(gain=r['gain_pp'],low=r['gain_ci95_low'],high=r['gain_ci95_high'])
    elif mid in ['TAB_ID','TAB_ID_FUS']:
        r=one(JOINT,phase=phase,model=mid);r.update(gain=r['gain_pp'],low=r['low'],high=r['high'])
    else:
        q=LEGACY[(LEGACY.dataset==ds)&(LEGACY.phase==phase)&(LEGACY.model_id==mid)]
        if len(q)==1:
            r=one(LEGACY,dataset=ds,phase=phase,model_id=mid)
            r.update(gain=r['top25_gain_pp'],low=r['original_gain_CI_low'],high=r['original_gain_CI_high'])
        else:
            table=read(f'legacy/{ds.lower()}_macro_model_comparison.csv')
            scope=('D1_DEVELOPMENT_PREVIOUSLY_ACCESSED' if phase=='development' else 'D1_AUTHOR_TEST_PREVIOUSLY_INSPECTED') if ds=='D1' else ('D2_DEVELOPMENT_REUSED_DATES' if phase=='development' else 'D2_HISTORY_PREVIOUSLY_INSPECTED')
            r=one(table,scope=scope,model_id=mid)
            r.update(gain=r['top25_gain_pp'],low=r['top25_gain_pp_ci95_low'],high=r['top25_gain_pp_ci95_high'])
    r.update(dataset=ds,phase=phase,model_id=mid)
    return r

def bootstrap(v):
    v=np.asarray(v,dtype=float);v=v[np.isfinite(v)]
    b=np.random.default_rng(SEED).choice(v,size=(10000,len(v)),replace=True).mean(axis=1)
    return float(v.mean()),*np.quantile(b,[.025,.975])

def unit_stats(g,score):
    ids=g.sample_id.astype(str).to_numpy();s=g[score].to_numpy(float);y=g.target.to_numpy(float)
    k=max(1,int(np.ceil(len(g)*.25)));p=np.lexsort((ids,-s))[:k];t=np.lexsort((ids,-y))[:k]
    rho=float(spearmanr(y,s).statistic) if np.unique(y).size>1 and np.unique(s).size>1 else np.nan
    return {'gain_pp':float(y[p].mean()-y.mean()),'rho':rho,'overlap':len(set(ids[p])&set(ids[t]))/k}

def prepare_joint():
    allp=read('extensions/tabpfn_predictions_part2.csv')
    p=allp[allp.method_id=='D2_TABPFN_CTR_IDPL44'].copy();assert len(p)==5857 and p.sample_id.is_unique
    rows=[];dates=[]
    for phase,filename in [('development','d2_dev_oof_predictions.csv'),('historical','d2_history_predictions.csv')]:
        base=read('extensions/'+filename)
        q=p[p.phase==phase][['sample_id','unit_id','split_group','score']].copy()
        assert set(q.sample_id)==set(base.sample_id)
        q=q.merge(base[['sample_id','target','PAIR_ABS','ID_PAIRWISE']],on='sample_id',validate='one_to_one')
        def z(col):return q.groupby('unit_id')[col].transform(lambda v:(v-v.mean())/max(float(v.std(ddof=0)),1e-12))
        q['fusion']=.5*z('score')+.5*z('PAIR_ABS')
        gs={}
        for mid,col in [('TAB_ID','score'),('TAB_ID_FUS','fusion'),('PAIR_ABS','PAIR_ABS'),('ID_PAIRWISE','ID_PAIRWISE')]:
            u=pd.DataFrame([{'unit_id':uid,'split_group':str(g.split_group.iloc[0]),**unit_stats(g,col)} for uid,g in q.groupby('unit_id',sort=True)])
            d=u.groupby('split_group',sort=True)[['gain_pp','rho','overlap']].mean();gs[mid]=d
            mean,lo,hi=bootstrap(d.gain_pp)
            rows.append({'phase':phase,'model':mid,'gain_pp':mean,'low':lo,'high':hi,
                         'rho':d.rho.mean(),'overlap':d.overlap.mean()})
        for date in gs['TAB_ID_FUS'].index:
            dates.append({'phase':phase,'split_group':date,
              'delta_vs_P6':gs['TAB_ID_FUS'].loc[date,'gain_pp']-gs['PAIR_ABS'].loc[date,'gain_pp'],
              'delta_vs_position':gs['TAB_ID_FUS'].loc[date,'gain_pp']-gs['ID_PAIRWISE'].loc[date,'gain_pp']})
    d=pd.DataFrame(rows);d.to_csv(ROOT/'PLOT_DATA/joint_macro.csv',index=False,float_format='%.17g')
    e=pd.DataFrame(dates);e.to_csv(ROOT/'PLOT_DATA/joint_dates.csv',index=False,float_format='%.17g')
    d['_row']=np.arange(len(d))+2;d.attrs['source']='PLOT_DATA/joint_macro.csv'
    original=read('extensions/tabpfn_results_summary_part2.csv')
    for _,r in d[d.model.isin(['TAB_ID','TAB_ID_FUS'])].iterrows():
        name='D2_TABPFN_CTR_IDPL44'+('_BLEND50_PAIR_ABS' if r.model=='TAB_ID_FUS' else '')
        old=one(original,phase=r.phase,method_id=name)
        assert abs(r.gain_pp-old['top25_gain_pp'])<1e-9
    return d,e

JOINT,JOINT_DATES=prepare_joint()

def figure2():
    fig=plt.figure(figsize=(178/25.4,130/25.4))
    axes=[fig.add_axes([.245,.13,.235,.73]),fig.add_axes([.755,.13,.235,.73])]
    ids=['PAIR_ABS','TAB_CTR','TAB_FUS','PL_PAIRWISE','LGBM_PL','EXTRATREES_PL','HISTGB_PL','RIDGE_PL','AUX','ID_PLUS_PL_PAIRWISE','ID_PAIRWISE','PL_INTENSITY']
    for ax,ds,letter in zip(axes,['D1','D2'],'ab'):
        mids=[('AUTHOR_KNN_AUX' if ds=='D1' else 'F2_RIDGE_AUX') if x=='AUX' else x for x in ids]
        ax.axhspan(-.45,2.45,color='#F0F6FA',zorder=0)
        for j,mid in enumerate(mids):
            for phase,offset in [('development',-.12),('historical',.12)]:
                r=metric(ds,phase,mid)
                marker='D' if mid=='TAB_FUS' else '^' if mid=='TAB_CTR' else 'o'
                dot(ax,r['gain'],j+offset,r['low'],r['high'],color(mid),phase=='development',marker,4.1 if mid=='TAB_FUS' else 3.5)
                record('Figure2',letter,r)
        ax.set_yticks(range(len(mids)),[LABELS[ds][m] for m in mids],fontsize=7.)
        ax.set_ylim(len(mids)-.5,-.65);ax.tick_params(axis='y',length=0,pad=4)
        ax.set_xlim((-.25,1.85) if ds=='D1' else (-1.7,2.15))
        ax.set_xlabel('Top25% PCE gain (pp)');ax.axvline(0,color=GRAY,ls='--',lw=.6);grid(ax);panel(ax,letter,ds)
    fig.legend(handles=[Line2D([],[],ls='',marker='o',color='black',label='Development'),
                        Line2D([],[],ls='',marker='o',color='black',mfc='white',label='History (previously viewed)')],
               loc='upper center',bbox_to_anchor=(.59,.99),ncol=2,frameon=False,fontsize=7.8)
    save(fig,'Figure2')

def figure3():
    fig,axs=plt.subplots(2,2,figsize=(178/25.4,137/25.4))
    fig.subplots_adjust(left=.23,right=.98,bottom=.12,top=.92,wspace=1.0,hspace=.65)
    ax=axs[0,0]
    for j,(ds,ph) in enumerate([('D1','development'),('D1','historical'),('D2','development'),('D2','historical')]):
        r=one(POS,dataset=ds,phase=ph);r.update(gain=r['delta'])
        dot(ax,r['delta'],j,r['low'],r['high'],BLUE if r['delta']>=0 else ORANGE,ph=='development')
        record('Figure3','a',r,'delta')
    ax.set_yticks(range(4),['D1 development','D1 history','D2 development','D2 history'])
    ax.set_ylim(3.5,-.5);ax.set_xlim(-.8,.8);ax.set_xticks([-.8,-.4,0,.4,.8])
    ax.set_xlabel('Position + optical − position (pp)',fontsize=7.2);ax.axvline(0,color=GRAY,ls='--',lw=.6);grid(ax);panel(ax,'a')
    ax=axs[0,1]
    labels=[]
    for j,(ds,name,contrast) in enumerate([
        ('D1','centering','CENTERED_RIDGE_MINUS_RAW_RIDGE'),('D1','pairwise','PAIRWISE_TOL05_MINUS_CENTERED_RIDGE'),
        ('D2','centering','CENTERED_RIDGE_MINUS_RAW_RIDGE'),('D2','pairwise','PAIRWISE_TOL05_MINUS_CENTERED_RIDGE')]):
        r=one(EXP5,dataset=ds,feature_set='ABS_12F',reg_mode='INNER_CV_TUNED',phase='development',objective='CONTRAST_'+contrast)
        r.update(gain=r['top25_gain_pp'],low=r['gain_ci95_low'],high=r['gain_ci95_high'])
        dot(ax,r['gain'],j,r['low'],r['high'],BLUE);record('Figure3','b',r);labels.append(ds+' · '+name)
    ax.set_yticks(range(4),labels);ax.set_ylim(3.5,-.5);ax.axvline(0,color=GRAY,ls='--',lw=.6)
    ax.set_xlim(-.1,.85);ax.set_xlabel('Controlled PCE gain increment (pp)',fontsize=7.2);grid(ax);panel(ax,'b')
    ax=axs[1,0]
    r=one(TARGET_DELTA,phase='development',metric='gain_pp');r.update(gain=r['mean_delta'],low=r['ci95_low'],high=r['ci95_high'])
    dot(ax,r['gain'],0,r['low'],r['high']);record('Figure3','c',r)
    for j,ds in enumerate(['D1','D2'],1):
        r=one(BLEND_DELTA,dataset=ds,phase='development',method_id=f'{ds}_TABPFN_CTR_ABS12_BLEND50_PAIR_ABS')
        r.update(gain=r['mean_delta'],low=r['ci95_low'],high=r['ci95_high'])
        dot(ax,r['gain'],j,r['low'],r['high'],BLUE,True,'D');record('Figure3','c',r)
    ax.set_yticks(range(3),['D2 · target centering','D1 · fixed fusion','D2 · fixed fusion'])
    ax.set_ylim(2.55,-.55);ax.set_xlim(-.12,.64);ax.set_xticks([-.1,0,.2,.4,.6]);ax.axvline(0,color=GRAY,ls='--',lw=.6)
    ax.set_xlabel('Paired PCE gain increment (pp)');grid(ax);panel(ax,'c')
    ax=axs[1,1]
    for j,(v,label) in enumerate([('FULL4','All statistics (12)'),('LEVEL8','Intensity level (8)'),('SLOPE4','Temporal slope (4)')]):
        r=one(ABLATION,scope='D2_DEVELOPMENT_REUSED_DATES',input_mode='OPTICAL_ONLY_REL',variant=v)
        r.update(gain=r['gain_pp'],low=r['gain_pp_ci_low'],high=r['gain_pp_ci_high'])
        dot(ax,r['gain'],j,r['low'],r['high']);record('Figure3','d',r)
    ax.set_yticks(range(3),['All statistics (12)','Intensity level (8)','Temporal slope (4)'])
    full=one(ABLATION,scope='D2_DEVELOPMENT_REUSED_DATES',input_mode='OPTICAL_ONLY_REL',variant='FULL4')['gain_pp']
    ax.axvline(full,color=GRAY,ls='--',lw=.6);ax.set_ylim(2.55,-.55);ax.set_xlim(.1,1.17)
    ax.set_xlabel('D2 Top25% PCE gain (pp)');grid(ax);panel(ax,'d')
    save(fig,'Figure3')

CURVE_STYLES={'PAIR_ABS':(BLUE,'o','-','Absolute ranker'),
              'ID_PAIRWISE':(ORANGE,'s','-','Position ranker'),
              'PL_INTENSITY':(GRAY,'^',(0,(4,2)),'Intensity rule'),
              'RANDOM_EXPECTATION':('black',None,(0,(1,2.5)),'Random selection')}

def curve_legend(fig,anchor=(.54,.99)):
    fig.legend(handles=[Line2D([],[],color=c,marker=m,ls=ls,lw=1.2,ms=3.4,label=label)
                        for c,m,ls,label in CURVE_STYLES.values()],
               ncol=4,loc='upper center',bbox_to_anchor=anchor,frameon=False,fontsize=7.2,
               columnspacing=1.,handlelength=1.8)

def gain_or_recall(ax,ds,metric_name,fig_name,panel_name):
    scope='D1_DEVELOPMENT_PREVIOUSLY_ACCESSED' if ds=='D1' else 'D2_DEVELOPMENT_REUSED_DATES'
    for mid,(c,marker,ls,lab) in CURVE_STYLES.items():
        d=TRIAGE[(TRIAGE.dataset==ds)&(TRIAGE.scope==scope)&(TRIAGE.model_id==mid)].sort_values('q')
        assert len(d)==9
        if metric_name=='gain':key,lo,hi,factor='gain_pp','gain_pp_ci_low','gain_pp_ci_high',1.
        else:key,lo,hi,factor='recall_truth_top10','recall_truth_top10_ci_low','recall_truth_top10_ci_high',100.
        ax.plot(d.q*100,d[key]*factor,color=c,marker=marker,ls=ls,lw=1.35 if mid=='PAIR_ABS' else .9,ms=3.2)
        if mid=='PAIR_ABS':ax.fill_between(d.q*100,d[lo]*factor,d[hi]*factor,color=BLUE,alpha=.09,lw=0)
        for _,row in d.iterrows():
            r=row.to_dict();r.update(_source=TRIAGE.attrs['source'],gain=row[key]*factor,low=row[lo]*factor,high=row[hi]*factor)
            record(fig_name,panel_name,r)
    ax.set_xlim(8,102);ax.set_xticks([10,25,50,75,100]);ax.axvline(25,color=GRAY,ls=':',lw=.6)
    ax.set_xlabel('Selected fraction, q (%)');ax.yaxis.grid(True,color='#E7EAED',lw=.4);ax.set_axisbelow(True)
    if metric_name=='gain':ax.set_ylabel('Mean PCE gain (pp)');ax.axhline(0,color='black',lw=.55,ls=':')
    else:ax.set_ylabel('True top-decile recall (%)');ax.set_ylim(0,103)

def figure5():
    fig,axs=plt.subplots(2,2,figsize=(178/25.4,127/25.4))
    fig.subplots_adjust(left=.105,right=.98,top=.85,bottom=.115,wspace=.38,hspace=.62)
    curve_legend(fig)
    for j,ds in enumerate(['D1','D2']):
        ax=axs[0,j];gain_or_recall(ax,ds,'gain','Figure5','ab'[j]);panel(ax,'ab'[j],ds)
        ax=axs[1,j]
        for mid,(c,marker,ls,lab) in CURVE_STYLES.items():
            source_mid='RANDOM_MC' if mid=='RANDOM_EXPECTATION' else mid
            d=REGRET[(REGRET.dataset==ds)&(REGRET.phase=='development')&(REGRET.model_id==source_mid)].sort_values('budget_q')
            assert len(d)==3,(ds,mid,len(d))
            ax.plot(d.budget_q*100,d.mean_max_regret_pp,color=c,marker=marker,ls=ls,lw=1.35 if mid=='PAIR_ABS' else .9,ms=3.2)
            if mid=='PAIR_ABS':ax.fill_between(d.budget_q*100,d.regret_ci95_low,d.regret_ci95_high,color=BLUE,alpha=.09,lw=0)
            for _,row in d.iterrows():
                r=row.to_dict();r.update(_source=REGRET.attrs['source'],gain=row.mean_max_regret_pp,low=row.regret_ci95_low,high=row.regret_ci95_high)
                record('Figure5','cd'[j],r)
        ax.set_xlabel('Selected fraction, q (%)');ax.set_ylabel('Champion regret (pp)')
        ax.set_xlim(8,52);ax.set_xticks([10,25,50]);ax.axvline(25,color=GRAY,ls=':',lw=.6)
        ax.yaxis.grid(True,color='#E7EAED',lw=.4);ax.set_axisbelow(True);ax.set_ylim(bottom=0);panel(ax,'cd'[j],ds)
    save(fig,'Figure5')

def figure_s9():
    fig,axs=plt.subplots(1,2,figsize=(178/25.4,83/25.4))
    fig.subplots_adjust(left=.105,right=.98,top=.77,bottom=.20,wspace=.38)
    curve_legend(fig)
    for ax,ds,l in zip(axs,['D1','D2'],'ab'):
        gain_or_recall(ax,ds,'recall','FigureS9',l);panel(ax,l,ds)
    save(fig,'FigureS9','SI')

def figure_s2():
    fig=plt.figure(figsize=(178/25.4,205/25.4))
    axes=[fig.add_axes([.285,.59,.20,.34]),fig.add_axes([.78,.59,.20,.34]),
          fig.add_axes([.285,.105,.20,.34]),fig.add_axes([.78,.105,.20,.34])]
    for ax,(ds,phase),letter in zip(axes,[('D1','development'),('D1','historical'),('D2','development'),('D2','historical')],'abcd'):
        original=read(f'legacy/{ds.lower()}_macro_model_comparison.csv')
        scope='D1_DEVELOPMENT_PREVIOUSLY_ACCESSED' if ds=='D1' and phase=='development' else 'D1_AUTHOR_TEST_PREVIOUSLY_INSPECTED' if ds=='D1' else 'D2_DEVELOPMENT_REUSED_DATES' if phase=='development' else 'D2_HISTORY_PREVIOUSLY_INSPECTED'
        mids=original[original.scope==scope].model_id.sort_values().tolist()
        mids=['PAIR_ABS','TAB_CTR','TAB_FUS']+[m for m in mids if m!='PAIR_ABS']
        if ds=='D2':mids.insert(1,'TAB_RAW');mids += ['TAB_ID','TAB_ID_FUS']
        for j,mid in enumerate(mids):
            r=metric(ds,phase,mid)
            dot(ax,r['gain'],j,r['low'],r['high'],color(mid),phase=='development',
                'D' if mid in ['TAB_FUS','TAB_ID_FUS'] else '^' if mid in ['TAB_CTR','TAB_ID'] else 'o',2.9)
            record('FigureS2',letter,r)
        ax.set_yticks(range(len(mids)),[LABELS[ds][m] for m in mids],fontsize=6.6)
        ax.tick_params(axis='y',length=0,pad=4);ax.set_ylim(len(mids)-.55,-.7)
        ax.set_xlim((-.4,1.95) if ds=='D1' else (-1.7,2.15));ax.axvline(0,color=GRAY,ls='--',lw=.55)
        ax.set_xlabel('Top25% PCE gain (pp)',fontsize=7.4);grid(ax);panel(ax,letter,ds+' '+('development' if phase=='development' else 'history'))
    save(fig,'FigureS2','SI')

def figure_s10():
    fig=plt.figure(figsize=(178/25.4,98/25.4))
    left=fig.add_axes([.235,.24,.24,.54]);right=fig.add_axes([.59,.24,.39,.54])
    mids=['PAIR_ABS','ID_PAIRWISE','TAB_ID','TAB_ID_FUS']
    for j,mid in enumerate(mids):
        for phase,offset in [('development',-.12),('historical',.12)]:
            r=metric('D2',phase,mid);dot(left,r['gain'],j+offset,r['low'],r['high'],color(mid),phase=='development','D' if mid=='TAB_ID_FUS' else 'o')
            record('FigureS10','a',r)
    left.set_yticks(range(4),['Absolute ranker','Position ranker','TabPFN · pos. + abs.','Fusion · pos. + abs.'])
    left.tick_params(axis='y',length=0,pad=4);left.set_ylim(3.5,-.5);left.set_xlim(.1,2.35)
    left.set_xlabel('Top25% PCE gain (pp)');grid(left);panel(left,'a')
    d=JOINT_DATES.copy();x=np.arange(len(d))
    bars=right.bar(x,d.delta_vs_P6,width=.72,color=ORANGE,edgecolor=ORANGE,lw=.8)
    for i,b in enumerate(bars):
        if d.phase.iloc[i]=='historical':b.set_facecolor('white')
    right.axhline(0,color='black',lw=.6);right.axvline(13.5,color=GRAY,ls=':',lw=.6)
    right.set_xticks(x,[s[4:6]+'/'+s[6:] for s in d.split_group],rotation=65,ha='right',fontsize=6.6)
    right.set_ylabel('Fusion − absolute ranker (pp)');right.yaxis.grid(True,color='#E7EAED',lw=.4);right.set_axisbelow(True);panel(right,'b')
    fig.legend(handles=[Line2D([],[],ls='',marker='o',color='black',label='Development'),
                        Line2D([],[],ls='',marker='o',color='black',mfc='white',label='History (previously viewed)')],
               ncol=2,loc='upper center',bbox_to_anchor=(.59,.99),frameon=False,fontsize=7.6)
    save(fig,'FigureS10','SI')

def figure1():
    source=(ROOT/'src/original_polish_figures.py').read_text(encoding='utf-8')
    tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='draw_figure1_r2')
    code=ast.get_source_segment(source,fn)
    code=code.replace("R1 / 'sources/", "R1 / '")
    start=code.index('    # Stage 3\n');end=code.index('    # Stage 4:',start)
    replacement='''    # Parallel predictors; target centering belongs only to the TabPFN branch.
    txt(91.7, 20.0, 'Parallel predictors', 6.4, 'bold', ha='center')
    rct(80, 27, 11.5, 12, BLUE, '#EEE6F6', .7)
    rct(93, 27, 11.5, 12, BLUE, '#EEE6F6', .7)
    txt(85.75, 29.4, 'Pairwise\\nranker', 5.8, ha='center')
    txt(98.75, 28.5, 'TabPFN', 5.8, 'bold', ha='center')
    txt(98.75, 32.6, 'Centered\\ntargets', 5.8, ha='center')
    ln([(77,45),(78.3,45),(78.3,24),(98.75,24)], BLUE, .65)
    arw((85.75,24),(85.75,27),BLUE,.65,ms=5)
    arw((98.75,24),(98.75,27),BLUE,.65,ms=5)
    ln([(85.75,39),(85.75,43),(98.75,43),(98.75,39)], BLUE, .65)
    arw((92,43),(92,48),BLUE,.7,ms=5)
    rct(80.8,48,22,7.0,BLUE,'#EEE6F6',.7)
    txt(91.8,50,'Fixed score fusion',6.2,'bold',ha='center')
    arw((92,55),(92,59.3),BLUE,.7,ms=5)
    for i,f in enumerate([1.,.77,.55,.32]):
        rct(81.5,61+i*3.1,20*f,1.8,c=BLUE if i<2 else GRAY,
            fill=BLUE if i<2 else '#C8CDD2',lw=0)
    txt(91.7,75.2,'Within-group order',6.2,ha='center')
    ln([(103,66),(108,66),(108,45)],BLUE,.8)
    arw((108,45),(111,45),BLUE,.95)

'''
    code=code[:start]+replacement+code[end:]
    code=code.replace("'Top-decile recall'","'Champion regret'")
    code=code.replace("    MAIN_DIR.mkdir(parents=True, exist_ok=True)\n    for ext in ['svg', 'pdf', 'png']:\n        fig.savefig(MAIN_DIR / f'Figure1_Final.{ext}', dpi=600)\n    plt.close(fig)","    save(fig, 'Figure1')")
    (ROOT/'src/revised_workflow_function.py').write_text(code,encoding='utf-8')
    ns=globals().copy();exec(code,ns);ns['draw_figure1_r2']()
    # The original function sets smaller typography; reset publication data-chart defaults.
    plt.rcParams.update({'font.size':7.7,'axes.labelsize':7.7,'xtick.labelsize':7.,'ytick.labelsize':7.})

def graphical_abstract():
    fig=plt.figure(figsize=(200/25.4,92/25.4));a=fig.add_axes([0,0,1,1]);a.set(xlim=(0,200),ylim=(92,0));a.axis('off')
    a.text(100,3,'Regional performance ranking from in situ optical monitoring',ha='center',va='top',fontsize=10.8,weight='bold',color='black')
    for x,c,fill,title in [(2,BLUE,'#E6F2FB','1  Optical monitoring'),(69,'#9478B2','#EEE6F6','2  Group-isolated analysis'),(136,'#BC9D79','#FFF0DF','3  D2 selection evidence')]:
        a.add_patch(FancyBboxPatch((x,13),62,77,boxstyle='round,pad=0,rounding_size=1.4',fc=fill,ec=c,lw=.8,zorder=0))
        a.text(x+31,16,title,ha='center',va='top',fontsize=8.5,weight='bold',color='black')
    im=Image.open(R1/'Optical_Acquisition_Selected.png');a.imshow(im,extent=(6,60,56,23),aspect='auto',zorder=1)
    a.text(33,59,'D1: LP725 PL',ha='center',va='top',fontsize=7.4,color='black')
    a.text(33,65,'D2: PL + reflection',ha='center',va='top',fontsize=7.4,color='black')
    for j,label in enumerate(['LP725','LP780','SP775','ND']):
        x=7+j*13
        a.add_patch(Rectangle((x,72),12,6,fc='#E6F2FB',ec=BLUE,lw=.7,zorder=2))
        a.text(x+6,74,label,ha='center',va='top',fontsize=6.4,color='black')
    a.text(33,83,'5,487 development regions',ha='center',va='top',fontsize=7.3,color='black')
    for x in [64.6,131.6]:a.add_patch(FancyArrowPatch((x,49),(x+3.8,49),arrowstyle='-|>',mutation_scale=6,color=BLUE,lw=.7,shrinkA=0,shrinkB=0))
    # Orthogonal graph: descriptors -> independent predictors -> individual
    # within-group score scaling -> fixed equal-weight fusion.
    internal_border='#9478B2'
    def box(x,y,w,h):
        a.add_patch(Rectangle((x,y),w,h,fc='#EEE6F6',ec=internal_border,lw=.75,zorder=2))
    def line(points):
        a.plot(*zip(*points),color=internal_border,lw=.7,solid_capstyle='butt',zorder=3)
    def arrow(x,y0,y1):
        a.add_patch(FancyArrowPatch((x,y0),(x,y1),arrowstyle='-|>',mutation_scale=6,color=internal_border,lw=.7,shrinkA=0,shrinkB=0,zorder=3))
    box(77,25,46,11)
    for row in range(2):
        for col in range(3):
            a.add_patch(Rectangle((80+col*2.6,27.7+row*2.7),1.9,1.9,fc='white',ec=internal_border,lw=.5,zorder=3))
    a.text(105,30.5,'Optical descriptors',ha='center',va='center',fontsize=7.3,color='black')
    line([(100,36),(100,40),(86,40)])
    line([(100,40),(117,40)])
    arrow(86,40,44);arrow(117,40,44)
    for x in [74,105]:box(x,44,24,18)
    # Two region tokens with an ordinal comparison; no decorative arrows.
    for x,label in [(79,'i'),(88.2,'j')]:
        a.add_patch(Rectangle((x,47),4.8,4.8,fc='white',ec=internal_border,lw=.6,zorder=3))
        a.text(x+2.4,49.4,label,ha='center',va='center',fontsize=6.3,color='black',zorder=4)
    a.text(86,49.4,'>',ha='center',va='center',fontsize=7.8,color='black',zorder=4)
    for row in range(2):
        for col in range(3):
            a.add_patch(Rectangle((113+col*2.8,46.5+row*2.6),2.1,1.8,fc='white',ec=internal_border,lw=.5,zorder=3))
    a.text(86,56,'Pairwise ranker',ha='center',va='center',fontsize=7,color='black')
    a.text(117,54.5,'TabPFN',ha='center',va='center',fontsize=7,color='black')
    a.text(117,59,'Centered targets',ha='center',va='center',fontsize=6.1,color='black')
    for center in [86,117]:
        line([(center,62),(center,74),(100,74)])
    a.text(101.5,70.5,'Score z-scaling',ha='center',va='center',fontsize=7.1,color='black')
    arrow(100,74,80)
    box(78,80,44,7)
    a.text(100,83.5,'Fixed 50/50 score fusion',ha='center',va='center',fontsize=7.1,color='black')
    # White result card separates quantitative marks from the orange panel.
    for j,w in enumerate([11,8,5]):
        a.add_patch(Rectangle((159,25+j*1.9),w,1.2,fc=BLUE if j<2 else GRAY,ec='none'))
    a.text(173,26,'Top25%',fontsize=7.1,va='center',color='black')
    a.add_patch(Rectangle((138.5,32),57.5,47,fc='white',ec='#CCD2D8',lw=.55,zorder=1))
    ax=fig.add_axes([.795,.25,.175,.39]);ax.set_facecolor('white')
    for j,mid in enumerate(['TAB_RAW','TAB_CTR','PAIR_ABS','TAB_FUS']):
        r=metric('D2','development',mid);dot(ax,r['gain'],j,r['low'],r['high'],ORANGE if mid=='TAB_FUS' else BLUE,True,'D' if mid=='TAB_FUS' else 'o',4.)
        record('Graphical_Abstract','selection',r)
    ax.set_yticks(range(4),['Raw targets','Centered targets','Pairwise ranker','Fixed fusion'],fontsize=7.3)
    ax.set_ylim(3.6,-.6);ax.set_xlim(0,1.25);ax.set_xticks([0,.5,1.]);ax.set_xlabel('Top25% PCE gain (pp)',fontsize=7.3)
    ax.xaxis.grid(True,color='#D2D7DD',lw=.55);ax.set_axisbelow(True)
    ax.tick_params(axis='x',labelsize=7.2)
    ax.tick_params(axis='y',length=0,pad=4)
    a.text(167,83,'14 dates · matched optical inputs',ha='center',va='top',fontsize=6.8,color='black')
    save(fig,'Graphical_Abstract','FIGURES_MAIN')

def copy_unchanged():
    for folder,names in [('MAIN',['Figure4']),('SI',['FigureS1','FigureS3','FigureS4','FigureS5','FigureS6','FigureS7','FigureS8'])]:
        destination=ROOT/('FIGURES_MAIN' if folder=='MAIN' else 'FIGURES_SI')
        for name in names:
            for ext in ['pdf','svg','png']:
                source=ROOT/'ORIGINAL_COPY'/folder/f'{name}.{ext}'
                if source.exists():shutil.copy2(source,destination/f'{name}.{ext}')
                else:assert (destination/f'{name}.{ext}').exists(),'Retain the delivered unchanged figure: '+name

def export_exp5_schema():
    contrasts=EXP5[EXP5.objective.str.startswith('CONTRAST_')].copy()
    models=EXP5[~EXP5.objective.str.startswith('CONTRAST_')].copy()
    contrasts=contrasts.rename(columns={'rho':'improved_groups','rho_ci95_low':'worsened_groups','rho_ci95_high':'tied_groups',
        'top25_gain_pp':'paired_delta_gain_pp','gain_ci95_low':'paired_ci_low','gain_ci95_high':'paired_ci_high'})
    assert len(models)==88 and len(contrasts)==100
    assert models.rho.dropna().between(-1,1).all()
    models.drop(columns=['_row']).to_csv(ROOT/'PLOT_DATA/controlled_model_results.csv',index=False,float_format='%.17g')
    contrasts.drop(columns=['_row']).to_csv(ROOT/'PLOT_DATA/controlled_paired_contrasts.csv',index=False,float_format='%.17g')

def main():
    copy_unchanged();export_exp5_schema()
    for fn in [figure1,figure2,figure3,figure5,figure_s2,figure_s9,figure_s10,graphical_abstract]:fn()
    pd.DataFrame(PROVENANCE).to_csv(ROOT/'PLOT_DATA/plotted_values.csv',index=False,float_format='%.17g')
    (ROOT/'RUN_RECEIPTS/geometry.json').write_text(json.dumps(GEOMETRY,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps([{'figure':x['figure'],'outside':x['outside_text'],'nonblack':x['nonblack_text']} for x in GEOMETRY],indent=2,ensure_ascii=False))

if __name__=='__main__':main()
