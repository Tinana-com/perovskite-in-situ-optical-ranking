"""Frozen P10-SUP figure plates. Reads bundled CSVs; no fitting or new predictions."""
from pathlib import Path
import hashlib
import json
import platform
import string
import sys
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator, PercentFormatter, StrMethodFormatter
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
INPUT = ROOT / 'INPUT'
OUT = ROOT / 'OUTPUT'
DATA = INPUT / 'DATA' / 'CODEX'
BLUE, ORANGE, GRAY = '#0072B2', '#D55E00', '#7C848C'
ACCENT, GRID = '#C65325', '#E7EAED'
SCOPES = {'D1': 'D1_DEVELOPMENT_PREVIOUSLY_ACCESSED', 'D2': 'D2_DEVELOPMENT_REUSED_DATES'}
HISTORY = 'D2_HISTORY_PREVIOUSLY_INSPECTED'
MODELS = ['PAIR_ABS', 'ID_PAIRWISE', 'PL_INTENSITY', 'RANDOM_EXPECTATION']
STYLES = {
    'PAIR_ABS': (BLUE, 'o', '-', 'Absolute pairwise'),
    'ID_PAIRWISE': (ORANGE, 's', '-', 'Position pairwise'),
    'PL_INTENSITY': (GRAY, '^', (0, (1, 1.8)), 'Intensity rule'),
    'RANDOM_EXPECTATION': ('black', None, (0, (1, 2.8)), 'Random expectation'),
}
NUMBERS, GEOMETRY, TESTS = [], [], []


def require(name, condition):
    if not condition:
        raise AssertionError(name)
    TESTS.append({'check': name, 'status': 'PASS'})


def read(name):
    df = pd.read_csv(DATA / name, float_precision='round_trip')
    df['_source_row'] = np.arange(len(df)) + 2  # physical CSV line, header is line 1
    df.attrs['source_csv'] = 'DATA/CODEX/' + name
    return df


def audit(df, figure, panel, metric, low=None, high=None, factor=1., transform='identity', note=''):
    for _, r in df.iterrows():
        value = float(r[metric]) * factor
        lo = float(r[low]) * factor if low else np.nan
        hi = float(r[high]) * factor if high else np.nan
        if transform == 'negate':
            value, lo, hi = -value, -hi, -lo
        pred = {k: str(r[k]) for k in ['dataset', 'scope', 'model_id', 'q', 'p_drop', 'variant',
                                     'input_mode', 'scenario', 'sample_id', 'frame_index',
                                     'method_a', 'method_b', 'metric'] if k in r}
        NUMBERS.append(dict(figure=figure, panel=panel, dataset=r.get('dataset', 'D1'),
                            cohort='history (previously inspected)' if 'HISTORY' in str(r.get('scope', ''))
                            else 'development (reused)', model=r.get('model_id', r.get('sample_id', '')),
                            scope=r.get('scope', SCOPES['D1']), source_csv=df.attrs['source_csv'],
                            source_row=int(r['_source_row']), source_row_predicate=json.dumps(pred, sort_keys=True),
                            source_metric=metric, source_CI_low=low or '', source_CI_high=high or '',
                            metric=metric, value=value, CI_low=lo, CI_high=hi,
                            scale_factor=factor, transform=transform, note=note))


def one(df, **filters):
    mask = np.ones(len(df), dtype=bool)
    for k, v in filters.items():
        mask &= np.isclose(df[k], v) if isinstance(v, float) else (df[k] == v)
    out = df.loc[mask].copy()
    if len(out) != 1:
        raise ValueError(f'Expected one source row: {filters}, got {len(out)}')
    return out


def style():
    plt.rcParams.update({
        'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
        'font.size': 8.2, 'axes.labelsize': 8.3, 'xtick.labelsize': 7.7, 'ytick.labelsize': 7.7,
        'legend.fontsize': 8., 'text.color': 'black', 'axes.labelcolor': 'black',
        'axes.edgecolor': 'black', 'xtick.color': 'black', 'ytick.color': 'black',
        'axes.linewidth': .65, 'xtick.major.width': .65, 'ytick.major.width': .65,
        'xtick.major.size': 3, 'ytick.major.size': 3,
        'axes.spines.top': False, 'axes.spines.right': False,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
        'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white',
        'svg.hashsalt': 'P10_SUP_FIGURES_R0', 'axes.unicode_minus': True,
    })


def letter(ax, label):
    ax.text(0, 1.075, f'({label})', transform=ax.transAxes, fontsize=10.5,
            fontweight='bold', va='bottom', ha='left', clip_on=False)


def axes_finish(ax, y_grid=True):
    if y_grid:
        ax.yaxis.grid(True, color=GRID, linewidth=.4)
    ax.set_axisbelow(True)
    ax.tick_params(pad=3)


def save(fig, name, folder):
    destination = OUT / folder / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    outside = []
    for txt in fig.findobj(matplotlib.text.Text):
        if not txt.get_visible() or not txt.get_text():
            continue
        # Tick artists outside the axis limits are not actually drawn.
        if txt.axes is not None and txt.get_clip_on():
            continue
        box = txt.get_window_extent(renderer)
        if box.x0 < -.8 or box.y0 < -.8 or box.x1 > fig.bbox.width + .8 or box.y1 > fig.bbox.height + .8:
            outside.append(txt.get_text())
    GEOMETRY.append(dict(figure=name, width_mm=fig.get_figwidth()*25.4,
                         height_mm=fig.get_figheight()*25.4, outside_canvas_text=outside))
    for suffix in ['pdf', 'svg', 'png']:
        opts = dict(dpi=600) if suffix == 'png' else {}
        if suffix == 'pdf':
            opts['metadata'] = {'Title': name, 'Author': 'Yutian Chen', 'CreationDate': None, 'ModDate': None}
        fig.savefig(destination.with_suffix('.'+suffix), **opts)
    plt.close(fig)


def legend_curves(fig):
    handles = []
    for m in MODELS:
        c, marker, ls, label = STYLES[m]
        handles.append(Line2D([], [], color=c, marker=marker, linestyle=ls,
                              markersize=3.8, linewidth=1.5 if m == 'PAIR_ABS' else 1., label=label))
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.53, .994),
               ncol=4, frameon=False, handlelength=2., handletextpad=.55, columnspacing=1.3)


def curves(df, metric_top, ci_top, metric_bottom, ci_bottom, name, culling=False):
    fig, axs = plt.subplots(2, 2, figsize=(178/25.4, 125/25.4))
    fig.subplots_adjust(left=.108, right=.98, bottom=.115, top=.86, hspace=.62, wspace=.40)
    legend_curves(fig)
    xcol = 'p_drop' if culling else 'q'
    for col, ds in enumerate(['D1', 'D2']):
        scope = SCOPES[ds]
        selected = df[(df.dataset == ds) & (df.scope == scope)]
        for row, metric, ci in [(0, metric_top, ci_top), (1, metric_bottom, ci_bottom)]:
            ax = axs[row, col]
            p = string.ascii_lowercase[row*2+col]
            letter(ax, p)
            text = ('D1 · 26 substrates' if ds == 'D1' else 'D2 · 14 dates / 158 experiments')
            if culling and row == 1:
                text = 'D1 · 8 low-PCE regions' if ds == 'D1' else 'D2 · 295 low-PCE regions'
            ax.text(1, 1.065, text, transform=ax.transAxes, ha='right', va='bottom', fontsize=8.)
            for model in MODELS:
                d = selected[selected.model_id == model].sort_values(xcol)
                if len(d) != (5 if culling else 9):
                    raise ValueError(f'Unexpected curve length {name} {ds} {model}')
                c, marker, ls, _ = STYLES[model]
                factor = 100. if row == 1 else 1.
                x, y = d[xcol].to_numpy()*100, d[metric].to_numpy()*factor
                ax.plot(x, y, color=c, linestyle=ls, marker=marker,
                        linewidth=1.65 if model=='PAIR_ABS' else 1., markersize=3.5,
                        markeredgewidth=.65, zorder=4 if model=='PAIR_ABS' else 3)
                audit(d, name, p, metric, *ci, factor=factor)
                if model == 'PAIR_ABS':
                    ax.fill_between(x, d[ci[0]].to_numpy()*factor, d[ci[1]].to_numpy()*factor,
                                    color=BLUE, alpha=.11, linewidth=0, zorder=1)
            ax.axvline(25, color='#A6ADB4', linewidth=.6, zorder=0)
            if row == 0:
                ax.axhline(0, color='black', linestyle=(0,(3,3)), linewidth=.6, zorder=1)
                ax.yaxis.set_major_locator(MaxNLocator(5))
                ax.yaxis.set_major_formatter(StrMethodFormatter('{x:.2f}' if culling else '{x:.1f}'))
                ax.set_ylabel('Kept-mean PCE enrichment (pp)' if culling else 'Mean PCE enrichment (pp)')
            else:
                ax.set_ylim(-3, 103)
                ax.set_yticks([0,25,50,75,100])
                ax.set_ylabel('Low-PCE recall, micro (%)' if culling else 'True top-decile recall (%)')
            ax.set_xticks([10,15,20,25,30] if culling else [10,25,50,75,100])
            ax.set_xlim((9,31) if culling else (7,103))
            ax.set_xlabel('Culled fraction, p (%)' if culling else 'Selected fraction, q (%)', labelpad=4)
            axes_finish(ax)
    save(fig, name, 'SI' if culling else 'MAIN')


def point_range(ax, d, labels, name, panel):
    for y, ((_, r), label) in zip(range(len(d)-1,-1,-1), zip(d.iterrows(), labels)):
        v, lo, hi = r.gain_pp, r.gain_pp_ci_low, r.gain_pp_ci_high
        ax.errorbar(v, y, xerr=[[v-lo],[hi-v]], fmt='o', color=BLUE,
                    markersize=4.4, linewidth=1.2, elinewidth=1., capsize=2.4, capthick=.8)
        ax.text(1.19, y, f'{v:.3f}', va='center', ha='right', fontsize=8.)
    ax.set_yticks(range(len(d)-1,-1,-1), labels)
    ax.tick_params(axis='y', length=0, pad=7)
    ax.set_ylim(-.55,len(d)-.45)
    ax.set_xlim(0,1.24)
    ax.set_xticks([0,.4,.8,1.2])
    ax.set_xlabel('Top25% PCE enrichment (pp)', labelpad=6)
    ax.xaxis.grid(True, color=GRID, linewidth=.4)
    ax.set_axisbelow(True)
    ax.spines['left'].set_visible(False)
    letter(ax, panel)
    audit(d, name, panel, 'gain_pp', 'gain_pp_ci_low', 'gain_pp_ci_high')


def information(abl, paired):
    name='Fig3_D2_Optical_Information_INSERT'
    d=abl[(abl.scope==SCOPES['D2']) & (abl.input_mode=='OPTICAL_ONLY_REL')]
    fig, axs = plt.subplots(1,2,figsize=(178/25.4,74/25.4))
    fig.subplots_adjust(left=.16,right=.98,bottom=.28,top=.84,wspace=.83)
    for ax, ids, labels, p in [
        (axs[0],['FULL4','PL3','ND1'],['PL + ND','PL only','ND only'],'a'),
        (axs[1],['FULL4','LEVEL8','SLOPE4'],['All summaries','Mean + final','Slopes'],'b')]:
        rows=pd.concat([one(d,variant=v) for v in ids]);rows.attrs=d.attrs.copy()
        point_range(ax, rows, labels,name,p)
    r=one(paired,scope=SCOPES['D2'],input_mode='OPTICAL_ONLY_REL',
          method_a='LEVEL8',method_b='SLOPE4',metric='gain_pp')
    a=r.iloc[0]
    footer=f'Slope − level: +{-a.value:.3f} pp (95% CI {-a.CI_high:.3f} to {-a.CI_low:.3f})'
    fig.text(.54,.06,footer,ha='center',fontsize=8.1)
    audit(r,name,'b','value','CI_low','CI_high',transform='negate',note='SLOPE4 minus LEVEL8; reverse archived contrast')
    save(fig,name,'MAIN')


def aem(a, sensitivity, trace):
    name='Fig4_AEM_Discordance_INSERT'
    fig=plt.figure(figsize=(178/25.4,87/25.4))
    ax=fig.add_axes([.09,.21,.44,.65]); bx=fig.add_axes([.70,.21,.27,.65])
    letter(ax,'a');letter(bx,'b')
    chosen=a.selected_top25.astype(bool)
    ax.scatter(a.loc[~chosen,'PAIR_ABS_rank'],a.loc[~chosen,'target'],color=GRAY,s=15,linewidth=0,zorder=3)
    ax.scatter(a.loc[chosen,'PAIR_ABS_rank'],a.loc[chosen,'target'],color=BLUE,s=18,linewidth=0,zorder=4)
    orig=one(sensitivity,scenario='ALL_REGIONS').iloc[0]
    ax.axhline(orig.reference_mean,color='black',linestyle=(0,(3,3)),linewidth=.7,zorder=1)
    ax.axvline(8.5,color='#A6ADB4',linewidth=.6,zorder=1)
    special=a[a.sample_id=='D1::AEM::21'].iloc[0]
    ax.scatter([special.PAIR_ABS_rank],[special.target],s=67,facecolor='none',edgecolor=ACCENT,linewidth=1.3,zorder=5)
    ax.annotate('AEM::21',(special.PAIR_ABS_rank,special.target),xytext=(8,2.3),
                arrowprops=dict(arrowstyle='-',color=ACCENT,lw=.85),fontsize=8.)
    ax.set(xlim=(0,33),ylim=(-.5,15),xlabel='Predicted rank (1 = highest)',ylabel='Measured PCE (%)')
    ax.set_xticks([1,8,16,24,32]);ax.set_yticks([0,5,10,15]);axes_finish(ax)
    audit(a,name,'a','target',note='x is archived PAIR_ABS_rank; all 32 regions retained')
    audit(a,name,'a','PAIR_ABS_rank')
    audit(sensitivity[sensitivity.scenario=='ALL_REGIONS'],name,'a','reference_mean',note='Dashed horizontal group mean')
    inset=ax.inset_axes([.50,.22,.46,.28])
    inset.plot(trace.frame_index,trace.LP725_raw,color=BLUE,lw=.8)
    inset.set(xlim=(0,718),ylim=(0,4000),xticks=[0,350,700],yticks=[0,4000])
    inset.set_xlabel('Frame index',fontsize=7.,labelpad=1)
    inset.set_ylabel('LP725 (a.u.)',fontsize=7.,labelpad=1)
    inset.tick_params(labelsize=6.8,length=2,pad=1)
    inset.spines['left'].set_linewidth(.5);inset.spines['bottom'].set_linewidth(.5)
    audit(trace,name,'a inset','LP725_raw',note='All 719 original frames; no smoothing or resampling')
    audit(trace,name,'a inset','frame_index')
    for i,scenario in enumerate(['ALL_REGIONS','POSTHOC_REMOVE_AEM_21']):
        d=one(sensitivity,scenario=scenario);r=d.iloc[0]
        color=BLUE if i==0 else ACCENT
        bx.plot([i,i],[0,r.gain_pp],color=color,linewidth=1.)
        bx.scatter([i],[r.gain_pp],color=color if i==0 else 'white',edgecolor=color,s=40,linewidth=1.4,zorder=4)
        bx.annotate(f'{r.gain_pp:+.3f}',(i,r.gain_pp),xytext=(0,8),textcoords='offset points',ha='center',fontsize=8.2)
        for metric in ['gain_pp','n','k','reference_mean','selected_mean']:
            audit(d,name,'b',metric,note='Post-hoc removal uses true PCE and changes selection pool/reference mean')
    bx.set_xticks([0,1],['All regions\nn = 32; k = 8','Remove AEM::21\nn = 31; k = 8'])
    bx.tick_params(axis='x',length=0,labelsize=7.7,pad=7)
    bx.set(xlim=(-.5,1.5),ylim=(-.75,1.12),ylabel='Top25% PCE enrichment (pp)')
    bx.set_yticks([-.5,0,.5,1.]);bx.axhline(0,color='black',lw=.6,linestyle=(0,(3,3)))
    bx.text(.5,1.045,'Outcome-conditioned sensitivity',transform=bx.transAxes,ha='center',fontsize=7.7)
    axes_finish(bx)
    handles=[Line2D([],[],marker='o',color=BLUE,ls='',label='Selected',markersize=4),
             Line2D([],[],marker='o',color=GRAY,ls='',label='Other regions',markersize=4),
             Line2D([],[],color='black',ls=(0,(3,3)),lw=.7,label='Group mean')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.31,.995),ncol=3,frameon=False,
               handlelength=1.6,columnspacing=1.2,fontsize=7.6)
    save(fig,name,'MAIN')


def si_ablation(abl,paired):
    name='FigS5_D2_ADDENDUM'
    ids=['FULL4','PL3','ND1','LEVEL8','SLOPE4']
    labels=['PL + ND','PL only','ND only','Mean + final','Slopes']
    fig,axs=plt.subplots(1,2,figsize=(178/25.4,92/25.4))
    fig.subplots_adjust(left=.155,right=.98,bottom=.24,top=.79,wspace=.76)
    for ax,scope,p in zip(axs,[SCOPES['D2'],HISTORY],['a','b']):
        for mi,mode in enumerate(['OPTICAL_ONLY_REL','POSITION_PLUS_OPTICAL_REL']):
            d=abl[(abl.scope==scope)&(abl.input_mode==mode)]
            for i,v in enumerate(ids):
                row=one(d,variant=v);r=row.iloc[0];y=4-i+(.115 if mi==0 else -.115)
                color,marker=(BLUE,'o') if mi==0 else (ORANGE,'s')
                face=color if p=='a' else 'white'
                ax.errorbar(r.gain_pp,y,xerr=[[r.gain_pp-r.gain_pp_ci_low],[r.gain_pp_ci_high-r.gain_pp]],
                            fmt=marker,color=color,markerfacecolor=face,markersize=4.,
                            elinewidth=.85,linewidth=.9,capsize=1.8,capthick=.7)
                audit(row,name,p,'gain_pp','gain_pp_ci_low','gain_pp_ci_high')
        ax.set_yticks(range(4,-1,-1),labels)
        ax.tick_params(axis='y',length=0,pad=5)
        ax.set_ylim(-.6,4.6)
        ax.set_xlabel('Top25% PCE enrichment (pp)',labelpad=6)
        ax.set_xlim((0,1.15) if p=='a' else (-.05,2.0))
        ax.set_xticks([0,.4,.8] if p=='a' else [0,.5,1.,1.5,2.])
        ax.spines['left'].set_visible(False);ax.xaxis.grid(True,color=GRID,lw=.4);ax.set_axisbelow(True)
        ax.text(.5,1.07,'Development · 14 dates' if p=='a' else 'Historical · 3 dates',
                transform=ax.transAxes,ha='center',fontsize=8.)
        letter(ax,p)
    handles=[Line2D([],[],color=BLUE,marker='o',lw=1.,label='Optical only (relative)',markersize=4),
             Line2D([],[],color=ORANGE,marker='s',lw=1.,label='Position + optical (relative)',markersize=4)]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.54,.995),ncol=2,
               frameon=False,columnspacing=2.,handlelength=1.8)
    r=one(paired,scope=HISTORY,input_mode='POSITION_PLUS_OPTICAL_REL',method_a='FULL4',
          method_b='ARCHIVED_ID_PAIRWISE',metric='gain_pp');a=r.iloc[0]
    fig.text(.53,.055,f'Historical FULL4 − position only: {a.value:+.3f} pp (95% CI {a.CI_low:.3f} to {a.CI_high:.3f})',
             ha='center',fontsize=7.9)
    audit(r,name,'b','value','CI_low','CI_high',note='Paired history contrast; three previously inspected dates')
    save(fig,name,'SI')


def validate_data(triage,cull,aem_df,sensitivity,trace,abl,paired):
    for ds,expected in [('D1',1.2415859047),('D2',.7790410510)]:
        v=one(triage,dataset=ds,scope=SCOPES[ds],model_id='PAIR_ABS',q=.25).gain_pp.iloc[0]
        require(ds+' Top25 gain',abs(v-expected)<1e-9)
        d=triage[(triage.dataset==ds)&(triage.scope==SCOPES[ds])]
        require(ds+' q100 gain definition',np.max(np.abs(d[d.q==1].gain_pp))<1e-10)
        require(ds+' q100 recall definition',np.allclose(d[d.q==1].recall_truth_top10,1))
    require('AEM 32 unique archived identities',len(aem_df)==32 and aem_df.sample_id.nunique()==32)
    require('AEM all archived ranks 1 to 32',sorted(aem_df.PAIR_ABS_rank)==list(range(1,33)))
    require('AEM selected quarter follows archived ranks',np.array_equal(aem_df.selected_top25,aem_df.PAIR_ABS_rank<=8))
    require('AEM full original trace',len(trace)==719 and np.array_equal(trace.frame_index,np.arange(719))
            and trace.sample_id.nunique()==1 and np.isfinite(trace.LP725_raw).all())
    for scenario,expected in [('ALL_REGIONS',-.423594),('POSTHOC_REMOVE_AEM_21',.824133)]:
        r=one(sensitivity,scenario=scenario).iloc[0]
        require('AEM gain '+scenario,abs(r.gain_pp-expected)<1e-6 and abs(r.selected_mean-r.reference_mean-r.gain_pp)<1e-12)
    for ds,den,inter in [('D1',8,4),('D2',295,88)]:
        r=one(cull,dataset=ds,scope=SCOPES[ds],model_id='PAIR_ABS',p_drop=.25).iloc[0]
        require(ds+' culling exact count ratio',r.micro_low_PCE_denominator==den and r.low_intercepted_total==inter
                and abs(r.micro_recall_low_pce-inter/den)<1e-12)
    d=abl[(abl.scope==SCOPES['D2'])&(abl.input_mode=='OPTICAL_ONLY_REL')]
    for var,expected in [('FULL4',.710010),('PL3',.711111),('ND1',.520903),('LEVEL8',.382363),('SLOPE4',.749338)]:
        r=one(d,variant=var).iloc[0]
        require('Matched D2 '+var,abs(r.gain_pp-expected)<1e-6 and r.n_independent_units==14 and r.n==4707 and r.n_experiments==158)
    r=one(paired,scope=SCOPES['D2'],input_mode='OPTICAL_ONLY_REL',method_a='LEVEL8',method_b='SLOPE4',metric='gain_pp').iloc[0]
    require('Paired dynamic contrast sign/bounds',abs(r.value+.366975)<1e-6 and r.CI_low<r.CI_high<0 and r.n_dates==14)


def contacts():
    files=sorted((OUT/'MAIN').glob('*.png'))+sorted((OUT/'SI').glob('*.png'))
    tiles=[]
    for f in files:
        im=Image.open(f).convert('RGB');im.thumbnail((1000,740),Image.Resampling.LANCZOS)
        tile=Image.new('RGB',(1040,800),'white');tile.paste(im,((1040-im.width)//2,40))
        ImageDraw.Draw(tile).text((20,15),f.stem,fill='black');tiles.append(tile)
    sheet=Image.new('RGB',(2080,800*3),'#e7eaed')
    for i,im in enumerate(tiles):sheet.paste(im,((i%2)*1040,(i//2)*800))
    sheet.save(OUT/'contact_sheet.png')


def main():
    style()
    triage=read('TRIAGE_MACRO_SUMMARY.csv');cull=read('CULLING_MACRO_MICRO.csv')
    aa=read('AEM_ALL_REGIONS.csv');ss=read('AEM_SINGLE_POINT_FILTER.csv');trace=read('AEM_PL_TRACE.csv')
    abl=read('D2_ABLATION_MACRO.csv');paired=read('D2_ABLATION_PAIRED_CONTRASTS.csv')
    validate_data(triage,cull,aa,ss,trace,abl,paired)
    curves(triage,'gain_pp',('gain_pp_ci_low','gain_pp_ci_high'),'recall_truth_top10',
           ('recall_truth_top10_ci_low','recall_truth_top10_ci_high'),'Fig5_MultiBudget_Champion_Selection')
    information(abl,paired);aem(aa,ss,trace)
    curves(cull,'kept_gain_pp',('kept_gain_pp_ci_low','kept_gain_pp_ci_high'),'micro_recall_low_pce',
           ('micro_recall_CI_low','micro_recall_CI_high'),'FigS_Culling_Diagnostics',True)
    si_ablation(abl,paired)
    pd.DataFrame(NUMBERS).to_csv(OUT/'figure_numbers.csv',index=False,float_format='%.17g')
    for g in GEOMETRY:
        require(g['figure']+' all text within canvas',not g['outside_canvas_text'])
    for p in list((OUT/'MAIN').glob('*.svg'))+list((OUT/'SI').glob('*.svg')):
        tree=ET.parse(p)
        require(p.stem+' vector SVG (no raster image)',not any(x.tag.endswith('}image') for x in tree.iter()))
        png=Image.open(p.with_suffix('.png'))
        require(p.stem+' PNG 600 dpi',abs(png.info['dpi'][0]-600)<.1)
    (OUT/'geometry_checks.json').write_text(json.dumps(GEOMETRY,indent=2),encoding='utf-8')
    (ROOT/'RUN_RECEIPTS/test_results.json').write_text(json.dumps({'passed':len(TESTS),'failed':0,'checks':TESTS},indent=2),encoding='utf-8')
    (ROOT/'RUN_RECEIPTS/environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),
      matplotlib=matplotlib.__version__,numpy=np.__version__,pandas=pd.__version__,font='Arial',dpi=600),indent=2),encoding='utf-8')
    contacts()
    print(f'Completed 5 plates / 15 exports; {len(NUMBERS)} numeric provenance entries; {len(TESTS)} checks passed')


if __name__=='__main__':
    main()
