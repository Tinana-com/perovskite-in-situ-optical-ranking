# Figure captions

**Figure 1.** Workflow from in situ optical monitoring to regional ranking and group-isolated evaluation. D1 uses LP725 PL; D2 uses three PL channels and ND diffuse reflection. Separately fitted pairwise and centered-target TabPFN scores enter fixed fusion, with position-only ranking as a control. The acquisition graphic is schematic; the small trajectory is measured D1 LP725 data.

**Figure 2.** Top25% PCE gain in (a) D1 and (b) D2. Filled/open symbols denote development/historical cohorts. Blue, orange and gray distinguish optical, position-containing and intensity models. Whiskers show descriptive 95% substrate/date-bootstrap intervals. Input definitions follow Table 1 and Methods; full comparisons appear in Figure S2.

**Figure 3.** (a) Matched optical increment over position. (b) Controlled target-centering and pairwise-learning increments on absolute descriptors. (c) TabPFN target-centering and fixed-fusion increments. (d) D2 relative optical statistics. Whiskers show 95% group-bootstrap intervals, paired in (a–c). Dashed guides indicate zero increment in (a–c) and the full-statistic reference in (d).

**Figure 4.** Original LP725 trajectories on (a) ACD and (b) AEM, with blue/orange identifying their higher-/lower-PCE examples. (c) All AEM regions ordered by out-of-fold score; blue points mark the selected eight and the ring identifies AEM/21. (d) Outcome-conditioned sensitivity to removing AEM/21. Trajectories retain all 719 frames and a common intensity scale.

**Figure 5.** Budget-dependent (a,b) mean selected PCE gain and (c,d) champion regret in D1 and D2. Shading shows the absolute ranker's 95% group-bootstrap interval. Markers denote evaluated budgets; vertical guides mark 25%. Random gain is analytic, while random regret averages 500 draws per comparison unit. Top-decile recall appears in Figure S9.

**Graphical abstract.** Optical monitoring, parallel prediction and regional selection. Score z-scaling is applied separately to each predictor before fixed equal-weight fusion. The right panel shows D2 development Top25% gain with 95% date-bootstrap intervals; the orange diamond highlights fusion. The acquisition illustration and model icons are schematic.

**Figure S1.** Development/historical region counts in (a) D1 and (b) D2, and outer-fold membership of (c) D1 substrates and (d) D2 dates. Numbers and shading identify fold indices; historical groups remain separate.

**Figure S2.** Complete comparisons for (a) D1 development, (b) D1 history, (c) D2 development and (d) D2 history. Blue denotes optical models, orange position-containing models and gray intensity/random references. Filled/open symbols denote development/history; whiskers show 95% group-bootstrap intervals. Tables S1–S4 identify the input configurations.

**Figure S3.** Absolute optical ranker gain for every (a) D1 development substrate and (b) D2 development date. Orange marks negative gain. D2 date means weight experiments equally.

**Figure S4.** Absolute optical ranker gain for all (a) D1 historical substrates and (b) D2 historical dates. Open bars identify history; orange marks negative gain.

**Figure S5.** D2 channel/statistic ablations in (a) development and (b) history. Blue circles denote relative optical ranking and orange squares its position-augmented counterpart. Whiskers show 95% date-bootstrap intervals; dashed guides mark position-only gain. Configurations appear in Table S5.

**Figure S6.** Matched optical increments over position for (a) D1 substrates and (b) D2 dates, with historical dates open. (c) Development increments of three exploratory extensions over the absolute ranker. Blue/orange identify positive/negative increments. Non-converged MiniRocket endpoints are described in the supplementary methods.

**Figure S7.** (a) Absolute, relative and combined optical representations. (b) D1 combined-input temporal-window and descriptor subsets. Window fractions refer to frame indices. D2 channel/statistic subsets appear in Figure S5.

**Figure S8.** (a,b) Retained-mean PCE gain after bottom-ranked culling and (c,d) pooled recall of regions below 2% PCE in D1 and D2. The low-PCE denominators are eight and 295, respectively. Shading shows the absolute ranker's 95% group-bootstrap interval.

**Figure S9.** True within-group top-decile recall across selection budgets in (a) D1 and (b) D2. Shading shows the absolute ranker's 95% group-bootstrap interval. Markers identify evaluated budgets; random expectations account for discrete group sizes.

**Figure S10.** (a) D2 absolute optical, position-only and position-plus-optical predictors. Filled/open symbols denote development/history; whiskers show 95% date-bootstrap intervals. (b) Paired date-level joint-fusion increment over the absolute optical ranker, including all 14 development and three historical dates. The historical dates are open; dates refer to 2023.
