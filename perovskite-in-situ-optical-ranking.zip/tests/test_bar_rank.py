"""Tests use tiny explicit numerical cases and the release's real optical excerpts."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import pytest
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'src'))
from bar_rank.core import center_targets,features,fuse_scores,fold_inputs,score_units
from dataset import Dataset

def scores():
    return pd.DataFrame({'sample_id':['a','b','c','d'],'unit_id':['u']*4,
        'split_group':['g']*4,'patchID':[11,12,13,14],'score':[1.,2.,3.,4.]})

def test_training_centering_zero_unit_means():
    f=pd.DataFrame({'unit_id':['a','a','b','b'],'target':[0.,2.,10.,14.]})
    y=center_targets(f);assert np.array_equal(y,[-1.,1.,-2.,2.])

def test_fixed_fusion_matches_components():
    a=scores();b=scores();q=fuse_scores(a,b)
    np.testing.assert_allclose(q.score,(a.score-a.score.mean())/a.score.std(ddof=0))

def test_fusion_constant_component_has_zero_z():
    a=scores();b=scores();b['score']=7.;q=fuse_scores(a,b)
    assert q.auxiliary_z.eq(0).all()

def test_fusion_identity_not_row_order():
    a=scores();q=fuse_scores(a,a.iloc[::-1]);np.testing.assert_allclose(q.pair_z,q.auxiliary_z)

@pytest.mark.parametrize('poison',['target','pce_mean','PCE_backward'])
def test_fusion_rejects_label_columns(poison):
    a=scores();a[poison]=1.
    with pytest.raises(ValueError,match='before label'):fuse_scores(a,scores())

def test_fusion_rejects_different_sample_cohorts():
    with pytest.raises(ValueError):fuse_scores(scores(),scores().iloc[:3])

def test_fusion_rejects_changed_identity():
    a=scores();a.loc[0,'patchID']=31
    with pytest.raises(ValueError,match='identity'):fuse_scores(a,scores())

@pytest.mark.parametrize('dataset',['D1','D2'])
@pytest.mark.parametrize('variant',['raw','centered'])
def test_validation_label_rewrite_invariance(dataset,variant):
    d=Dataset(B/'tests/fixtures',dataset);_,tr,ev=next(d.cases())
    first=fold_inputs(d,tr,ev,variant);d.labels.loc[d.labels.split_group.isin(ev),'target']=123456.
    second=fold_inputs(d,tr,ev,variant)
    for i in [0,1,2]:np.testing.assert_array_equal(first[i],second[i])
    pd.testing.assert_frame_equal(first[3],second[3])

@pytest.mark.parametrize('variant,dimension',[('joint',44),('relative-slope',4),('copula-slope',4)])
def test_frozen_d2_feature_dimensions(variant,dimension):
    d=Dataset(B/'tests/fixtures','D2');_,tr,ev=next(d.cases());a=fold_inputs(d,tr,ev,variant)
    assert a[0].shape[1]==dimension and np.isfinite(a[0]).all() and np.isfinite(a[2]).all()

def test_group_overlap_rejected():
    d=Dataset(B/'tests/fixtures','D1');_,tr,ev=next(d.cases())
    with pytest.raises(ValueError,match='overlap'):fold_inputs(d,tr|ev,ev,'centered')

def test_metric_ceil_budget_and_zero_pce_retained():
    a=scores().iloc[:3].copy();a['target']=[0.,2.,5.]
    row=score_units(a).iloc[0]
    assert row.n_regions==3 and row.gain_pp==pytest.approx(5-7/3) and row.overlap==1.

@pytest.mark.parametrize('representation,position',[('ABS',False),('ABS',True),('REL',False),('COPULA',False)])
def test_portable_features_match_archived_implementation(representation,position):
    import ast
    from scipy.stats import norm
    from bar_rank.core import CATEGORIES
    path=B/'archived_methods/extensions/run_pl_tabpfn_ubuntu.py'
    nodes=[n for n in ast.parse(path.read_text(encoding='utf-8')).body
           if isinstance(n,ast.FunctionDef) and n.name in ['rank_gaussian','build_features']]
    ns={'np':np,'pd':pd,'norm':norm,'CATEGORIES':CATEGORIES}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)
    d=Dataset(B/'tests/fixtures','D2');opt=d.optical();columns=d.spec['feature_names']
    expected,floor=ns['build_features'](opt,columns,representation,include_id=position)
    actual,actual_floor=features(opt,columns,representation,position)
    np.testing.assert_array_equal(expected,actual)
    if floor is not None:np.testing.assert_array_equal(floor,actual_floor)
