"""GPU replay of exactly two frozen configurations, with durable per-fold scores."""
from __future__ import annotations
import os
import sys
sys.dont_write_bytecode = True
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
for key in ['HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'TABPFN_DISABLE_TELEMETRY', 'TABPFN_NO_BROWSER']:
    os.environ[key] = '1'
for key in ['OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS']:
    os.environ[key] = '4'
os.environ['TABPFN_MODEL_CACHE_DIR'] = str(ROOT / 'cache/tabpfn')
os.environ['MPLCONFIGDIR'] = str(ROOT / 'cache/matplotlib')

import argparse
import gc
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import threading
import time
import traceback
import warnings
import numpy as np
import pandas as pd
import psutil
import torch
import frozen_original as ref

ref.DATA_DIR = Path('/home/ch/gemini_pl_tabpfn/data')
ref.CHECKPOINT = Path('/home/ch/tabpfn_leap_runs/AUX-TABPFN-LEAP-20261110-PHASE1/checkpoints/tabpfn-v3.5-20260909.safetensors')
torch.set_num_threads(4)
torch.set_num_interop_threads(1)

def sha(path):
    return hashlib.file_digest(open(path, 'rb'), 'sha256').hexdigest()

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding='utf-8')

def csv(path, df):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, float_format='%.17g', lineterminator='\n')

class Monitor:
    def __init__(self):
        self.stop = threading.Event()
        self.peak_rss = 0
        self.peak_private = 0
        self.min_available = float('inf')
        self.process = psutil.Process()
        self.worker = threading.Thread(target=self.sample, daemon=True)
    def sample(self):
        while not self.stop.is_set():
            m = self.process.memory_info()
            self.peak_rss = max(self.peak_rss, m.rss)
            self.peak_private = max(self.peak_private, getattr(m, 'private', 0))
            self.min_available = min(self.min_available, psutil.virtual_memory().available)
            self.stop.wait(1)
    def __enter__(self):
        self.worker.start()
        return self
    def __exit__(self, *args):
        self.stop.set()
        self.worker.join()
    def asdict(self):
        return {'peak_rss_bytes': self.peak_rss, 'peak_private_bytes': self.peak_private,
                'minimum_system_available_bytes': self.min_available}

def run_dataset(ds, max_folds=None):
    opt, lbl = ref.load_prepared(ds)
    assert opt.sample_id.is_unique and lbl.sample_id.is_unique
    assert opt.select_dtypes(include='number').shape[0] == len(opt)
    dev = lbl[lbl.role == 'development'].copy()
    history = lbl[lbl.role == 'history'].copy()
    assert len(dev) == {'D1': 780, 'D2': 4707}[ds]
    assert dev.split_group.nunique() == {'D1': 26, 'D2': 14}[ds]
    assert not set(dev.split_group) & set(history.split_group)
    assert not (dev.groupby('split_group').outer_fold.nunique() > 1).any()
    dev_groups = set(dev.split_group)
    columns = ref.D1_STATS if ds == 'D1' else ref.D2_STATS
    mid = f'{ds}_TABPFN_CTR_ABS12'
    folds = sorted(dev.outer_fold.unique()) + [-1]
    for i, fold in enumerate(folds):
        if max_folds is not None and i >= max_folds:
            break
        ph = 'historical' if fold == -1 else 'development'
        output = ROOT / 'results' / ds / f'{ph}_fold_{int(fold)}'
        if (output / 'receipt.json').exists():
            old = json.loads((output / 'receipt.json').read_text(encoding='utf-8'))
            assert old['prediction_sha256'] == sha(output / 'scores_before_labels.csv')
            assert old['source_sha256'] == sha(Path(__file__))
            print(f'RESUME verified {ds} {ph} fold {fold}', flush=True)
            continue
        output.mkdir(parents=True, exist_ok=True)
        ev_groups = set(history.split_group) if fold == -1 else set(dev.loc[dev.outer_fold == fold, 'split_group'])
        tr_groups = dev_groups if fold == -1 else dev_groups - ev_groups
        assert not tr_groups & ev_groups
        tr_opt = opt[opt.split_group.isin(tr_groups)].reset_index(drop=True)
        ev_opt = opt[opt.split_group.isin(ev_groups)].reset_index(drop=True)
        train = dev[dev.split_group.isin(tr_groups)].sort_values(['split_group','unit_id','sample_id']).reset_index(drop=True)
        # Evaluation labels are excluded from all input construction and prediction output.
        ev = opt.loc[opt.sample_id.isin((history if fold == -1 else dev).sample_id) & opt.split_group.isin(ev_groups), ref.KEYS]
        ev = ev.sort_values(['split_group','unit_id','sample_id']).reset_index(drop=True)
        tr_block, floor = ref.build_features(tr_opt, columns, 'ABS', include_id=False)
        ev_block, _ = ref.build_features(ev_opt, columns, 'ABS', include_id=False, floor=floor)
        x_train = pd.DataFrame(tr_block, index=tr_opt.sample_id).loc[train.sample_id].to_numpy(dtype=float)
        x_ev = pd.DataFrame(ev_block, index=ev_opt.sample_id).loc[ev.sample_id].to_numpy(dtype=float)
        y = (train.target - train.groupby('unit_id').target.transform('mean')).to_numpy(dtype=float)
        assert x_train.shape == (len(train),12) and x_ev.shape == (len(ev),12)
        assert np.isfinite(x_train).all() and np.isfinite(x_ev).all() and np.isfinite(y).all()
        assert np.max(np.abs(pd.Series(y).groupby(train.unit_id).mean())) < 1e-12
        training_hash = hashlib.sha256(x_train.tobytes() + y.tobytes()).hexdigest()
        write(output / 'identities.json', {'dataset': ds, 'method_id': mid, 'phase': ph, 'fold': int(fold),
              'training_groups': sorted(tr_groups), 'evaluation_groups': sorted(ev_groups),
              'training_ids': train.sample_id.tolist(), 'evaluation_ids': ev.sample_id.tolist(),
              'input_columns': columns, 'x_train_sha256': hashlib.sha256(x_train.tobytes()).hexdigest(),
              'centered_training_target_sha256': hashlib.sha256(y.tobytes()).hexdigest(),
              'x_evaluation_sha256': hashlib.sha256(x_ev.tobytes()).hexdigest(),
              'training_zero_targets': int((train.target == 0).sum()),
              'evaluation_labels_passed_to_predict': False})
        np.random.seed(ref.SEED)
        torch.manual_seed(ref.SEED)
        t0 = time.perf_counter()
        print(f'START {mid} {ph} fold={fold}: train={len(train)}, predict={len(ev)}', flush=True)
        torch.cuda.reset_peak_memory_stats()
        with Monitor() as monitor, warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            model = ref.TabPFNRegressor.create_default_for_version(
                ref.ModelVersion.V3_5, model_path=ref.CHECKPOINT, device='cuda',
                random_state=ref.SEED, n_estimators='auto', ignore_pretraining_limits=True,
                memory_saving_mode=True, n_preprocessing_jobs=1)
            write(output / 'requested_model_params.json', model.get_params(deep=False))
            model.fit(x_train, y)
            t_fit = time.perf_counter() - t0
            print(f'FIT {ds} fold={fold}: {t_fit:.1f}s', flush=True)
            score = []
            chunks = (len(ev)+63)//64
            for j, start in enumerate(range(0,len(ev),64)):
                # Save each chunk, so a disconnect never loses all completed predictions.
                chunk_file = output / 'chunks' / f'{j:04d}.csv'
                chunk = ev.iloc[start:start+64].copy()
                chunk['score'] = np.asarray(model.predict(x_ev[start:start+64]), dtype=float)
                assert np.isfinite(chunk.score).all()
                csv(chunk_file, chunk)
                score.extend(chunk.score.tolist())
                print(f'PREDICT {ds} fold={fold} chunk={j+1}/{chunks} elapsed={time.perf_counter()-t0:.1f}s', flush=True)
            ev['score'] = score
            ev['dataset'], ev['phase'], ev['method_id'], ev['outer_fold'] = ds, ph, mid, int(fold)
            csv(output / 'scores_before_labels.csv', ev)
            elapsed = time.perf_counter()-t0
            resolved = {'n_estimators_': getattr(model,'n_estimators_',None),
                        'inference_config_': str(getattr(model,'inference_config_',None)),
                        'model_class': type(model).__name__}
            gpu_peak_allocated = torch.cuda.max_memory_allocated()
            gpu_peak_reserved = torch.cuda.max_memory_reserved()
            del model
            gc.collect()
            torch.cuda.empty_cache()
        write(output / 'warnings.json', [{'type': type(w.message).__name__, 'message': str(w.message)} for w in caught])
        write(output / 'receipt.json', {'status':'COMPLETE','dataset':ds,'phase':ph,'fold':int(fold),
              'model_id':mid,'seed':ref.SEED,'training_input_hash':training_hash,
              'n_train':len(train),'n_predict':len(ev),'fit_seconds':t_fit,'wall_seconds':elapsed,
              **monitor.asdict(),'gpu_peak_allocated_bytes':gpu_peak_allocated,'gpu_peak_reserved_bytes':gpu_peak_reserved,'resolved':resolved,'source_sha256':sha(Path(__file__)),
              'prediction_sha256':sha(output / 'scores_before_labels.csv')})
        print(f'COMPLETE {ds} {ph} fold={fold} seconds={elapsed:.1f} peak_rss_GiB={monitor.peak_rss/1024**3:.2f}', flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset', choices=['D1','D2','both'],default='both')
    parser.add_argument('--max-folds', type=int)
    args=parser.parse_args()
    environment={'python':sys.version,'platform':platform.platform(),'logical_cores':psutil.cpu_count(),
                 'physical_cores':psutil.cpu_count(logical=False),'memory':psutil.virtual_memory()._asdict(),
                 'versions':{x:importlib.metadata.version(x) for x in ['tabpfn','torch','numpy','pandas','scipy','scikit-learn','psutil']},
                 'torch_threads':torch.get_num_threads(),'torch_interop_threads':torch.get_num_interop_threads(),
                 'cuda_available':torch.cuda.is_available(),'device':'cuda'}
    write(ROOT/'RUN_RECEIPTS/environment.json', environment)
    (ROOT/'requirements.lock.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True),encoding='utf-8')
    try:
        for ds in (['D1','D2'] if args.dataset=='both' else [args.dataset]):
            run_dataset(ds,args.max_folds)
    except BaseException:
        (ROOT/'logs'/f'failure_{time.time_ns()}.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise

if __name__=='__main__':
    main()
