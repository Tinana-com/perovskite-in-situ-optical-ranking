from __future__ import annotations
import sys
sys.dont_write_bytecode = True

import os
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TABPFN_DISABLE_TELEMETRY"] = "1"

import gc
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_pl_tabpfn_ubuntu as r1


def main():
    t_start = time.perf_counter()
    print(f"PART2 CUDA: {torch.cuda.is_available()}", flush=True)
    archived = r1.load_archived()
    arch_grp = {}
    for (ds, ph), df in archived.items():
        for mid in ["PAIR_ABS", "ID_PAIRWISE"]:
            gdf = r1.score_predictions(df.rename(columns={mid: "score"}), ds).set_index("split_group")["gain_pp"]
            arch_grp[(ds, ph, mid)] = gdf

    configs = [
        ("D2", "D2_TABPFN_CTR_SLOPE_REL4", r1.D2_SLOPE_STATS, "REL", False, True),
        ("D2", "D2_TABPFN_CTR_SLOPE_COPULA4", r1.D2_SLOPE_STATS, "COPULA", False, True),
        ("D2", "D2_TABPFN_CTR_IDPL44", r1.D2_STATS, "ABS", True, True),
    ]

    summary_rows = []
    oof_preds_all = []

    for ds, mid, feat_cols, rep, inc_id, center_target in configs:
        t0 = time.perf_counter()
        opt, lbl = r1.load_prepared(ds)
        dev_lbl = lbl[lbl["role"] == "development"].copy()
        hist_lbl = lbl[lbl["role"] == "history"].copy()
        dev_g = set(dev_lbl["split_group"].unique())
        hist_g = set(hist_lbl["split_group"].unique())
        folds = sorted(dev_lbl["outer_fold"].unique())

        preds = {"development": [], "historical": []}
        for fold in folds + [-1]:
            phase = "historical" if fold == -1 else "development"
            if fold == -1:
                tr_g, ev_g, ev_sub = dev_g, hist_g, hist_lbl
            else:
                ev_g = set(dev_lbl.loc[dev_lbl["outer_fold"] == fold, "split_group"])
                tr_g, ev_sub = dev_g - ev_g, dev_lbl

            tr_opt = opt[opt["split_group"].isin(tr_g)].reset_index(drop=True)
            ev_opt = opt[opt["split_group"].isin(ev_g)].reset_index(drop=True)
            tr_y = dev_lbl[dev_lbl["split_group"].isin(tr_g)].sort_values(["split_group", "unit_id", "sample_id"]).reset_index(drop=True)
            ev_y = ev_sub[ev_sub["split_group"].isin(ev_g)].sort_values(["split_group", "unit_id", "sample_id"]).reset_index(drop=True)

            tr_blk, fl = r1.build_features(tr_opt, feat_cols, rep, include_id=inc_id, floor=None)
            ev_blk, _ = r1.build_features(ev_opt, feat_cols, rep, include_id=inc_id, floor=fl)

            x_tr = pd.DataFrame(tr_blk, index=tr_opt["sample_id"]).loc[tr_y["sample_id"]].to_numpy(dtype=float)
            x_ev = pd.DataFrame(ev_blk, index=ev_opt["sample_id"]).loc[ev_y["sample_id"]].to_numpy(dtype=float)
            y_target = (tr_y["target"] - tr_y.groupby("unit_id")["target"].transform("mean")).to_numpy(dtype=float)

            np.random.seed(r1.SEED)
            torch.manual_seed(r1.SEED)
            model = r1.make_tabpfn()
            model.fit(x_tr, y_target)
            sc = r1.predict_chunked(model, x_ev, chunk_size=64)
            assert np.isfinite(sc).all()
            del model
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            out_df = ev_y[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
            out_df["score"] = np.asarray(sc, dtype=float)
            preds[phase].append(out_df)

        wall = time.perf_counter() - t0
        for ph in ["development", "historical"]:
            pdf = pd.concat(preds[ph], ignore_index=True)
            pdf_save = pdf.copy()
            pdf_save["dataset"] = ds
            pdf_save["phase"] = ph
            pdf_save["method_id"] = mid
            oof_preds_all.append(pdf_save)

            arch_df = archived[(ds, ph)][["sample_id", "PAIR_ABS"]].copy()
            m_df = pdf.merge(arch_df, on="sample_id", validate="one_to_one")
            m_df["blend_score"] = 0.5 * r1.within_unit_z(m_df, "PAIR_ABS") + 0.5 * r1.within_unit_z(m_df, "score")

            for variant_suffix, sc_col in [("", "score"), ("_BLEND50_PAIR_ABS", "blend_score")]:
                eval_df = m_df[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
                eval_df["score"] = m_df[sc_col]
                gdf = r1.score_predictions(eval_df, ds)
                g_m, g_lo, g_hi = r1.bootstrap_ci(gdf["gain_pp"])
                r_m, _, _ = r1.bootstrap_ci(gdf["rho"])
                o_m, _, _ = r1.bootstrap_ci(gdf["overlap"])
                gs = gdf.set_index("split_group")["gain_pp"]
                p_abs = r1.paired_bootstrap_ci(gs, arch_grp[(ds, ph, "PAIR_ABS")])
                p_id = r1.paired_bootstrap_ci(gs, arch_grp[(ds, ph, "ID_PAIRWISE")])
                summary_rows.append({
                    "dataset": ds,
                    "method_id": mid + variant_suffix,
                    "phase": ph,
                    "n_groups": int(len(gdf)),
                    "top25_gain_pp": g_m,
                    "gain_ci95_low": g_lo,
                    "gain_ci95_high": g_hi,
                    "rho": r_m,
                    "top25_overlap": o_m,
                    "neg_groups": int((gdf["gain_pp"] < -1e-12).sum()),
                    "delta_vs_PAIR_ABS": p_abs["mean_delta"],
                    "delta_vs_PAIR_ABS_ci_lo": p_abs["ci95_low"],
                    "delta_vs_PAIR_ABS_ci_hi": p_abs["ci95_high"],
                    "delta_vs_ID_PAIRWISE": p_id["mean_delta"],
                    "delta_vs_ID_ci_lo": p_id["ci95_low"],
                    "delta_vs_ID_ci_hi": p_id["ci95_high"],
                    "wall_seconds": wall,
                })
        r_dev = [x for x in summary_rows if x["method_id"] == mid and x["phase"] == "development"][0]
        r_hist = [x for x in summary_rows if x["method_id"] == mid and x["phase"] == "historical"][0]
        rb_dev = [x for x in summary_rows if x["method_id"] == mid + "_BLEND50_PAIR_ABS" and x["phase"] == "development"][0]
        rb_hist = [x for x in summary_rows if x["method_id"] == mid + "_BLEND50_PAIR_ABS" and x["phase"] == "historical"][0]
        print(
            f"[TabPFN] {mid:28s} ({wall:5.1f}s) | dev={r_dev['top25_gain_pp']:.3f} (blend={rb_dev['top25_gain_pp']:.3f}) "
            f"| hist={r_hist['top25_gain_pp']:.3f} (blend={rb_hist['top25_gain_pp']:.3f})",
            flush=True,
        )
        pd.DataFrame(summary_rows).to_csv(r1.WORK_DIR / "tabpfn_results_summary_part2.csv", index=False, float_format="%.12g", lineterminator="\n")

    pd.concat(oof_preds_all, ignore_index=True).to_csv(r1.WORK_DIR / "tabpfn_predictions_part2.csv", index=False, float_format="%.12g", lineterminator="\n")
    print(f"DONE PART2 in {time.perf_counter() - t_start:.1f}s", flush=True)


if __name__ == "__main__":
    main()
