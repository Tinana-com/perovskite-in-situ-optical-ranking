import sys
sys.dont_write_bytecode = True

import os
for _env_var in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"]:
    os.environ[_env_var] = "1"

from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

RESEARCH_ROOT = Path(r"D:\文档\ChatGPT\选题 2\research").resolve()
PROJECT_ROOT = RESEARCH_ROOT.parent
GEMINI_DIR = RESEARCH_ROOT / "gemini"
os.environ["NUMBA_CACHE_DIR"] = str(GEMINI_DIR / ".numba_cache")
os.environ["MPLCONFIGDIR"] = str(GEMINI_DIR / ".mplconfig")

CODE_RELEASE = RESEARCH_ROOT / "pl_spatial_ranking_manuscript_final" / "CODE_RELEASE"
SOURCE_P6 = CODE_RELEASE / "SOURCE_DATA" / "P6"
ANALYSIS_DIR = CODE_RELEASE / "ANALYSIS"

D1_H5_TRAIN = PROJECT_ROOT / "perovskite-ai-research" / "research" / "pl_public_data_pilot_01" / "data_external" / "D1" / "training_extracted_features_and_labels.h5"
D1_H5_TEST = PROJECT_ROOT / "perovskite-ai-research" / "research" / "pl_public_data_pilot_01" / "data_external" / "D1" / "test_extracted_features_and_labels.h5"
D2_H5_PATH = PROJECT_ROOT / "perovskite-ai-research" / "data" / "raw" / "kit_pl_2025" / "data.h5"
D2_FEATURES_PATH = RESEARCH_ROOT / "pl_public_data_pilot_02" / "results" / "extracted_features.csv"

P9_DIR = RESEARCH_ROOT / "pl_public_data_pilot_09_trajectory_ranking"

SEED = 20261019
BOOTSTRAP_REPLICATES = 10000
KEYS = ["sample_id", "unit_id", "split_group", "patchID"]
D2_CHANNELS = ["LP725", "LP780", "SP775", "ND"]
D2_F2 = [f"{ch}_{st}" for ch in D2_CHANNELS for st in ["mean", "last", "slope"]]
CATEGORIES = [
    11, 12, 13, 14, 21, 22, 23, 24,
    31, 32, 33, 34, 41, 42, 43, 44,
    51, 52, 53, 54, 61, 62, 63, 64,
    71, 72, 73, 74, 81, 82, 83, 84,
]
D2_DEV_DATES = [
    20230425, 20230502, 20230510, 20230516, 20230524, 20230531, 20230607,
    20230613, 20230627, 20230704, 20230717, 20230808, 20230816, 20230822,
]
D2_OUTER_FOLDS = [
    [20230425, 20230808],
    [20230502, 20230627],
    [20230510, 20230822],
    [20230516, 20230717],
    [20230524, 20230816],
    [20230531, 20230704],
    [20230607, 20230613],
]
D2_HIST_DATES = [20230829, 20230905, 20230912]


def top_k_count(n: int, fraction: float = 0.25, rounding: str = "ceil") -> int:
    if n < 1:
        raise ValueError("Empty group")
    if rounding == "floor":
        return int(np.floor(n * fraction))
    return max(1, int(np.ceil(n * fraction)))


def stable_order_indices(scores, sample_ids) -> np.ndarray:
    scores = np.asarray(scores, dtype=float)
    ids = np.asarray(sample_ids, dtype=str)
    if not np.isfinite(scores).all():
        raise ValueError("Nonfinite scores")
    return np.lexsort((ids, -scores))


def spearman_rho(y, s) -> float:
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    if len(y) < 2 or np.unique(y).size <= 1 or np.unique(s).size <= 1:
        return np.nan
    return float(spearmanr(s, y).statistic)


def group_metrics_basic(y, s, ids, fraction: float = 0.25) -> dict:
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    ids = np.asarray(ids, dtype=str)
    n = len(y)
    k = top_k_count(n, fraction=fraction, rounding="ceil")
    pi = stable_order_indices(s, ids)
    ti = stable_order_indices(y, ids)
    sel_ids = set(ids[pi[:k]])
    true_ids = set(ids[ti[:k]])
    k10 = top_k_count(n, fraction=0.10, rounding="ceil")
    true10_ids = set(ids[ti[:k10]])
    sel_mean = float(y[pi[:k]].mean())
    all_mean = float(y.mean())
    return {
        "n": n,
        "k": k,
        "k10": k10,
        "gain_pp": sel_mean - all_mean,
        "selected_mean": sel_mean,
        "all_mean": all_mean,
        "overlap": len(sel_ids & true_ids) / k,
        "top10_recall": len(sel_ids & true10_ids) / k10,
        "rho": spearman_rho(y, s),
    }


def bootstrap_ci(values, seed: int = SEED, replicates: int = BOOTSTRAP_REPLICATES) -> tuple[float, float, float]:
    vals = np.asarray(pd.Series(values).dropna(), dtype=float)
    if len(vals) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    boot = rng.choice(vals, size=(replicates, len(vals)), replace=True).mean(axis=1)
    lo, hi = np.quantile(boot, [0.025, 0.975])
    return float(vals.mean()), float(lo), float(hi)


def paired_bootstrap_ci(series_a: pd.Series, series_b: pd.Series, seed: int = SEED, replicates: int = BOOTSTRAP_REPLICATES) -> dict:
    diff = (series_a - series_b).dropna().sort_index()
    vals = diff.to_numpy(dtype=float)
    if len(vals) == 0:
        return {
            "n_groups": 0, "mean_delta": np.nan, "ci95_low": np.nan, "ci95_high": np.nan,
            "improved": 0, "worsened": 0, "tied": 0,
        }
    rng = np.random.default_rng(seed)
    boot = rng.choice(vals, size=(replicates, len(vals)), replace=True).mean(axis=1)
    lo, hi = np.quantile(boot, [0.025, 0.975])
    return {
        "n_groups": int(len(vals)),
        "mean_delta": float(vals.mean()),
        "ci95_low": float(lo),
        "ci95_high": float(hi),
        "improved": int((vals > 1e-12).sum()),
        "worsened": int((vals < -1e-12).sum()),
        "tied": int((np.abs(vals) <= 1e-12).sum()),
    }


def load_archived_predictions() -> dict[tuple[str, str], pd.DataFrame]:
    """Load frozen D1 and D2 prediction tables with full-precision D1 targets."""
    datasets = {}
    specs = [
        ("D1", "development", "d1_train_oof_predictions.csv", "d1_development_targets_full_precision.csv"),
        ("D1", "historical", "d1_author_test_predictions.csv", "d1_historical_targets_full_precision.csv"),
        ("D2", "development", "d2_dev_oof_predictions.csv", None),
        ("D2", "historical", "d2_history_predictions.csv", None),
    ]
    for ds, phase, pred_file, target_file in specs:
        df = pd.read_csv(SOURCE_P6 / pred_file, dtype={"split_group": str}, float_precision="round_trip")
        if target_file is not None:
            tf = pd.read_csv(SOURCE_P6 / target_file, float_precision="round_trip")
            df = df.merge(tf[["sample_id", "raw_target"]], on="sample_id", validate="one_to_one")
            df["target"] = df["raw_target"].to_numpy(dtype=float)
        datasets[(ds, phase)] = df
    return datasets


def evaluate_unit_to_group(unit_df: pd.DataFrame, dataset: str, metric_cols: list[str]) -> pd.DataFrame:
    """Aggregate selection units (D1 substrate or D2 date::expID) to independent groups (D1 substrate or D2 date)."""
    if dataset == "D1":
        return unit_df[["split_group"] + metric_cols].copy()
    return unit_df.groupby("split_group", sort=True)[metric_cols].mean().reset_index()


def verify_archived_baseline() -> None:
    """Verify exact numerical match against archived recomputed_macro_metrics.csv and V2_position_summary.csv."""
    datasets = load_archived_predictions()
    expected = pd.read_csv(ANALYSIS_DIR / "recomputed_macro_metrics.csv", float_precision="round_trip")
    v2 = pd.read_csv(ANALYSIS_DIR / "V2_position_summary.csv", float_precision="round_trip")
    max_err = 0.0
    for (ds, phase), df in datasets.items():
        for mid in ["PAIR_ABS", "PL_PAIRWISE", "ID_PAIRWISE", "ID_PLUS_PL_PAIRWISE", "PL_INTENSITY", "LGBM_PL"]:
            unit_rows = []
            for uid, g in df.groupby("unit_id", sort=True):
                m = group_metrics_basic(g["target"], g[mid], g["sample_id"], fraction=0.25)
                unit_rows.append({"unit_id": uid, "split_group": str(g["split_group"].iloc[0]), **m})
            udf = pd.DataFrame(unit_rows)
            gdf = evaluate_unit_to_group(udf, ds, ["gain_pp", "rho", "overlap"])
            exp_row = expected[(expected.dataset == ds) & (expected.phase == phase) & (expected.model_id == mid)].iloc[0]
            max_err = max(
                max_err,
                abs(gdf["gain_pp"].mean() - exp_row["top25_gain_pp"]),
                abs(gdf["rho"].dropna().mean() - exp_row["rho"]),
                abs(gdf["overlap"].mean() - exp_row["top25_overlap"]),
            )
            _, ci_lo, ci_hi = bootstrap_ci(gdf["gain_pp"])
            max_err = max(max_err, abs(ci_lo - exp_row["gain_CI_low"]), abs(ci_hi - exp_row["gain_CI_high"]))
    # Verify V2 position summary
    for (ds, phase), df in datasets.items():
        grp_metrics = {}
        for mid in ["ID_PAIRWISE", "ID_PLUS_PL_PAIRWISE"]:
            unit_rows = []
            for uid, g in df.groupby("unit_id", sort=True):
                m = group_metrics_basic(g["target"], g[mid], g["sample_id"], fraction=0.25)
                unit_rows.append({"unit_id": uid, "split_group": str(g["split_group"].iloc[0]), **m})
            gdf = evaluate_unit_to_group(pd.DataFrame(unit_rows), ds, ["gain_pp"]).set_index("split_group")["gain_pp"]
            grp_metrics[mid] = gdf
        res = paired_bootstrap_ci(grp_metrics["ID_PLUS_PL_PAIRWISE"], grp_metrics["ID_PAIRWISE"])
        vrow = v2[(v2.dataset == ds) & (v2.phase == phase)].iloc[0]
        max_err = max(max_err, abs(res["mean_delta"] - vrow["delta"]), abs(res["ci95_low"] - vrow["low"]), abs(res["ci95_high"] - vrow["high"]))
    assert max_err < 1e-10, f"Baseline verification failed: max_err={max_err}"
    print(f"[common.py] Verified archived metrics & bootstrap CIs: max_abs_err = {max_err:.3e}")
