from __future__ import annotations
import sys
sys.dont_write_bytecode = True

import os
import time
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.exceptions import ConvergenceWarning

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as cm

PREPARED_DIR = cm.RESEARCH_ROOT / "pl_spatial_ranking_training_release_v1" / "outputs" / "prepared_verified"
OUT_CSV = cm.GEMINI_DIR / "exp5_controlled_loss_ablation.csv"
OUT_PREDS_SUMMARY = cm.GEMINI_DIR / "exp5_inner_cv_selected_params.csv"

D1_STATS = [
    "mean", "std", "early10_mean", "late10_mean", "late_minus_early", "maximum",
    "argmax_relative_index", "relative_end_change", "middle50_mean",
    "relative_index_slope", "integral_frame_index", "total_abs_difference",
]
D2_STATS = cm.D2_F2
D2_SLOPE_STATS = [f"{ch}_slope" for ch in cm.D2_CHANNELS]


def load_prepared(dataset: str):
    d = PREPARED_DIR / dataset
    meta = pd.read_csv(d / "optical_identity.csv", dtype={"split_group": str}, float_precision="round_trip")
    lbl = pd.read_csv(d / "labels.csv", dtype={"split_group": str}, float_precision="round_trip")
    feats = np.load(d / "features.npz", allow_pickle=False)["FULL"]
    cols = D1_STATS if dataset == "D1" else D2_STATS
    assert len(meta) == len(feats)
    opt = meta.copy()
    for i, c in enumerate(cols):
        opt[c] = feats[:, i]
    return opt, lbl, cols


def compute_unit_weights(lbl: pd.DataFrame) -> np.ndarray:
    """Exact training_weights(y) from frozen P6 protocol (mean = 1.0)."""
    n_unit = lbl.groupby("unit_id")["unit_id"].transform("size").to_numpy(dtype=float)
    n_units_in_grp = lbl[["split_group", "unit_id"]].drop_duplicates().groupby("split_group").size()
    w = 1.0 / (n_unit * lbl["split_group"].map(n_units_in_grp).to_numpy(dtype=float) * lbl["split_group"].nunique())
    return w / w.mean()


def build_feature_block(opt_df: pd.DataFrame, feat_cols: list[str], rep: str, floor: np.ndarray | None = None):
    x_raw = opt_df[feat_cols].to_numpy(dtype=float)
    blocks = []
    if rep in ("ABS", "BOTH"):
        blocks.append(x_raw)
    if rep in ("REL", "BOTH"):
        if floor is None:
            floor = np.maximum(1e-12, 0.01 * np.median(np.abs(x_raw), axis=0))
        med = opt_df.groupby("unit_id", sort=False)[feat_cols].transform("median").to_numpy(dtype=float)
        mad = (opt_df[feat_cols] - med).abs().groupby(opt_df["unit_id"], sort=False).transform("median").to_numpy(dtype=float)
        blocks.append((x_raw - med) / np.maximum(1.4826 * mad, floor))
    return np.column_stack(blocks), floor


def build_matched_pairs(train_lbl: pd.DataFrame, x_tr: np.ndarray, w_tr: np.ndarray, dataset: str, tolerance: float, matched_unit_weight: bool = True):
    """Construct within-unit symmetric pairs with either matched unit weights or exact P6 pair weights."""
    train_lbl = train_lbl.reset_index(drop=True)
    total_w = float(w_tr.sum())  # == len(train_lbl) when mean=1

    # Step 1: Collect blocks per unit
    blocks = []
    for uid, g in train_lbl.groupby("unit_id", sort=True):
        g = g.sort_values("sample_id")
        idx = g.index.to_numpy()
        ii, jj = np.triu_indices(len(idx), 1)
        y_vals = g["target"].to_numpy(dtype=float)
        dy = y_vals[ii] - y_vals[jj]
        if tolerance == 0.0:
            keep = dy != 0.0
        elif dataset == "D1":
            keep = np.abs(dy) > tolerance
        else:
            keep = np.abs(dy) >= tolerance
        i = idx[ii[keep]]
        j = idx[jj[keep]]
        if len(i) == 0:
            continue
        tgt = (dy[keep] > 0).astype(int)
        unit_w_sum = float(w_tr[idx].sum())
        blocks.append((str(g["split_group"].iloc[0]), uid, x_tr[i] - x_tr[j], tgt, unit_w_sum))

    if matched_unit_weight:
        # Every unit gets exact same total pair weight sum == unit_w_sum (identical to Ridge effective unit weighting!)
        # If some unit had 0 usable pairs, renormalize total weight sum to total_w (= N_train) so penalty scale stays constant.
        active_unit_w = sum(b[4] for b in blocks)
        scale = total_w / active_unit_w if active_unit_w > 0 else 1.0
        xx, yy, ww = [], [], []
        for _, _, diff, tgt, unit_w_sum in blocks:
            n_dir = 2 * len(diff)
            w_pair = (unit_w_sum * scale) / n_dir
            xx.extend([diff, -diff])
            yy.extend([tgt, 1 - tgt])
            ww.extend([np.full(len(diff), w_pair), np.full(len(diff), w_pair)])
    else:
        # Exact P6/P5/P4 legacy weighting (for parity verification against frozen PAIR_ABS / PL_PAIRWISE)
        if dataset == "D1":
            n_subs = len(blocks)
            total_pairs = sum(2 * len(b[2]) for b in blocks)
            xx, yy, ww = [], [], []
            for _, _, diff, tgt, _ in blocks:
                w_pair = total_pairs / (n_subs * 2 * len(diff))
                xx.extend([diff, -diff])
                yy.extend([tgt, 1 - tgt])
                ww.extend([np.full(len(diff), w_pair), np.full(len(diff), w_pair)])
        else:
            exps_by_date = {}
            for sg, _, _, _, _ in blocks:
                exps_by_date[sg] = exps_by_date.get(sg, 0) + 1
            nd = len(exps_by_date)
            total_pairs = sum(2 * len(b[2]) for b in blocks)
            xx, yy, ww = [], [], []
            for sg, _, diff, tgt, _ in blocks:
                w_pair = total_pairs / (nd * exps_by_date[sg] * 2 * len(diff))
                xx.extend([diff, -diff])
                yy.extend([tgt, 1 - tgt])
                ww.extend([np.full(len(diff), w_pair), np.full(len(diff), w_pair)])
    return np.concatenate(xx), np.concatenate(yy), np.concatenate(ww)


def score_predictions(pred_df: pd.DataFrame, dataset: str) -> tuple[float, float, float, float, float, float]:
    urows = []
    for uid, g in pred_df.groupby("unit_id", sort=True):
        m = cm.group_metrics_basic(g["target"], g["score"], g["sample_id"], 0.25)
        urows.append({"unit_id": uid, "split_group": str(g["split_group"].iloc[0]), **m})
    udf = pd.DataFrame(urows)
    gdf = cm.evaluate_unit_to_group(udf, dataset, ["gain_pp", "rho", "overlap"])
    return gdf


def fit_and_predict_one(objective: str, hparam: float, tr_lbl: pd.DataFrame, x_tr: np.ndarray, w_tr: np.ndarray, ev_x: np.ndarray, dataset: str):
    if objective == "RAW_RIDGE":
        model = Ridge(alpha=hparam)
        model.fit(x_tr, tr_lbl["target"].to_numpy(dtype=float), sample_weight=w_tr)
        return model.predict(ev_x), True
    elif objective == "CENTERED_RIDGE":
        y_centered = (tr_lbl["target"] - tr_lbl.groupby("unit_id")["target"].transform("mean")).to_numpy(dtype=float)
        model = Ridge(alpha=hparam)
        model.fit(x_tr, y_centered, sample_weight=w_tr)
        return model.predict(ev_x), True
    elif objective in ("PAIRWISE_TOL00", "PAIRWISE_TOL05", "PAIRWISE_P6_PARITY"):
        tol = 0.0 if objective == "PAIRWISE_TOL00" else 0.5
        matched = objective != "PAIRWISE_P6_PARITY"
        xx, yy, ww = build_matched_pairs(tr_lbl, x_tr, w_tr, dataset, tolerance=tol, matched_unit_weight=matched)
        clf = LogisticRegression(random_state=cm.SEED, C=hparam, fit_intercept=False, solver="lbfgs", tol=1e-8, max_iter=5000)
        conv = True
        with warnings.catch_warnings(record=True) as wlog:
            warnings.simplefilter("always", ConvergenceWarning)
            clf.fit(xx, yy, sample_weight=ww)
        if any(issubclass(w.category, ConvergenceWarning) for w in wlog):
            conv = False
        return clf.decision_function(ev_x), conv
    else:
        raise ValueError(objective)


def prepare_fold_matrices(opt: pd.DataFrame, lbl: pd.DataFrame, feat_cols: list[str], rep: str, tr_groups: set[str], ev_groups: set[str]):
    tr_opt = opt[opt["split_group"].isin(tr_groups)].reset_index(drop=True)
    ev_opt = opt[opt["split_group"].isin(ev_groups)].reset_index(drop=True)
    sort_cols = ["split_group", "unit_id", "sample_id"]
    tr_lbl = lbl[lbl["split_group"].isin(tr_groups)].sort_values(sort_cols).reset_index(drop=True)
    ev_lbl = lbl[lbl["split_group"].isin(ev_groups)].sort_values(sort_cols).reset_index(drop=True)

    tr_blk, floor = build_feature_block(tr_opt, feat_cols, rep=rep, floor=None)
    scaler = StandardScaler().fit(tr_blk)
    tr_scaled = scaler.transform(tr_blk)
    ev_blk, _ = build_feature_block(ev_opt, feat_cols, rep=rep, floor=floor)
    ev_scaled = scaler.transform(ev_blk)

    tr_lookup = pd.DataFrame(tr_scaled, index=tr_opt["sample_id"])
    ev_lookup = pd.DataFrame(ev_scaled, index=ev_opt["sample_id"])
    x_tr = tr_lookup.loc[tr_lbl["sample_id"]].to_numpy(dtype=float)
    x_ev = ev_lookup.loc[ev_lbl["sample_id"]].to_numpy(dtype=float)
    w_tr = compute_unit_weights(tr_lbl)
    return tr_lbl, x_tr, w_tr, ev_lbl, x_ev


def run_exp5():
    t0 = time.perf_counter()
    archived = cm.load_archived_predictions()

    specs = [
        ("D1", "ABS_12F", D1_STATS, "ABS"),
        ("D1", "BOTH_24F", D1_STATS, "BOTH"),
        ("D2", "ABS_12F", D2_STATS, "ABS"),
        ("D2", "REL_12F", D2_STATS, "REL"),
        ("D2", "SLOPE_REL_4F", D2_SLOPE_STATS, "REL"),
    ]

    RIDGE_GRID = [0.01, 0.1, 1.0, 10.0, 100.0, 1000.0, 10000.0]
    PAIR_GRID = [0.0001, 0.001, 0.01, 0.1, 1.0, 10.0, 100.0]

    summary_rows = []
    inner_param_rows = []

    for ds, feat_set, feat_cols, rep in specs:
        opt, lbl, _ = load_prepared(ds)
        dev_lbl = lbl[lbl["role"] == "development"].copy()
        hist_lbl = lbl[lbl["role"] == "history"].copy()
        dev_groups_all = set(dev_lbl["split_group"].unique())
        hist_groups_all = set(hist_lbl["split_group"].unique())
        outer_fold_ids = sorted(dev_lbl["outer_fold"].unique())

        # Verify P6 parity for canonical configs on FULL dataset where archived exists
        parity_target = {
            ("D1", "ABS_12F"): "PAIR_ABS",
            ("D1", "BOTH_24F"): "PL_PAIRWISE",
            ("D2", "ABS_12F"): "PAIR_ABS",
            ("D2", "REL_12F"): "PL_PAIRWISE",
        }.get((ds, feat_set))

        objectives = [
            ("RAW_RIDGE", "DEFAULT", [10.0]),
            ("CENTERED_RIDGE", "DEFAULT", [10.0]),
            ("PAIRWISE_TOL00", "DEFAULT", [1.0]),
            ("PAIRWISE_TOL05", "DEFAULT", [1.0]),
            ("RAW_RIDGE", "INNER_CV_TUNED", RIDGE_GRID),
            ("CENTERED_RIDGE", "INNER_CV_TUNED", RIDGE_GRID),
            ("PAIRWISE_TOL00", "INNER_CV_TUNED", PAIR_GRID),
            ("PAIRWISE_TOL05", "INNER_CV_TUNED", PAIR_GRID),
        ]
        if parity_target is not None:
            objectives.append(("PAIRWISE_P6_PARITY", "DEFAULT", [1.0]))

        # Cache prepared fold matrices so every objective sees exact identical feature matrices & weights!
        outer_cache = {}
        for fold in outer_fold_ids:
            ev_g = set(dev_lbl.loc[dev_lbl["outer_fold"] == fold, "split_group"])
            tr_g = dev_groups_all - ev_g
            outer_cache[fold] = prepare_fold_matrices(opt, dev_lbl, feat_cols, rep, tr_g, ev_g)
        outer_cache[-1] = prepare_fold_matrices(opt, lbl, feat_cols, rep, dev_groups_all, hist_groups_all)

        # Cache inner fold matrices per outer case for nested hyperparameter selection
        inner_cache = {}
        for fold in outer_fold_ids + [-1]:
            if fold == -1:
                avail_folds = outer_fold_ids
                tr_pool = dev_groups_all
            else:
                ev_g = set(dev_lbl.loc[dev_lbl["outer_fold"] == fold, "split_group"])
                avail_folds = [f for f in outer_fold_ids if f != fold]
                tr_pool = dev_groups_all - ev_g
            ic = []
            for infold in avail_folds:
                iev_g = set(dev_lbl.loc[dev_lbl["outer_fold"] == infold, "split_group"])
                itr_g = tr_pool - iev_g
                ic.append(prepare_fold_matrices(opt, dev_lbl, feat_cols, rep, itr_g, iev_g))
            inner_cache[fold] = ic

        # Store per-group gain series for paired comparisons within each (ds, feat_set, regime, phase)
        grp_gain_store = {}

        for obj, reg_mode, grid in objectives:
            all_conv = True
            preds_dev = []
            preds_hist = []

            for fold in outer_fold_ids + [-1]:
                phase = "historical" if fold == -1 else "development"
                if reg_mode == "DEFAULT":
                    chosen_hp = grid[0]
                else:
                    # Strictly leakage-free inner CV on training pool only
                    best_gain = -np.inf
                    best_hp = grid[0]
                    # Prefer stronger regularization on exact ties:
                    # Ridge stronger = larger alpha; Pairwise stronger = smaller C.
                    ordered_grid = sorted(grid, reverse=obj.endswith("RIDGE"))
                    for hp in ordered_grid:
                        in_preds = []
                        for itr_lbl, ix_tr, iw_tr, iev_lbl, ix_ev in inner_cache[fold]:
                            sc_in, _ = fit_and_predict_one(obj, hp, itr_lbl, ix_tr, iw_tr, ix_ev, ds)
                            tmp = iev_lbl[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
                            tmp["score"] = sc_in
                            in_preds.append(tmp)
                        in_gdf = score_predictions(pd.concat(in_preds, ignore_index=True), ds)
                        mg = float(in_gdf["gain_pp"].mean())
                        if mg > best_gain + 1e-12:
                            best_gain = mg
                            best_hp = hp
                    chosen_hp = best_hp
                    inner_param_rows.append({
                        "dataset": ds, "feature_set": feat_set, "objective": obj,
                        "outer_fold": fold, "phase": phase, "chosen_hparam": chosen_hp,
                        "inner_cv_gain_pp": best_gain,
                    })

                tr_lbl, x_tr, w_tr, ev_lbl, x_ev = outer_cache[fold]
                sc_ev, conv = fit_and_predict_one(obj, chosen_hp, tr_lbl, x_tr, w_tr, x_ev, ds)
                all_conv = all_conv and conv
                out_df = ev_lbl[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
                out_df["score"] = sc_ev
                if phase == "development":
                    preds_dev.append(out_df)
                else:
                    preds_hist.append(out_df)

            for phase, plist in [("development", preds_dev), ("historical", preds_hist)]:
                pdf = pd.concat(plist, ignore_index=True)
                if obj == "PAIRWISE_P6_PARITY" and parity_target is not None:
                    arch = archived[(ds, phase)].set_index("sample_id")
                    max_diff = float(np.abs(pdf["score"].to_numpy() - arch.loc[pdf["sample_id"], parity_target].to_numpy()).max())
                    print(f"[PARITY] {ds} {feat_set} {phase} vs {parity_target}: max_abs_score_diff = {max_diff:.3e}")
                gdf = score_predictions(pdf, ds)
                g_m, g_lo, g_hi = cm.bootstrap_ci(gdf["gain_pp"])
                r_m, r_lo, r_hi = cm.bootstrap_ci(gdf["rho"])
                o_m, o_lo, o_hi = cm.bootstrap_ci(gdf["overlap"])
                grp_gain_store[(reg_mode, phase, obj)] = gdf.set_index("split_group")["gain_pp"]
                summary_rows.append({
                    "dataset": ds,
                    "feature_set": feat_set,
                    "n_features": int(x_tr.shape[1]),
                    "reg_mode": reg_mode,
                    "phase": phase,
                    "objective": obj,
                    "n_groups": int(len(gdf)),
                    "all_converged": bool(all_conv),
                    "top25_gain_pp": g_m,
                    "gain_ci95_low": g_lo,
                    "gain_ci95_high": g_hi,
                    "rho": r_m,
                    "rho_ci95_low": r_lo,
                    "rho_ci95_high": r_hi,
                    "top25_overlap": o_m,
                    "overlap_ci95_low": o_lo,
                    "overlap_ci95_high": o_hi,
                    "neg_groups": int((gdf["gain_pp"] < -1e-12).sum()),
                })

        # Compute clean paired contrasts: PAIRWISE_TOL05 vs RAW_RIDGE, PAIRWISE_TOL05 vs CENTERED_RIDGE, CENTERED_RIDGE vs RAW_RIDGE
        for reg_mode in ["DEFAULT", "INNER_CV_TUNED"]:
            for phase in ["development", "historical"]:
                for obj_a, obj_b in [
                    ("PAIRWISE_TOL05", "RAW_RIDGE"),
                    ("PAIRWISE_TOL05", "CENTERED_RIDGE"),
                    ("PAIRWISE_TOL00", "CENTERED_RIDGE"),
                    ("CENTERED_RIDGE", "RAW_RIDGE"),
                    ("PAIRWISE_TOL05", "PAIRWISE_TOL00"),
                ]:
                    sa = grp_gain_store[(reg_mode, phase, obj_a)]
                    sb = grp_gain_store[(reg_mode, phase, obj_b)]
                    p = cm.paired_bootstrap_ci(sa, sb)
                    summary_rows.append({
                        "dataset": ds,
                        "feature_set": feat_set,
                        "n_features": np.nan,
                        "reg_mode": reg_mode,
                        "phase": phase,
                        "objective": f"CONTRAST_{obj_a}_MINUS_{obj_b}",
                        "n_groups": p["n_groups"],
                        "all_converged": True,
                        "top25_gain_pp": p["mean_delta"],
                        "gain_ci95_low": p["ci95_low"],
                        "gain_ci95_high": p["ci95_high"],
                        "rho": float(p["improved"]),   # store improved count cleanly
                        "rho_ci95_low": float(p["worsened"]),
                        "rho_ci95_high": float(p["tied"]),
                        "top25_overlap": np.nan,
                        "overlap_ci95_low": np.nan,
                        "overlap_ci95_high": np.nan,
                        "neg_groups": p["worsened"],
                    })

        print(f"[exp5] Completed {ds} {feat_set} in {time.perf_counter() - t0:.1f}s", flush=True)

    pd.DataFrame(summary_rows).to_csv(OUT_CSV, index=False, float_format="%.12g", lineterminator="\n")
    pd.DataFrame(inner_param_rows).to_csv(OUT_PREDS_SUMMARY, index=False, float_format="%.12g", lineterminator="\n")
    print(f"[exp5] Saved {OUT_CSV} and {OUT_PREDS_SUMMARY} in {time.perf_counter() - t0:.1f}s")


if __name__ == "__main__":
    cm.verify_archived_baseline()
    run_exp5()
