from __future__ import annotations
import sys
sys.dont_write_bytecode = True

import os
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["TABPFN_DISABLE_TELEMETRY"] = "1"

import gc
import time
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm, spearmanr
import torch
from tabpfn import TabPFNRegressor
from tabpfn.constants import ModelVersion

SEED = 20261019
BOOTSTRAP_REPLICATES = 10000
KEYS = ["sample_id", "unit_id", "split_group", "patchID"]
D1_STATS = [
    "mean", "std", "early10_mean", "late10_mean", "late_minus_early", "maximum",
    "argmax_relative_index", "relative_end_change", "middle50_mean",
    "relative_index_slope", "integral_frame_index", "total_abs_difference",
]
D2_CHANNELS = ["LP725", "LP780", "SP775", "ND"]
D2_STATS = [f"{ch}_{st}" for ch in D2_CHANNELS for st in ["mean", "last", "slope"]]
D2_SLOPE_STATS = [f"{ch}_slope" for ch in D2_CHANNELS]
CATEGORIES = [
    11, 12, 13, 14, 21, 22, 23, 24,
    31, 32, 33, 34, 41, 42, 43, 44,
    51, 52, 53, 54, 61, 62, 63, 64,
    71, 72, 73, 74, 81, 82, 83, 84,
]

WORK_DIR = Path(__file__).resolve().parent
DATA_DIR = WORK_DIR / "data"
CHECKPOINT = Path("/home/ch/tabpfn_leap_runs/AUX-TABPFN-LEAP-20261110-PHASE1/checkpoints/tabpfn-v3.5-20260909.safetensors")


def top_k_count(n: int, fraction: float = 0.25) -> int:
    return max(1, int(np.ceil(n * fraction)))


def stable_order_indices(scores, sample_ids) -> np.ndarray:
    scores = np.asarray(scores, dtype=float)
    ids = np.asarray(sample_ids, dtype=str)
    return np.lexsort((ids, -scores))


def spearman_rho(y, s) -> float:
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    if len(y) < 2 or np.unique(y).size <= 1 or np.unique(s).size <= 1:
        return np.nan
    return float(spearmanr(s, y).statistic)


def group_metrics_basic(y, s, ids, fraction: float = 0.25) -> dict:
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    ids = np.asarray(ids, dtype=str)
    n = len(y)
    k = top_k_count(n, fraction=fraction)
    pi = stable_order_indices(s, ids)
    ti = stable_order_indices(y, ids)
    sel_ids = set(ids[pi[:k]])
    true_ids = set(ids[ti[:k]])
    return {
        "gain_pp": float(y[pi[:k]].mean() - y.mean()),
        "overlap": len(sel_ids & true_ids) / k,
        "rho": spearman_rho(y, s),
    }


def bootstrap_ci(values, seed: int = SEED, replicates: int = BOOTSTRAP_REPLICATES):
    vals = np.asarray(pd.Series(values).dropna(), dtype=float)
    if len(vals) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    boot = rng.choice(vals, size=(replicates, len(vals)), replace=True).mean(axis=1)
    lo, hi = np.quantile(boot, [0.025, 0.975])
    return float(vals.mean()), float(lo), float(hi)


def paired_bootstrap_ci(series_a: pd.Series, series_b: pd.Series, seed: int = SEED, replicates: int = BOOTSTRAP_REPLICATES):
    diff = (series_a - series_b).dropna().sort_index()
    vals = diff.to_numpy(dtype=float)
    rng = np.random.default_rng(seed)
    boot = rng.choice(vals, size=(replicates, len(vals)), replace=True).mean(axis=1)
    lo, hi = np.quantile(boot, [0.025, 0.975])
    return {
        "n_groups": int(len(vals)),
        "mean_delta": float(vals.mean()),
        "ci95_low": float(lo),
        "ci95_high": float(hi),
        "improved": int((vals > 1e-12).sum()),
        "worsened": int((vals < -1e-12).sum()),
    }


def evaluate_unit_to_group(unit_df: pd.DataFrame, dataset: str) -> pd.DataFrame:
    if dataset == "D1":
        return unit_df[["split_group", "gain_pp", "rho", "overlap"]].copy()
    return unit_df.groupby("split_group", sort=True)[["gain_pp", "rho", "overlap"]].mean().reset_index()


def score_predictions(pred_df: pd.DataFrame, dataset: str) -> pd.DataFrame:
    urows = []
    for uid, g in pred_df.groupby("unit_id", sort=True):
        m = group_metrics_basic(g["target"], g["score"], g["sample_id"], 0.25)
        urows.append({"unit_id": uid, "split_group": str(g["split_group"].iloc[0]), **m})
    return evaluate_unit_to_group(pd.DataFrame(urows), dataset)


def load_prepared(dataset: str):
    d = DATA_DIR / "prepared_verified" / dataset
    meta = pd.read_csv(d / "optical_identity.csv", dtype={"split_group": str}, float_precision="round_trip")
    lbl = pd.read_csv(d / "labels.csv", dtype={"split_group": str}, float_precision="round_trip")
    feats = np.load(d / "features.npz", allow_pickle=False)["FULL"]
    cols = D1_STATS if dataset == "D1" else D2_STATS
    opt = meta.copy()
    for i, c in enumerate(cols):
        opt[c] = feats[:, i]
    return opt, lbl


def load_archived():
    specs = [
        ("D1", "development", "d1_train_oof_predictions.csv", "d1_development_targets_full_precision.csv"),
        ("D1", "historical", "d1_author_test_predictions.csv", "d1_historical_targets_full_precision.csv"),
        ("D2", "development", "d2_dev_oof_predictions.csv", None),
        ("D2", "historical", "d2_history_predictions.csv", None),
    ]
    arch = {}
    for ds, ph, pf, tf in specs:
        df = pd.read_csv(DATA_DIR / "archived_p6" / pf, dtype={"split_group": str}, float_precision="round_trip")
        if tf is not None:
            tdf = pd.read_csv(DATA_DIR / "archived_p6" / tf, float_precision="round_trip")
            df = df.merge(tdf[["sample_id", "raw_target"]], on="sample_id", validate="one_to_one")
            df["target"] = df["raw_target"].to_numpy(dtype=float)
        arch[(ds, ph)] = df
    return arch


def rank_gaussian(opt_df: pd.DataFrame, feat_cols: list[str]) -> np.ndarray:
    out = np.zeros((len(opt_df), len(feat_cols)), dtype=float)
    for _, idx in opt_df.groupby("unit_id", sort=False).groups.items():
        idx_arr = np.asarray(list(idx), dtype=int)
        n = len(idx_arr)
        for j, col in enumerate(feat_cols):
            vals = opt_df.iloc[idx_arr][col].to_numpy(dtype=float)
            ranks = pd.Series(vals).rank(method="average").to_numpy(dtype=float)
            u = (ranks - 0.375) / (n + 0.25)
            out[idx_arr, j] = norm.ppf(np.clip(u, 1e-4, 1.0 - 1e-4))
    return out


def build_features(opt_df: pd.DataFrame, feat_cols: list[str], rep: str, include_id: bool = False, floor: np.ndarray | None = None):
    x_raw = opt_df[feat_cols].to_numpy(dtype=float)
    blocks = []
    if include_id:
        cats = np.asarray(CATEGORIES)
        blocks.append((opt_df["patchID"].to_numpy()[:, None] == cats[None, :]).astype(float))
    if rep in ("ABS", "BOTH"):
        blocks.append(x_raw)
    if rep in ("REL", "BOTH"):
        if floor is None:
            floor = np.maximum(1e-12, 0.01 * np.median(np.abs(x_raw), axis=0))
        med = opt_df.groupby("unit_id", sort=False)[feat_cols].transform("median").to_numpy(dtype=float)
        mad = (opt_df[feat_cols] - med).abs().groupby(opt_df["unit_id"], sort=False).transform("median").to_numpy(dtype=float)
        blocks.append((x_raw - med) / np.maximum(1.4826 * mad, floor))
    if rep == "COPULA":
        blocks.append(rank_gaussian(opt_df, feat_cols))
    return np.column_stack(blocks), floor


def make_tabpfn():
    return TabPFNRegressor.create_default_for_version(
        ModelVersion.V3_5,
        model_path=CHECKPOINT,
        device="cuda",
        random_state=SEED,
        n_estimators="auto",
        ignore_pretraining_limits=True,
        memory_saving_mode=True,
        n_preprocessing_jobs=1,
    )


def predict_chunked(model, x_ev: np.ndarray, chunk_size: int = 64) -> np.ndarray:
    preds = []
    for start in range(0, len(x_ev), chunk_size):
        preds.append(np.asarray(model.predict(x_ev[start:start + chunk_size]), dtype=float))
    return np.concatenate(preds, axis=0)


def within_unit_z(df: pd.DataFrame, col: str) -> np.ndarray:
    s = df.groupby("unit_id")[col].transform(lambda x: (x - x.mean()) / max(float(x.std(ddof=0)), 1e-12))
    return s.to_numpy(dtype=float)


def main():
    t_start = time.perf_counter()
    print(f"CUDA available: {torch.cuda.is_available()}, device count: {torch.cuda.device_count()}", flush=True)
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}", flush=True)

    archived = load_archived()
    arch_grp = {}
    for (ds, ph), df in archived.items():
        for mid in ["PAIR_ABS", "ID_PAIRWISE"]:
            gdf = score_predictions(df.rename(columns={mid: "score"}), ds).set_index("split_group")["gain_pp"]
            arch_grp[(ds, ph, mid)] = gdf

    configs = [
        ("D1", "D1_TABPFN_RAW_ABS12", D1_STATS, "ABS", False, False),
        ("D1", "D1_TABPFN_CTR_ABS12", D1_STATS, "ABS", False, True),
        ("D1", "D1_TABPFN_CTR_REL12", D1_STATS, "REL", False, True),
        ("D1", "D1_TABPFN_CTR_COPULA12", D1_STATS, "COPULA", False, True),
        ("D1", "D1_TABPFN_CTR_BOTH24", D1_STATS, "BOTH", False, True),
        ("D1", "D1_TABPFN_CTR_IDPL44", D1_STATS, "ABS", True, True),
        ("D2", "D2_TABPFN_RAW_ABS12", D2_STATS, "ABS", False, False),
        ("D2", "D2_TABPFN_CTR_ABS12", D2_STATS, "ABS", False, True),
        ("D2", "D2_TABPFN_CTR_REL12", D2_STATS, "REL", False, True),
        ("D2", "D2_TABPFN_CTR_COPULA12", D2_STATS, "COPULA", False, True),
        ("D2", "D2_TABPFN_CTR_SLOPE_REL4", D2_SLOPE_STATS, "REL", False, True),
        ("D2", "D2_TABPFN_CTR_SLOPE_COPULA4", D2_SLOPE_STATS, "COPULA", False, True),
        ("D2", "D2_TABPFN_CTR_IDPL44", D2_STATS, "ABS", True, True),
    ]

    summary_rows = []
    oof_preds_all = []

    for ds, mid, feat_cols, rep, inc_id, center_target in configs:
        t0 = time.perf_counter()
        opt, lbl = load_prepared(ds)
        dev_lbl = lbl[lbl["role"] == "development"].copy()
        hist_lbl = lbl[lbl["role"] == "history"].copy()
        dev_g = set(dev_lbl["split_group"].unique())
        hist_g = set(hist_lbl["split_group"].unique())
        folds = sorted(dev_lbl["outer_fold"].unique())

        preds = {"development": [], "historical": []}
        for fold in folds + [-1]:
            phase = "historical" if fold == -1 else "development"
            if fold == -1:
                tr_g, ev_g, ev_sub = dev_g, hist_g, hist_lbl
            else:
                ev_g = set(dev_lbl.loc[dev_lbl["outer_fold"] == fold, "split_group"])
                tr_g, ev_sub = dev_g - ev_g, dev_lbl

            tr_opt = opt[opt["split_group"].isin(tr_g)].reset_index(drop=True)
            ev_opt = opt[opt["split_group"].isin(ev_g)].reset_index(drop=True)
            tr_y = dev_lbl[dev_lbl["split_group"].isin(tr_g)].sort_values(["split_group", "unit_id", "sample_id"]).reset_index(drop=True)
            ev_y = ev_sub[ev_sub["split_group"].isin(ev_g)].sort_values(["split_group", "unit_id", "sample_id"]).reset_index(drop=True)

            tr_blk, fl = build_features(tr_opt, feat_cols, rep, include_id=inc_id, floor=None)
            ev_blk, _ = build_features(ev_opt, feat_cols, rep, include_id=inc_id, floor=fl)

            x_tr = pd.DataFrame(tr_blk, index=tr_opt["sample_id"]).loc[tr_y["sample_id"]].to_numpy(dtype=float)
            x_ev = pd.DataFrame(ev_blk, index=ev_opt["sample_id"]).loc[ev_y["sample_id"]].to_numpy(dtype=float)
            if center_target:
                y_target = (tr_y["target"] - tr_y.groupby("unit_id")["target"].transform("mean")).to_numpy(dtype=float)
            else:
                y_target = tr_y["target"].to_numpy(dtype=float)

            np.random.seed(SEED)
            torch.manual_seed(SEED)
            model = make_tabpfn()
            model.fit(x_tr, y_target)
            sc = predict_chunked(model, x_ev, chunk_size=64)
            assert np.isfinite(sc).all()
            del model
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            out_df = ev_y[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
            out_df["score"] = np.asarray(sc, dtype=float)
            preds[phase].append(out_df)

        wall = time.perf_counter() - t0
        for ph in ["development", "historical"]:
            pdf = pd.concat(preds[ph], ignore_index=True)
            pdf_save = pdf.copy()
            pdf_save["dataset"] = ds
            pdf_save["phase"] = ph
            pdf_save["method_id"] = mid
            oof_preds_all.append(pdf_save)

            # Evaluate standalone TabPFN AND 50/50 within-unit z-score blend with archived PAIR_ABS
            arch_df = archived[(ds, ph)][["sample_id", "PAIR_ABS"]].copy()
            m_df = pdf.merge(arch_df, on="sample_id", validate="one_to_one")
            m_df["blend_score"] = 0.5 * within_unit_z(m_df, "PAIR_ABS") + 0.5 * within_unit_z(m_df, "score")

            for variant_suffix, sc_col in [("", "score"), ("_BLEND50_PAIR_ABS", "blend_score")]:
                eval_df = m_df[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
                eval_df["score"] = m_df[sc_col]
                gdf = score_predictions(eval_df, ds)
                g_m, g_lo, g_hi = bootstrap_ci(gdf["gain_pp"])
                r_m, _, _ = bootstrap_ci(gdf["rho"])
                o_m, _, _ = bootstrap_ci(gdf["overlap"])
                gs = gdf.set_index("split_group")["gain_pp"]
                p_abs = paired_bootstrap_ci(gs, arch_grp[(ds, ph, "PAIR_ABS")])
                p_id = paired_bootstrap_ci(gs, arch_grp[(ds, ph, "ID_PAIRWISE")])
                summary_rows.append({
                    "dataset": ds,
                    "method_id": mid + variant_suffix,
                    "phase": ph,
                    "n_groups": int(len(gdf)),
                    "top25_gain_pp": g_m,
                    "gain_ci95_low": g_lo,
                    "gain_ci95_high": g_hi,
                    "rho": r_m,
                    "top25_overlap": o_m,
                    "neg_groups": int((gdf["gain_pp"] < -1e-12).sum()),
                    "delta_vs_PAIR_ABS": p_abs["mean_delta"],
                    "delta_vs_PAIR_ABS_ci_lo": p_abs["ci95_low"],
                    "delta_vs_PAIR_ABS_ci_hi": p_abs["ci95_high"],
                    "delta_vs_ID_PAIRWISE": p_id["mean_delta"],
                    "delta_vs_ID_ci_lo": p_id["ci95_low"],
                    "delta_vs_ID_ci_hi": p_id["ci95_high"],
                    "wall_seconds": wall,
                })
        r_dev = [x for x in summary_rows if x["method_id"] == mid and x["phase"] == "development"][0]
        r_hist = [x for x in summary_rows if x["method_id"] == mid and x["phase"] == "historical"][0]
        rb_dev = [x for x in summary_rows if x["method_id"] == mid + "_BLEND50_PAIR_ABS" and x["phase"] == "development"][0]
        rb_hist = [x for x in summary_rows if x["method_id"] == mid + "_BLEND50_PAIR_ABS" and x["phase"] == "historical"][0]
        print(
            f"[TabPFN] {mid:28s} ({wall:5.1f}s) | dev={r_dev['top25_gain_pp']:.3f} (blend={rb_dev['top25_gain_pp']:.3f}) "
            f"| hist={r_hist['top25_gain_pp']:.3f} (blend={rb_hist['top25_gain_pp']:.3f})",
            flush=True,
        )
        pd.DataFrame(summary_rows).to_csv(WORK_DIR / "tabpfn_results_summary.csv", index=False, float_format="%.12g", lineterminator="\n")

    pd.DataFrame(summary_rows).to_csv(WORK_DIR / "tabpfn_results_summary.csv", index=False, float_format="%.12g", lineterminator="\n")
    pd.concat(oof_preds_all, ignore_index=True).to_csv(WORK_DIR / "tabpfn_predictions.csv", index=False, float_format="%.12g", lineterminator="\n")
    print(f"DONE ALL in {time.perf_counter() - t_start:.1f}s", flush=True)


if __name__ == "__main__":
    main()
