from __future__ import annotations
import sys
sys.dont_write_bytecode = True

import time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import wasserstein_distance, spearmanr
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as cm
import exp5_controlled_loss_ablation as e5

OUT_REGRET_CSV = cm.GEMINI_DIR / "exp6_decision_utility_and_regret.csv"
OUT_CONDITIONAL_CSV = cm.GEMINI_DIR / "exp6_conditional_utility_stratified.csv"
OUT_GATING_CSV = cm.GEMINI_DIR / "exp6_label_free_spread_gating.csv"
OUT_SIGN_DRIFT_CSV = cm.GEMINI_DIR / "exp6_feature_within_unit_sign_drift.csv"


def compute_d2_slope_predictions():
    """Fit exact D2_DYNAMIC_ONLY (REL and ID+REL) matching frozen P6 protocol."""
    opt, lbl, _ = e5.load_prepared("D2")
    dev_lbl = lbl[lbl["role"] == "development"].copy()
    hist_lbl = lbl[lbl["role"] == "history"].copy()
    dev_groups_all = set(dev_lbl["split_group"].unique())
    hist_groups_all = set(hist_lbl["split_group"].unique())
    slope_cols = [f"{ch}_slope" for ch in cm.D2_CHANNELS]
    outer_fold_ids = sorted(dev_lbl["outer_fold"].unique())
    cats = np.asarray(cm.CATEGORIES)

    def run_variant(include_id: bool):
        preds_dev, preds_hist = [], []
        for fold in outer_fold_ids + [-1]:
            phase = "historical" if fold == -1 else "development"
            if fold == -1:
                tr_g, ev_g = dev_groups_all, hist_groups_all
                ev_sub = hist_lbl
            else:
                ev_g = set(dev_lbl.loc[dev_lbl["outer_fold"] == fold, "split_group"])
                tr_g = dev_groups_all - ev_g
                ev_sub = dev_lbl
            tr_opt = opt[opt["split_group"].isin(tr_g)].reset_index(drop=True)
            ev_opt = opt[opt["split_group"].isin(ev_g)].reset_index(drop=True)
            tr_y = dev_lbl[dev_lbl["split_group"].isin(tr_g)].sort_values(["split_group", "unit_id", "sample_id"]).reset_index(drop=True)
            ev_y = ev_sub[ev_sub["split_group"].isin(ev_g)].sort_values(["split_group", "unit_id", "sample_id"]).reset_index(drop=True)

            tr_rel, floor = e5.build_feature_block(tr_opt, slope_cols, rep="REL", floor=None)
            ev_rel, _ = e5.build_feature_block(ev_opt, slope_cols, rep="REL", floor=floor)
            if include_id:
                tr_id = (tr_opt["patchID"].to_numpy()[:, None] == cats[None, :]).astype(float)
                ev_id = (ev_opt["patchID"].to_numpy()[:, None] == cats[None, :]).astype(float)
                tr_blk = np.column_stack([tr_id, tr_rel])
                ev_blk = np.column_stack([ev_id, ev_rel])
            else:
                tr_blk, ev_blk = tr_rel, ev_rel
            sc = StandardScaler().fit(tr_blk)
            x_tr_df = pd.DataFrame(sc.transform(tr_blk), index=tr_opt["sample_id"])
            x_ev_df = pd.DataFrame(sc.transform(ev_blk), index=ev_opt["sample_id"])
            w_tr = e5.compute_unit_weights(tr_y)
            score_ev, conv = e5.fit_and_predict_one(
                "PAIRWISE_P6_PARITY", 1.0, tr_y,
                x_tr_df.loc[tr_y["sample_id"]].to_numpy(dtype=float),
                w_tr,
                x_ev_df.loc[ev_y["sample_id"]].to_numpy(dtype=float),
                "D2",
            )
            assert conv
            out_df = ev_y[["sample_id", "unit_id", "split_group", "patchID", "target"]].copy()
            out_df["score"] = score_ev
            if phase == "development":
                preds_dev.append(out_df)
            else:
                preds_hist.append(out_df)
        return {"development": pd.concat(preds_dev, ignore_index=True), "historical": pd.concat(preds_hist, ignore_index=True)}

    return run_variant(include_id=False), run_variant(include_id=True)


def run_decision_utility_and_regret(archived, d2_slope_rel, d2_id_slope_rel):
    """Compute Champion Regret, within-0.2/0.5 pp champion capture, exact champion capture, and Top-10% Enrichment."""
    rows = []
    rng = np.random.default_rng(cm.SEED)

    for (ds, phase), df in archived.items():
        merged = df.copy()
        if ds == "D2":
            s_rel = d2_slope_rel[phase][["sample_id", "score"]].rename(columns={"score": "D2_SLOPE_REL"})
            s_id_rel = d2_id_slope_rel[phase][["sample_id", "score"]].rename(columns={"score": "D2_ID_PLUS_SLOPE_REL"})
            merged = merged.merge(s_rel, on="sample_id", validate="one_to_one").merge(s_id_rel, on="sample_id", validate="one_to_one")
            models = ["PAIR_ABS", "PL_PAIRWISE", "ID_PAIRWISE", "ID_PLUS_PL_PAIRWISE", "D2_SLOPE_REL", "D2_ID_PLUS_SLOPE_REL", "LGBM_PL", "PL_INTENSITY"]
        else:
            models = ["PAIR_ABS", "PL_PAIRWISE", "ID_PAIRWISE", "ID_PLUS_PL_PAIRWISE", "LGBM_PL", "PL_INTENSITY"]

        for q in [0.10, 0.25, 0.50]:
            for mid in models + ["RANDOM_MC"]:
                urows = []
                for uid, g in merged.groupby("unit_id", sort=True):
                    y = g["target"].to_numpy(dtype=float)
                    ids = g["sample_id"].to_numpy(dtype=str)
                    n = len(y)
                    k = cm.top_k_count(n, fraction=q, rounding="ceil")
                    k10 = cm.top_k_count(n, fraction=0.10, rounding="ceil")
                    true_max = float(y.max())
                    ti = cm.stable_order_indices(y, ids)
                    true10_ids = set(ids[ti[:k10]])
                    champ_val = float(y[ti[0]])

                    if mid == "RANDOM_MC":
                        # Exact expectation over random selection of k from n (via 2000 balanced draws per group using fixed seed)
                        regrets, w02, w05, exact_best, t10rec = [], [], [], [], []
                        for _ in range(500):
                            pick = rng.choice(n, size=k, replace=False)
                            sel_max = float(y[pick].max())
                            reg = true_max - sel_max
                            regrets.append(reg)
                            w02.append(float(reg <= 0.2 + 1e-12))
                            w05.append(float(reg <= 0.5 + 1e-12))
                            exact_best.append(float(sel_max >= champ_val - 1e-12))
                            t10rec.append(len(set(ids[pick]) & true10_ids) / k10)
                        regret = float(np.mean(regrets))
                        hit02 = float(np.mean(w02))
                        hit05 = float(np.mean(w05))
                        hit_best = float(np.mean(exact_best))
                        top10_rec = float(np.mean(t10rec))
                    else:
                        pi = cm.stable_order_indices(g[mid].to_numpy(dtype=float), ids)
                        sel_idx = pi[:k]
                        sel_max = float(y[sel_idx].max())
                        regret = true_max - sel_max
                        hit02 = float(regret <= 0.2 + 1e-12)
                        hit05 = float(regret <= 0.5 + 1e-12)
                        hit_best = float(sel_max >= champ_val - 1e-12)
                        top10_rec = len(set(ids[sel_idx]) & true10_ids) / k10

                    urows.append({
                        "unit_id": uid,
                        "split_group": str(g["split_group"].iloc[0]),
                        "regret_pp": regret,
                        "within_0p2pp": hit02,
                        "within_0p5pp": hit05,
                        "exact_champion": hit_best,
                        "top10_recall": top10_rec,
                        "enrichment_factor": top10_rec / q,
                    })
                udf = pd.DataFrame(urows)
                gdf = cm.evaluate_unit_to_group(udf, ds, ["regret_pp", "within_0p2pp", "within_0p5pp", "exact_champion", "top10_recall", "enrichment_factor"])
                reg_m, reg_lo, reg_hi = cm.bootstrap_ci(gdf["regret_pp"])
                t10_m, t10_lo, t10_hi = cm.bootstrap_ci(gdf["top10_recall"])
                ef_m, ef_lo, ef_hi = cm.bootstrap_ci(gdf["enrichment_factor"])
                rows.append({
                    "dataset": ds,
                    "phase": phase,
                    "budget_q": q,
                    "model_id": mid,
                    "n_groups": int(len(gdf)),
                    "n_units": int(len(udf)),
                    "mean_max_regret_pp": reg_m,
                    "regret_ci95_low": reg_lo,
                    "regret_ci95_high": reg_hi,
                    "pct_units_within_0p2pp": float(udf["within_0p2pp"].mean()),
                    "pct_units_within_0p5pp": float(udf["within_0p5pp"].mean()),
                    "pct_units_exact_champion": float(udf["exact_champion"].mean()),
                    "pct_groups_within_0p2pp_macro": float(gdf["within_0p2pp"].mean()),
                    "pct_groups_within_0p5pp_macro": float(gdf["within_0p5pp"].mean()),
                    "top10_recall": t10_m,
                    "top10_recall_ci95_low": t10_lo,
                    "top10_recall_ci95_high": t10_hi,
                    "top10_enrichment_factor": ef_m,
                    "ef_ci95_low": ef_lo,
                    "ef_ci95_high": ef_hi,
                })

    out = pd.DataFrame(rows)
    out.to_csv(OUT_REGRET_CSV, index=False, float_format="%.12g", lineterminator="\n")
    print(f"[exp6] Saved {OUT_REGRET_CSV}")


def run_conditional_stratification_and_gating(archived, d2_slope_rel):
    """Stratify selection units by optical-position agreement, position weakness, and label-free optical spread."""
    cond_rows = []
    gate_rows = []

    for (ds, phase), df in archived.items():
        merged = df.copy()
        if ds == "D2":
            s_rel = d2_slope_rel[phase][["sample_id", "score"]].rename(columns={"score": "D2_SLOPE_REL"})
            merged = merged.merge(s_rel, on="sample_id", validate="one_to_one")

        unit_records = []
        for uid, g in merged.groupby("unit_id", sort=True):
            y = g["target"].to_numpy(dtype=float)
            ids = g["sample_id"].to_numpy(dtype=str)
            m_abs = cm.group_metrics_basic(y, g["PAIR_ABS"], ids, 0.25)
            m_rel = cm.group_metrics_basic(y, g["PL_PAIRWISE"], ids, 0.25)
            m_id = cm.group_metrics_basic(y, g["ID_PAIRWISE"], ids, 0.25)
            m_idpl = cm.group_metrics_basic(y, g["ID_PLUS_PL_PAIRWISE"], ids, 0.25)
            m_slope = cm.group_metrics_basic(y, g["D2_SLOPE_REL"], ids, 0.25) if ds == "D2" else None

            corr_abs_id = cm.spearman_rho(g["ID_PAIRWISE"], g["PAIR_ABS"])
            score_iqr_abs = float(np.subtract(*np.percentile(g["PAIR_ABS"], [75, 25])))
            score_std_abs = float(np.std(g["PAIR_ABS"], ddof=1))
            y_iqr = float(np.subtract(*np.percentile(y, [75, 25])))

            rec = {
                "unit_id": uid,
                "split_group": str(g["split_group"].iloc[0]),
                "corr_opt_id": corr_abs_id,
                "score_iqr_abs": score_iqr_abs,
                "score_std_abs": score_std_abs,
                "y_iqr": y_iqr,
                "gain_PAIR_ABS": m_abs["gain_pp"],
                "gain_PL_PAIRWISE": m_rel["gain_pp"],
                "gain_ID_PAIRWISE": m_id["gain_pp"],
                "gain_ID_PLUS_PL": m_idpl["gain_pp"],
                "gain_D2_SLOPE_REL": m_slope["gain_pp"] if m_slope else np.nan,
                "delta_abs_minus_id": m_abs["gain_pp"] - m_id["gain_pp"],
                "delta_idpl_minus_id": m_idpl["gain_pp"] - m_id["gain_pp"],
                "delta_slope_minus_id": (m_slope["gain_pp"] - m_id["gain_pp"]) if m_slope else np.nan,
            }
            unit_records.append(rec)

        udf = pd.DataFrame(unit_records)
        med_corr = float(udf["corr_opt_id"].median())
        med_id_gain = float(udf["gain_ID_PAIRWISE"].median())

        strata = [
            ("ALL_UNITS", udf),
            ("DISCORDANT_OPT_VS_POS (corr<=0)", udf[udf["corr_opt_id"] <= 0.0]),
            ("CONCORDANT_OPT_VS_POS (corr>0)", udf[udf["corr_opt_id"] > 0.0]),
            ("LOW_AGREEMENT_HALF (<median_corr)", udf[udf["corr_opt_id"] < med_corr]),
            ("HIGH_AGREEMENT_HALF (>=median_corr)", udf[udf["corr_opt_id"] >= med_corr]),
            ("POS_WEAK_OR_FAIL (ID_gain<=0)", udf[udf["gain_ID_PAIRWISE"] <= 0.0]),
            ("POS_BOTTOM_HALF (ID_gain<median)", udf[udf["gain_ID_PAIRWISE"] < med_id_gain]),
            ("POS_TOP_HALF (ID_gain>=median)", udf[udf["gain_ID_PAIRWISE"] >= med_id_gain]),
        ]

        for sname, sub in strata:
            if len(sub) == 0:
                continue
            row = {
                "dataset": ds,
                "phase": phase,
                "stratum": sname,
                "n_units": int(len(sub)),
                "n_split_groups": int(sub["split_group"].nunique()),
                "mean_corr_opt_id": float(sub["corr_opt_id"].mean()),
                "mean_gain_ID": float(sub["gain_ID_PAIRWISE"].mean()),
                "mean_gain_PAIR_ABS": float(sub["gain_PAIR_ABS"].mean()),
                "mean_gain_ID_PLUS_PL": float(sub["gain_ID_PLUS_PL"].mean()),
                "mean_gain_D2_SLOPE_REL": float(sub["gain_D2_SLOPE_REL"].mean()) if ds == "D2" else np.nan,
                "mean_delta_PAIR_ABS_minus_ID": float(sub["delta_abs_minus_id"].mean()),
                "mean_delta_IDPL_minus_ID": float(sub["delta_idpl_minus_id"].mean()),
                "mean_delta_SLOPE_minus_ID": float(sub["delta_slope_minus_id"].mean()) if ds == "D2" else np.nan,
                "PAIR_ABS_beats_ID_units": int((sub["delta_abs_minus_id"] > 1e-12).sum()),
                "IDPL_beats_ID_units": int((sub["delta_idpl_minus_id"] > 1e-12).sum()),
                "PAIR_ABS_positive_units": int((sub["gain_PAIR_ABS"] > 1e-12).sum()),
                "ID_positive_units": int((sub["gain_ID_PAIRWISE"] > 1e-12).sum()),
            }
            # Paired CI over units when n>=5 (clearly flagged as unit-level descriptive breakdown)
            p_abs = cm.paired_bootstrap_ci(sub["gain_PAIR_ABS"], sub["gain_ID_PAIRWISE"])
            row["unit_delta_ABS_minus_ID_ci95_low"] = p_abs["ci95_low"]
            row["unit_delta_ABS_minus_ID_ci95_high"] = p_abs["ci95_high"]
            cond_rows.append(row)

        # Label-free spread diagnostics comparing negative vs positive PAIR_ABS units
        neg = udf[udf["gain_PAIR_ABS"] < -1e-12]
        pos = udf[udf["gain_PAIR_ABS"] >= -1e-12]
        for q_cut in [0.0, 0.10, 0.15, 0.20]:
            thr = float(udf["score_std_abs"].quantile(q_cut)) if q_cut > 0 else -np.inf
            kept = udf[udf["score_std_abs"] >= thr]
            abstained = udf[udf["score_std_abs"] < thr]
            gate_rows.append({
                "dataset": ds,
                "phase": phase,
                "abstain_quantile": q_cut,
                "score_std_threshold": thr,
                "n_units_total": int(len(udf)),
                "n_units_kept": int(len(kept)),
                "n_units_abstained": int(len(abstained)),
                "kept_neg_units": int((kept["gain_PAIR_ABS"] < -1e-12).sum()),
                "kept_neg_rate": float((kept["gain_PAIR_ABS"] < -1e-12).mean()) if len(kept) else np.nan,
                "abstained_neg_units": int((abstained["gain_PAIR_ABS"] < -1e-12).sum()),
                "abstained_neg_rate": float((abstained["gain_PAIR_ABS"] < -1e-12).mean()) if len(abstained) else np.nan,
                "kept_mean_gain_PAIR_ABS": float(kept["gain_PAIR_ABS"].mean()) if len(kept) else np.nan,
                "abstained_mean_gain_PAIR_ABS": float(abstained["gain_PAIR_ABS"].mean()) if len(abstained) else np.nan,
                "all_neg_units_mean_score_std": float(neg["score_std_abs"].mean()) if len(neg) else np.nan,
                "all_pos_units_mean_score_std": float(pos["score_std_abs"].mean()) if len(pos) else np.nan,
                "all_neg_units_mean_y_iqr": float(neg["y_iqr"].mean()) if len(neg) else np.nan,
                "all_pos_units_mean_y_iqr": float(pos["y_iqr"].mean()) if len(pos) else np.nan,
            })

    pd.DataFrame(cond_rows).to_csv(OUT_CONDITIONAL_CSV, index=False, float_format="%.12g", lineterminator="\n")
    pd.DataFrame(gate_rows).to_csv(OUT_GATING_CSV, index=False, float_format="%.12g", lineterminator="\n")
    print(f"[exp6] Saved {OUT_CONDITIONAL_CSV} and {OUT_GATING_CSV}")


def run_feature_sign_and_drift():
    """Analyze per-feature within-unit Spearman(feature, PCE) sign stability and cross-batch shift across Dev vs Hist."""
    rows = []

    D1_LEVEL = {"mean", "early10_mean", "late10_mean", "maximum", "middle50_mean", "integral_frame_index"}

    for ds in ["D1", "D2"]:
        opt, lbl, feat_cols = e5.load_prepared(ds)
        df = lbl.merge(opt[["sample_id"] + feat_cols], on="sample_id", validate="one_to_one")

        # Fit global StandardScaler on development optical rows to quantify cross-cohort feature drift cleanly
        dev_opt = opt[opt["role"] == "development"]
        scaler = StandardScaler().fit(dev_opt[feat_cols].to_numpy(dtype=float))
        z_all = pd.DataFrame(scaler.transform(df[feat_cols].to_numpy(dtype=float)), columns=feat_cols, index=df.index)
        z_dev = z_all[df["role"] == "development"]
        z_hist = z_all[df["role"] == "history"]

        for f in feat_cols:
            if ds == "D1":
                ftype = "level" if f in D1_LEVEL else "dynamic"
            else:
                ftype = "dynamic_slope" if f.endswith("_slope") else "intensity_level"

            # Per-unit within-group Spearman(f, target)
            unit_rhos = []
            for role in ["development", "history"]:
                sub = df[df["role"] == role]
                for uid, g in sub.groupby("unit_id", sort=True):
                    r = cm.spearman_rho(g["target"], g[f])
                    unit_rhos.append({
                        "role": role,
                        "split_group": str(g["split_group"].iloc[0]),
                        "unit_id": uid,
                        "rho": r,
                    })
            ur = pd.DataFrame(unit_rhos)
            # Group-level aggregation (substrate for D1, date for D2)
            grp_dev = ur[ur["role"] == "development"].groupby("split_group", sort=True)["rho"].mean()
            grp_hist = ur[ur["role"] == "history"].groupby("split_group", sort=True)["rho"].mean()

            dev_mean_rho = float(grp_dev.mean())
            hist_mean_rho = float(grp_hist.mean())
            dev_sign = 1.0 if dev_mean_rho >= 0 else -1.0

            dev_same_sign_frac = float((grp_dev * dev_sign > 0).mean())
            hist_same_sign_frac = float((grp_hist * dev_sign > 0).mean())

            w1_global = float(wasserstein_distance(z_dev[f].to_numpy(), z_hist[f].to_numpy()))
            mean_shift_std = float(z_hist[f].mean() - z_dev[f].mean())

            row = {
                "dataset": ds,
                "feature": f,
                "feature_type": ftype,
                "dev_mean_within_unit_rho": dev_mean_rho,
                "hist_mean_within_unit_rho": hist_mean_rho,
                "rho_shift_hist_minus_dev": hist_mean_rho - dev_mean_rho,
                "abs_rho_ratio_hist_over_dev": abs(hist_mean_rho) / max(abs(dev_mean_rho), 1e-12),
                "same_sign_dev_vs_hist_overall": bool((dev_mean_rho * hist_mean_rho) > 0),
                "dev_groups_same_sign_frac": dev_same_sign_frac,
                "hist_groups_same_sign_frac": hist_same_sign_frac,
                "dev_to_hist_wasserstein_z": w1_global,
                "dev_to_hist_mean_shift_z": mean_shift_std,
            }
            if ds == "D2":
                for d_str in ["20230829", "20230905", "20230912"]:
                    row[f"rho_{d_str}"] = float(grp_hist.get(d_str, np.nan))
            rows.append(row)

    pd.DataFrame(rows).to_csv(OUT_SIGN_DRIFT_CSV, index=False, float_format="%.12g", lineterminator="\n")
    print(f"[exp6] Saved {OUT_SIGN_DRIFT_CSV}")


def main():
    t0 = time.perf_counter()
    cm.verify_archived_baseline()
    archived = cm.load_archived_predictions()
    d2_slope_rel, d2_id_slope_rel = compute_d2_slope_predictions()
    run_decision_utility_and_regret(archived, d2_slope_rel, d2_id_slope_rel)
    run_conditional_stratification_and_gating(archived, d2_slope_rel)
    run_feature_sign_and_drift()
    print(f"[exp6] All analyses completed in {time.perf_counter() - t0:.1f}s")


if __name__ == "__main__":
    main()
