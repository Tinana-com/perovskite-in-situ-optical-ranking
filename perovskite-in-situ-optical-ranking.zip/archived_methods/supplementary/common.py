"""P10-SUP paths, stable score metrics and independent-unit resampling."""
from pathlib import Path
import hashlib,json,time
import numpy as np,pandas as pd
from scipy.stats import spearmanr
B=Path(__file__).resolve().parents[1];ROOT=B.parents[1];R=B/'results'
REF=B/'references/CODE_RELEASE';P6=REF/'SOURCE_DATA/P6'
CACHE=ROOT/'research/pl_public_data_pilot_02/results/extracted_features.csv'
RAW=ROOT/'perovskite-ai-research/data/raw/kit_pl_2025/data.h5'
D1DIR=ROOT/'perovskite-ai-research/research/pl_public_data_pilot_01/data_external/D1'
CHANNELS=['LP725','LP780','SP775','ND'];STATS=['mean','last','slope'];F2=[f'{c}_{s}' for c in CHANNELS for s in STATS]
KEYS=['sample_id','unit_id','split_group','patchID'];SEED=20261019
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for a in iter(lambda:f.read(8*1024*1024),b''):h.update(a)
 return h.hexdigest()
def dump(p,v):
 p=Path(p);p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n',encoding='utf8')
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def csv(p,f):
 p=Path(p);p.parent.mkdir(exist_ok=True,parents=True);f.to_csv(p,index=False,float_format='%.17g',lineterminator='\n',na_rep='')
def ihash(ids):return hashlib.sha256('\n'.join(sorted(map(str,ids))).encode()).hexdigest()
def order(ids,score):return np.lexsort((np.asarray(ids,str),-np.asarray(score,float)))
def kceil(q,n):return n if q==1 else int(np.ceil(q*n))
def gain(ids,y,score,q=.25):
 y=np.asarray(y,float);k=kceil(q,len(y));sel=order(ids,score)[:k];true=order(ids,y)[:k]
 rho=float(spearmanr(y,score).statistic) if np.ptp(y)>0 and np.ptp(score)>0 else np.nan
 return {'n':len(y),'k':k,'gain_pp':0. if k==len(y) else float(y[sel].mean()-y.mean()),'rho':rho,'overlap':len(set(sel)&set(true))/k,'reference_mean':float(y.mean()),'selected_mean':float(y[sel].mean()),'selected_ids':'|'.join(np.asarray(ids,str)[sel]),'status':'PASS'}
def ci(a):
 a=np.asarray(a,float);a=a[np.isfinite(a)]
 if not len(a):return np.nan,np.nan,np.nan,0
 b=np.random.default_rng(SEED).choice(a,(10000,len(a)),replace=True).mean(axis=1);return float(a.mean()),float(np.quantile(b,.025)),float(np.quantile(b,.975)),len(a)
def independent(frame,by,metrics):return frame.groupby(by+['split_group'],sort=True,dropna=False)[metrics].mean().reset_index()
def is_history_scope(scope):return 'HISTORY' in str(scope) or 'AUTHOR_TEST' in str(scope)
def macro(frame,by,metrics):
 rows=[]
 for key,g in frame.groupby(by,sort=True,dropna=False):
  row=dict(zip(by,key if isinstance(key,tuple) else (key,)));row['n_independent_units']=len(g);row['scope_kind']='PREVIOUSLY_INSPECTED_HISTORY' if is_history_scope(row.get('scope','')) else 'REUSED_EXPLORATORY_DEVELOPMENT'
  for m in metrics:
   val,lo,hi,n=ci(g[m]);row.update({m:val,m+'_ci_low':lo,m+'_ci_high':hi,m+'_n_defined':n})
  row['status']='PASS';rows.append(row)
 return pd.DataFrame(rows)
def archived():
 out=[]
 for ds,phase,n in [('D1','dev','d1_train_oof_predictions.csv'),('D1','history','d1_author_test_predictions.csv'),('D2','dev','d2_dev_oof_predictions.csv'),('D2','history','d2_history_predictions.csv')]:
  f=pd.read_csv(P6/n,dtype={'split_group':str},float_precision='round_trip');assert f.sample_id.is_unique
  if ds=='D1':
   t=pd.read_csv(P6/('d1_development_targets_full_precision.csv' if phase=='dev' else 'd1_historical_targets_full_precision.csv'),float_precision='round_trip');f=f.drop(columns=['target']).merge(t,on='sample_id',validate='one_to_one').rename(columns={'raw_target':'target'})
  f['dataset']=ds;f['phase']=phase;out.append(f)
 return pd.concat(out,ignore_index=True,sort=False)
def within_budget():
 start=read(B/'RUN_RECEIPTS/start.json')['unix_time'];return time.time()-start<7200
def explicit_D2_identity(f):
 if not {'dataset','unit_id','split_group'}<=set(f):return f
 f=f.copy();d=f.dataset.eq('D2')
 if 'date' not in f:f['date']=pd.to_numeric(f.split_group.where(d),errors='coerce').astype('Int64')
 if 'expID' not in f:f['expID']=f.unit_id.astype(str).str.split('::').str[-1].where(d)
 return f
