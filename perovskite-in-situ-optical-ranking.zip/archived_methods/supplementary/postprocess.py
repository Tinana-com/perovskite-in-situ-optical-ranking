"""Frozen archived-score decisions and explicitly retrospective label sensitivities."""
import argparse
from common import *
MODELS=['PAIR_ABS','ID_PAIRWISE','PL_INTENSITY','PL_PAIRWISE']
def triage(ids,y,s,q,random=False):
 n=len(y);k=kceil(q,n);kt=kceil(.1,n);idx=order(ids,s)[:k] if not random else None;true=set(order(ids,y)[:kt]);return {'n':n,'k':k,'actual_fraction':k/n,'gain_pp':0. if random or k==n else float(np.asarray(y)[idx].mean()-np.mean(y)),'recall_truth_top10':k/n if random else len(set(idx)&true)/kt,'truth_top10_n':kt,'selected_ids':'ANALYTIC_EXPECTATION' if random else '|'.join(np.asarray(ids)[idx]),'status':'PASS','new_training':False}
def cull(ids,y,s,p,random=False):
 y=np.asarray(y,float);n=len(y);k=kceil(p,n)
 if k>=n:raise ValueError('Culling may not remove whole group')
 low=y<2.;l=int(low.sum());idx=order(ids,s)[-k:] if not random else None
 if random:tp=k*l/n;kept_gain=0.;drop='ANALYTIC_EXPECTATION'
 else:tp=int(low[idx].sum());keep=np.ones(n,bool);keep[idx]=False;kept_gain=float(y[keep].mean()-y.mean());drop='|'.join(np.asarray(ids)[idx])
 return {'n':n,'k':k,'n_kept':n-k,'actual_drop_fraction':k/n,'n_low_pce':l,'low_intercepted':tp,'low_missed':l-tp,'false_culled':k-tp,'kept_gain_pp':kept_gain,'recall_low_pce':tp/l if l else np.nan,'PPV_culling':tp/k,'random_recall_expectation':k/n if l else np.nan,'dropped_ids':drop,'status':'PASS' if l else 'NO_LOW_PCE_RECALL_UNDEFINED','new_training':False}
def contrasts(units,cols,metrics,out):
 rows=[]
 for key,g in units.groupby(cols,sort=True):
  info=dict(zip(cols,key if isinstance(key,tuple) else (key,)));aa=g[g.model_id=='PAIR_ABS'].set_index('split_group')
  for ref in ['ID_PAIRWISE','PL_INTENSITY','PL_PAIRWISE','RANDOM_EXPECTATION']:
   bb=g[g.model_id==ref].set_index('split_group');assert set(aa.index)==set(bb.index)
   for m in metrics:
    delta=(aa[m]-bb[m]).sort_index();val,lo,hi,n=ci(delta);rows.append({**info,'method_a':'PAIR_ABS','method_b':ref,'metric':m,'value':val,'ci_low':lo,'ci_high':hi,'n_independent_units_defined':n,'improved':int((delta>1e-12).sum()),'worsened':int((delta< -1e-12).sum()),'tied':int((abs(delta)<=1e-12).sum()),'status':'PASS' if n else 'UNDEFINED_NO_DENOMINATOR','interval':'descriptive paired substrate/date bootstrap10000'})
 csv(out,pd.DataFrame(rows))
def baseline(f,out):
 rows=[];bm=[]
 for (ds,scope,unit),g in f.groupby(['dataset','scope','unit_id'],sort=True):
  for mid in ['PAIR_ABS','ID_PAIRWISE','ID_PLUS_PL_PAIRWISE']:
   rows.append({'dataset':ds,'scope':scope,'unit_id':unit,'split_group':str(g.split_group.iloc[0]),'model_id':mid,**gain(g.sample_id,g.target,g[mid])})
 u=independent(pd.DataFrame(rows),['dataset','scope','model_id'],['gain_pp']);summ=u.groupby(['dataset','scope','model_id']).gain_pp.mean()
 for ds,phase,mid,expected in [('D1','dev','PAIR_ABS',1.241586),('D2','dev','PAIR_ABS',.779041)]:
  scope=f[(f.dataset==ds)&(f.phase==phase)].scope.iloc[0];actual=float(summ.loc[(ds,scope,mid)]);bm.append({'dataset':ds,'scope':scope,'model_id':mid,'metric':'gain_pp','value':actual,'reference':expected,'abs_difference':abs(actual-expected),'status':'PASS' if abs(actual-expected)<=1e-6 else 'FAILED_QA'})
 ds='D2';scope=f[(f.dataset==ds)&(f.phase=='history')].scope.iloc[0];actual=float(summ.loc[(ds,scope,'ID_PLUS_PL_PAIRWISE')]-summ.loc[(ds,scope,'ID_PAIRWISE')]);bm.append({'dataset':ds,'scope':scope,'model_id':'ID_PLUS_PL_PAIRWISE - ID_PAIRWISE','metric':'gain_pp','value':actual,'reference':-.303715,'abs_difference':abs(actual+.303715),'status':'PASS' if abs(actual+.303715)<=1e-6 else 'FAILED_QA'});csv(out/'BASELINE_REPRODUCTION.csv',pd.DataFrame(bm));assert all(r['status']=='PASS' for r in bm),'P6 baseline mismatch, stop corresponding comparison'
 return pd.DataFrame(rows)
def smoke():
 start=time.perf_counter();f=archived();checks=[]
 for ds,phase,n,ng,ni in [('D1','dev',780,26,26),('D1','history',349,12,12),('D2','dev',4707,158,14),('D2','history',1150,36,3)]:
  g=f[(f.dataset==ds)&(f.phase==phase)];assert (len(g),g.unit_id.nunique(),g.split_group.nunique())==(n,ng,ni);assert not g.duplicated(['unit_id','patchID']).any();assert np.isfinite(g[MODELS+['ID_PLUS_PL_PAIRWISE','target']].to_numpy()).all();checks.append({'dataset':ds,'phase':phase,'n':n,'selection_units':ng,'independent_units':ni,'zero_targets':int(g.target.eq(0).sum())})
 rawchecks=[]
 for phase,name in [('dev','training_extracted_features_and_labels.h5'),('history','test_extracted_features_and_labels.h5')]:
  raw=pd.read_hdf(D1DIR/name,'df');rawids='D1::'+raw.substrateID.astype(str)+'::'+raw.patchID.astype(int).astype(str);lookup=pd.Series(raw.pce_mean.to_numpy(float),index=rawids);g=f[(f.dataset=='D1')&(f.phase==phase)];assert np.array_equal(lookup.loc[g.sample_id].to_numpy(),g.target.to_numpy());rawchecks.append({'phase':phase,'full_precision_bit_exact':True,'rows':len(g)})
 baseline(f,R);dump(B/'RUN_RECEIPTS/smoke.json',{'status':'PASS','wall_seconds':time.perf_counter()-start,'under_one_minute':time.perf_counter()-start<60,'counts':checks,'D1_full_precision_H5_checks':rawchecks,'new_model_fits':0});print(read(B/'RUN_RECEIPTS/smoke.json'),flush=True)
def run(out):
 start=time.perf_counter();out.mkdir(exist_ok=True,parents=True);f=archived();baseline_rows=baseline(f,out);p=read(B/'FROZEN_EXPERIMENTS.json');tt=[];cc=[]
 for (ds,scope,unit),g in f.groupby(['dataset','scope','unit_id'],sort=True):
  for mid in MODELS+['RANDOM_EXPECTATION']:
   ids=g.sample_id.to_numpy(str);y=g.target.to_numpy(float);s=g[mid].to_numpy() if mid!='RANDOM_EXPECTATION' else np.zeros(len(g));info={'dataset':ds,'scope':scope,'unit_id':unit,'split_group':str(g.split_group.iloc[0]),'date':int(g.date.iloc[0]) if ds=='D2' else None,'expID':g.expID.iloc[0] if ds=='D2' else None,'model_id':mid}
   for q in p['q_top']:tt.append({**info,'q':q,**triage(ids,y,s,q,mid=='RANDOM_EXPECTATION')})
   for d in p['p_drop']:cc.append({**info,'p_drop':d,**cull(ids,y,s,d,mid=='RANDOM_EXPECTATION')})
 t=pd.DataFrame(tt);c=pd.DataFrame(cc);csv(out/'TRIAGE_BY_UNIT.csv',t);csv(out/'CULLING_BY_UNIT.csv',c)
 by=['dataset','scope','model_id','q'];tu=independent(t,by,['gain_pp','recall_truth_top10']);csv(out/'TRIAGE_BY_INDEPENDENT_UNIT.csv',tu);tm=macro(tu,by,['gain_pp','recall_truth_top10']);coverage=t.groupby(by).agg(n_regions=('n','sum'),n_selection_units=('unit_id','size')).reset_index();tm=tm.merge(coverage,on=by,validate='one_to_one');csv(out/'TRIAGE_MACRO_SUMMARY.csv',tm);contrasts(tu,['dataset','scope','q'],['gain_pp','recall_truth_top10'],out/'TRIAGE_PAIRED_CONTRASTS.csv')
 by=['dataset','scope','model_id','p_drop'];cu=independent(c,by,['kept_gain_pp','recall_low_pce','PPV_culling']);csv(out/'CULLING_BY_INDEPENDENT_UNIT.csv',cu);cm=macro(cu,by,['kept_gain_pp','recall_low_pce','PPV_culling']);micro=[]
 for key,g in c.groupby(by,sort=True):
  sums=g.groupby('split_group')[['low_intercepted','n_low_pce']].sum();tp=sums.low_intercepted.to_numpy();den=sums.n_low_pce.to_numpy();idx=np.random.default_rng(SEED).integers(0,len(sums),(10000,len(sums)));td=den[idx].sum(1);boot=np.divide(tp[idx].sum(1),td,out=np.full(10000,np.nan),where=td>0);lo,hi=np.nanquantile(boot,[.025,.975]) if np.isfinite(boot).any() else (np.nan,np.nan);micro.append({**dict(zip(by,key)),'micro_recall_low_pce':float(tp.sum()/den.sum()) if den.sum() else np.nan,'micro_recall_CI_low':lo,'micro_recall_CI_high':hi,'micro_low_PCE_denominator':int(den.sum()),'low_intercepted_total':float(tp.sum()),'low_missed_total':float(g.low_missed.sum()),'false_culled_total':float(g.false_culled.sum()),'n_regions':int(g.n.sum()),'n_selection_units':len(g),'n_selection_units_with_low_PCE':int((g.n_low_pce>0).sum()),'micro_bootstrap_undefined_draws':int(np.isnan(boot).sum())})
 cm=cm.rename(columns={'recall_low_pce':'macro_recall_low_pce'}).merge(pd.DataFrame(micro),on=by,validate='one_to_one');csv(out/'CULLING_MACRO_MICRO.csv',cm);contrasts(cu,['dataset','scope','p_drop'],['kept_gain_pp','recall_low_pce','PPV_culling'],out/'CULLING_PAIRED_CONTRASTS.csv')
 sensitivity(f,baseline_rows,out)
 for n in ['PCE_THRESHOLD_SENSITIVITY_BY_UNIT.csv','LOW_PCE_FILTER_COUNTS.csv','DISCORDANCE_CASES.csv']:
  path=out/n;csv(path,explicit_D2_identity(pd.read_csv(path,dtype={'split_group':str},float_precision='round_trip')))
 dump(out/'postprocess_receipt.json',{'wall_seconds':time.perf_counter()-start,'archived_regions':len(f),'triage_rows':len(t),'culling_rows':len(c),'zero_new_fits':True});print('Postprocess complete',len(t),len(c),flush=True)
def sensitivity(f,baseline_rows,out):
 a=f[(f.dataset=='D1')&(f.unit_id=='AEM')].copy();a=a.sort_values(['PAIR_ABS','sample_id'],ascending=[False,True]);a['PAIR_ABS_rank']=np.arange(1,len(a)+1);a['selected_top25']=a.PAIR_ABS_rank<=kceil(.25,len(a));csv(out/'AEM_ALL_REGIONS.csv',a[['dataset','scope','sample_id','unit_id','target','PAIR_ABS','PAIR_ABS_rank','selected_top25']]);single=[]
 for label,g in [('ALL_REGIONS',a),('POSTHOC_REMOVE_AEM_21',a[a.sample_id!='D1::AEM::21'])]:single.append({'dataset':'D1','scope':a.scope.iloc[0],'unit_id':'AEM','model_id':'PAIR_ABS','scenario':label,**gain(g.sample_id,g.target,g.PAIR_ABS)})
 csv(out/'AEM_SINGLE_POINT_FILTER.csv',pd.DataFrame(single));rows=[];counts=[]
 for (ds,scope,unit),g in f.groupby(['dataset','scope','unit_id'],sort=True):
  for scenario,threshold in [('ALL',None),('POSTHOC_TARGET_GT_0',0.),('POSTHOC_TARGET_GT_1',1.)]:
   z=g if threshold is None else g[g.target>threshold];counts.append({'dataset':ds,'scope':scope,'unit_id':unit,'split_group':str(g.split_group.iloc[0]),'scenario':scenario,'n_original':len(g),'n_remaining':len(z),'n_removed':len(g)-len(z),'status':'PASS' if len(z)>=4 else 'FEWER_THAN_4_CANDIDATES'})
   for mid in MODELS+['ID_PLUS_PL_PAIRWISE']:
    result=gain(z.sample_id,z.target,z[mid]) if len(z)>=4 else {'n':len(z),'k':0,'gain_pp':np.nan,'rho':np.nan,'overlap':np.nan,'status':'FEWER_THAN_4_CANDIDATES'};rows.append({'dataset':ds,'scope':scope,'unit_id':unit,'split_group':str(g.split_group.iloc[0]),'model_id':mid,'scenario':scenario,'posthoc_PCE_filter':scenario!='ALL',**result})
 sens=pd.DataFrame(rows);csv(out/'PCE_THRESHOLD_SENSITIVITY_BY_UNIT.csv',sens);counts=pd.DataFrame(counts);csv(out/'LOW_PCE_FILTER_COUNTS.csv',counts)
 si=independent(sens,['dataset','scope','model_id','scenario'],['gain_pp','rho','overlap']);ss=macro(si,['dataset','scope','model_id','scenario'],['gain_pp','rho','overlap']);neg=sens.groupby(['dataset','scope','model_id','scenario']).agg(n_units_total=('unit_id','size'),n_units_evaluated=('gain_pp','count'),n_negative_units=('gain_pp',lambda v:int((v< -1e-12).sum()))).reset_index();ss=ss.merge(neg,on=['dataset','scope','model_id','scenario']);csv(out/'PCE_THRESHOLD_SENSITIVITY_SUMMARY.csv',ss)
 paired=[]
 for (ds,scope,scenario),g in si.groupby(['dataset','scope','scenario']):
  for mid,ref in [('PAIR_ABS','ID_PAIRWISE'),('ID_PLUS_PL_PAIRWISE','ID_PAIRWISE')]:
   aa=g[g.model_id==mid].set_index('split_group');bb=g[g.model_id==ref].set_index('split_group');d=aa.gain_pp-bb.gain_pp;v,lo,hi,n=ci(d);paired.append({'dataset':ds,'scope':scope,'scenario':scenario,'method_a':mid,'method_b':ref,'metric':'gain_pp','value':v,'CI_low':lo,'CI_high':hi,'n_defined':n,'status':'PASS' if n else 'UNDEFINED'})
 csv(out/'PCE_THRESHOLD_PAIRED_CONTRASTS.csv',pd.DataFrame(paired));cases=[];failed=baseline_rows[(baseline_rows.model_id=='PAIR_ABS')&(baseline_rows.gain_pp<0)];units=set(failed.unit_id)|{'AEM','ADT','AEL'}
 for (ds,scope,unit),g in f[f.unit_id.isin(units)].groupby(['dataset','scope','unit_id'],sort=True):
  g=g.sort_values(['PAIR_ABS','sample_id'],ascending=[False,True]).copy();g['rank']=np.arange(1,len(g)+1);g['selected_top25']=g['rank']<=kceil(.25,len(g));g['target_lt2']=g.target<2;g['top25_and_target_lt2']=g.selected_top25&g.target_lt2;rem=sens[(sens.dataset==ds)&(sens.scope==scope)&(sens.unit_id==unit)&(sens.model_id=='PAIR_ABS')&(sens.scenario=='POSTHOC_TARGET_GT_1')];g['gain_after_posthoc_gt1']=rem.gain_pp.iloc[0];g['remains_negative_after_gt1']=bool(rem.gain_pp.iloc[0]<0) if pd.notna(rem.gain_pp.iloc[0]) else None;g['diagnosis']='DESCRIPTIVE_OPTICAL_ELECTRICAL_DISCORDANCE';cases.append(g[['dataset','scope','unit_id','split_group','sample_id','target','PAIR_ABS','rank','selected_top25','target_lt2','top25_and_target_lt2','gain_after_posthoc_gt1','remains_negative_after_gt1','diagnosis']])
 csv(out/'DISCORDANCE_CASES.csv',pd.concat(cases,ignore_index=True))
 raw=pd.read_hdf(D1DIR/'training_extracted_features_and_labels.h5','df');r=raw[(raw.substrateID=='AEM')&(raw.patchID==21)];assert len(r)==1;v=np.asarray(r.iloc[0].LP725,float);iqr=np.quantile(v,.75)-np.quantile(v,.25);norm=(v-np.median(v))/iqr if iqr>1e-12 else np.full(len(v),np.nan);csv(out/'AEM_PL_TRACE.csv',pd.DataFrame({'sample_id':'D1::AEM::21','frame_index':np.arange(len(v)),'LP725_raw':v,'LP725_median_IQR_normalized':norm}));dump(out/'AEM_PL_TRACE_AUDIT.json',{'source':str(D1DIR/'training_extracted_features_and_labels.h5'),'source_SHA256':sha(D1DIR/'training_extracted_features_and_labels.h5'),'n_frames':len(v),'raw_min':float(np.min(v)),'raw_max':float(np.max(v)),'raw_mean':float(np.mean(v)),'nonfinite_frames':int((~np.isfinite(v)).sum()),'normalization':'full719trace median/IQR, descriptive only','no_physical_failure_stage_inferred':True})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=R);p.add_argument('--smoke',action='store_true');a=p.parse_args();smoke() if a.smoke else run(a.output.resolve())
