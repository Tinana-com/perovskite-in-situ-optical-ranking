"""Named-feature adapter around exact archived P6 blocks and P4 pair construction."""
import ast,types,warnings,gc
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits
from common import *

def archived_definitions():
 ns={'np':np,'pd':pd,'KEYS':KEYS,'StandardScaler':StandardScaler,'p4':types.SimpleNamespace(F2=F2),'p5':types.SimpleNamespace(STATS=[])}
 path=P6/'reference_source/p6_core.py';nodes=[n for n in ast.parse(path.read_text(encoding='utf8')).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ['require','Preprocessor']];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns)
 pp={'np':np,'pd':pd,'GROUP':['date','expID']};path=P6/'reference_source/p4_reference.py';nodes=[n for n in ast.parse(path.read_text(encoding='utf8')).body if isinstance(n,ast.FunctionDef) and n.name=='construct_pairs'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),pp)
 return ns['Preprocessor'],pp['construct_pairs']
OriginalPreprocessor,construct_pairs=archived_definitions()
class SubsetPreprocessor(OriginalPreprocessor):
 """Only fit-time statistic selection changes; original block/transform are inherited."""
 def fit(self,f):
  if set(f)!=set(KEYS+F2):raise ValueError('Optical preprocessing accepts identifiers and named ABS12 only')
  self.stats_=list(self.spec['feature_names_subset']);assert set(self.stats_)<=set(F2)
  self.floor_=np.maximum(1e-12,.01*np.median(abs(f[self.stats_].to_numpy()),axis=0));self.names_=([f'ID_{v}' for v in self.c['categories']] if self.spec['position']=='IDPL' else [])+['REL_'+n for n in self.stats_]
  self.scaler_=StandardScaler().fit(self.block(f));return self
def fit(train_labels,train_opt,eval_opt,columns,position,c):
 spec={'position':'IDPL' if position else 'PL','representation':'REL','feature_names_subset':columns};pre=SubsetPreprocessor('D2',spec,c).fit(train_opt);lookup=pd.DataFrame(pre.transform(train_opt),index=train_opt.sample_id);yy=train_labels.sort_values(['split_group','unit_id','sample_id']).reset_index(drop=True);x=lookup.loc[yy.sample_id].to_numpy();a=yy[KEYS].copy();a['date']=a.split_group.astype(int);a['expID']=a.unit_id;a['PCE_backward']=yy.target.to_numpy();xx,y,w,audit,pairids=construct_pairs(a[['sample_id','date','expID','patchID','PCE_backward']],x,.5);model=LogisticRegression(random_state=SEED,**c['models']['PAIRWISE'])
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always');model.fit(xx,y,sample_weight=w)
 stable=not any(isinstance(v.message,ConvergenceWarning) for v in caught);pred=model.decision_function(pre.transform(eval_opt));status={'status':'PASS' if stable else 'NOT_STABLE','iterations':int(model.n_iter_[0]),'warnings':' | '.join(str(v.message) for v in caught),'n_ordered_pairs':len(y),'pair_weight_sum':float(sum(w)),'pair_ID_sha256':hashlib.sha256('\n'.join(pairids).encode()).hexdigest(),'n_pairs_excluded_near_ties':int(audit.near_tie_pairs_excluded_from_training_only.sum()),'n_units_without_usable_pairs':int(audit.usable_unordered_pairs.eq(0).sum())}
 params={'floor':pre.floor_,'scaler_mean':pre.scaler_.mean_,'scaler_scale':pre.scaler_.scale_,'coef':model.coef_[0],'feature_names':np.array(columns,str),'transformed_feature_names':np.array(pre.names_,str),'categories':np.array(c['categories'],int),'position':np.array([position]),'train_optical_ids':train_opt.sample_id.to_numpy(str),'train_label_ids':yy.sample_id.to_numpy(str)}
 return pred,status,params,audit
def predict_saved(model,opt):
 columns=model['feature_names'].tolist();x=opt[columns];med=opt.groupby('unit_id',sort=False)[columns].transform('median');mad=(x-med).abs().groupby(opt.unit_id,sort=False).transform('median');block=(x.to_numpy()-med.to_numpy())/np.maximum(1.4826*mad.to_numpy(),model['floor'])
 if bool(model['position'][0]):block=np.column_stack([(opt.patchID.to_numpy()[:,None]==model['categories'][None,:]).astype(float),block])
 return ((block-model['scaler_mean'])/model['scaler_scale'])@model['coef']
def inputs():
 p=read(B/'FROZEN_EXPERIMENTS.json');f=pd.read_csv(CACHE);raw=pd.read_hdf(RAW,'df');assert len(f)==11136 and f.PCE_backward.notna().sum()==5857
 for n in ['date','expID','patchID']:assert np.array_equal(raw[n].astype(str),f[n].astype(str)),n
 assert np.allclose(raw.PCE_backward,f.PCE_backward,atol=1e-10,equal_nan=True);del raw
 opt=pd.DataFrame({'sample_id':f.sample_id,'unit_id':f.date.astype(str)+'::'+f.expID,'split_group':f.date.astype(str),'patchID':f.patchID.astype(int)});opt=pd.concat([opt,f[F2]],axis=1);assert np.isfinite(opt[F2]).all().all();meta=archived();meta=meta[meta.dataset=='D2'].copy();targetlookup=pd.Series(f.PCE_backward.to_numpy(),index=f.sample_id);assert np.allclose(meta.target,targetlookup.loc[meta.sample_id],atol=1e-10,rtol=0);y=meta[KEYS+['scope','outer_fold','phase']].copy();y['target']=targetlookup.loc[meta.sample_id].to_numpy();return opt,y,meta
def variants():
 p=read(B/'FROZEN_EXPERIMENTS.json');v={name:[f'{ch}_{s}' for ch in cs for s in STATS] for name,cs in p['d2_ablation_variants'].items()};v.update({name:[f'{ch}_{s}' for ch in CHANNELS for s in ss] for name,ss in p['d2_stat_ablation_variants'].items()});order_=p['d2_primary_model_variants']+[n for n in v if n not in p['d2_primary_model_variants']];return [(n,mode,v[n]) for n in order_ for mode in p['d2_model_input_modes']]
def evaluate_scores(scores,labels):
 q=scores.merge(labels[KEYS+['target']],on=KEYS,validate='many_to_one');rows=[]
 for (scope,mid,unit),g in q.groupby(['scope','model_id','unit_id'],sort=True):rows.append({'dataset':'D2','scope':scope,'unit_id':unit,'split_group':str(g.split_group.iloc[0]),'date':int(g.split_group.iloc[0]),'expID':unit.split('::')[-1],'model_id':mid,'variant':g.variant.iloc[0],'input_mode':g.input_mode.iloc[0],'new_training':True,'fit_status':g.fit_status.iloc[0],**gain(g.sample_id,g.target,g.score)})
 return pd.DataFrame(rows)
def reconciliation(scores,meta,phase):
 rows=[]
 for mode,oldcol in [('OPTICAL_ONLY_REL','PL_PAIRWISE'),('POSITION_PLUS_OPTICAL_REL','ID_PLUS_PL_PAIRWISE')]:
  s=scores[(scores.variant=='FULL4')&(scores.input_mode==mode)];ref=meta[meta.phase==phase].set_index('sample_id');s=s.set_index('sample_id');assert set(s.index)==set(ref.index);dif=np.abs(s.score-ref.loc[s.index,oldcol]);mismatch=0
  for unit,g in ref.groupby('unit_id'):
   pred=s.loc[g.index];k=kceil(.25,len(g));oldsel=g.index[order(g.index,g[oldcol])[:k]];newsel=pred.index[order(pred.index,pred.score)[:k]];mismatch+=int(set(oldsel)!=set(newsel))
  ok=float(dif.max())<1e-8 and mismatch==0 and s.fit_status.eq('PASS').all();rows.append({'dataset':'D2','phase':phase,'input_mode':mode,'model_id':'FULL4__'+mode,'reference_model':oldcol,'max_absolute_score_difference':float(dif.max()),'Top25_selection_mismatched_experiments':mismatch,'status':'PASS' if ok else 'FAILED_QA'})
 return pd.DataFrame(rows)
def run():
 start=time.perf_counter();p=read(B/'FROZEN_EXPERIMENTS.json');c=read(P6/'configs/frozen_p6_protocol.json');config=variants();(B/'runs/models').mkdir(exist_ok=True,parents=True);scorelist=[];fits=[];pairaudits=[];configrows=[];recon=[];identity=[]
 if not CACHE.exists() or not RAW.exists():
  csv(R/'D2_ABLATION_CONFIGS.csv',pd.DataFrame([{'variant':n,'input_mode':m,'status':'BLOCKED_MISSING_INPUT'} for n,m,cols in config]));return
 opt,y,meta=inputs();(B/'prepared').mkdir(exist_ok=True);csv(B/'prepared/D2_OPTICAL_ABS12.csv',opt);csv(B/'prepared/D2_LABELS_FOR_SCORING.csv',y);csv(R/'D2_FEATURE_NAME_MAP.csv',pd.DataFrame([{'channel':ch,'statistic':stat,'cache_column':f'{ch}_{stat}','ABS12_index':F2.index(f'{ch}_{stat}')} for ch in CHANNELS for stat in STATS]))
 with threadpool_limits(limits=4):
  for phase in ['dev','history']:
   for v,mode,cols in config:
    elapsed=time.time()-read(B/'RUN_RECEIPTS/start.json')['unix_time'];core=v in p['d2_primary_model_variants'];mid=v+'__'+mode
    if not within_budget() or (elapsed>5400 and not core):configrows.append({'dataset':'D2','phase':phase,'variant':v,'input_mode':mode,'model_id':mid,'n_optical_features':len(cols),'status':'NOT_RUN_BUDGET'});continue
    before=len(scorelist);cases=[(i,[str(d) for d in p['d2_development_dates'] if d not in va],list(map(str,va))) for i,va in enumerate(p['d2_outer_date_folds'])] if phase=='dev' else [(-1,list(map(str,p['d2_development_dates'])),list(map(str,p['d2_history_dates'])))];cfgstatus='PASS'
    for fold,tr,va in cases:
     if not within_budget():cfgstatus='NOT_RUN_BUDGET';break
     begin=time.perf_counter();assert not set(tr)&set(va);trainopt=opt[opt.split_group.isin(tr)].reset_index(drop=True);evopt=opt[opt.split_group.isin(va)].reset_index(drop=True);train=y[y.split_group.isin(tr)].reset_index(drop=True);eid=y[y.split_group.isin(va)][KEYS+['scope']].copy()
     try:
      pred,st,params,audit=fit(train[KEYS+['target']],trainopt,evopt,cols,mode.startswith('POSITION'),c);lookup=pd.Series(pred,index=evopt.sample_id);s=eid.copy();s['score']=lookup.loc[s.sample_id].to_numpy();s['outer_fold']=fold;s['model_id']=mid;s['variant']=v;s['input_mode']=mode;s['fit_status']=st['status'];scorelist.append(s);np.savez_compressed(B/'runs/models'/f'{mid}__{phase}__{fold}.npz',**params);audit['phase']=phase;audit['outer_fold']=fold;audit['model_id']=mid;pairaudits.append(audit)
      fits.append({'dataset':'D2','phase':phase,'variant':v,'input_mode':mode,'model_id':mid,'outer_fold':fold,'n_train_optical':len(trainopt),'n_train_labels':len(train),'n_eval_optical':len(evopt),'n_eval_regions':len(eid),'wall_seconds':time.perf_counter()-begin,**st});identity.append({'model_id':mid,'phase':phase,'fold':fold,'train_dates':json.dumps(tr),'eval_dates':json.dumps(va),'n_date_overlap':0,'floor_scaler_fit_ID_hash':ihash(trainopt.sample_id),'train_label_ID_hash':ihash(train.sample_id),'eval_ID_hash':ihash(evopt.sample_id),'validation_labels_passed_into_fit':False})
      if st['status']!='PASS':cfgstatus='NOT_STABLE'
     except Exception as exc:
      fits.append({'dataset':'D2','phase':phase,'model_id':mid,'outer_fold':fold,'status':'NOT_STABLE','error':repr(exc),'wall_seconds':time.perf_counter()-begin});cfgstatus='NOT_STABLE';break
    configrows.append({'dataset':'D2','phase':phase,'variant':v,'input_mode':mode,'model_id':mid,'n_optical_features':len(cols),'n_model_features':len(cols)+(32 if mode.startswith('POSITION') else 0),'feature_names':'|'.join(cols),'status':cfgstatus,'new_training':True})
    current=pd.concat(scorelist,ignore_index=True) if scorelist else pd.DataFrame();csv(R/'D2_ABLATION_OOF_SCORES.csv',current);csv(R/'D2_TRAINING_DIAGNOSTICS.csv',pd.DataFrame(fits));csv(R/'D2_ABLATION_CONFIGS.csv',pd.DataFrame(configrows));csv(R/'D2_TRAINING_IDENTITY_AUDIT.csv',pd.DataFrame(identity));print(phase,mid,cfgstatus,'elapsed',round(time.perf_counter()-start,2),flush=True)
    if v=='FULL4' and mode==p['d2_model_input_modes'][-1]:
     r=reconciliation(current[current.scope==eid.scope.iloc[0]],meta,phase);recon.append(r);csv(R/'D2_FULL4_RECONCILIATION.csv',pd.concat(recon,ignore_index=True))
     if not r.status.eq('PASS').all():
      dump(R/'D2_ABLATION_PROTOCOL_BLOCK.json',{'status':'FAILED_QA','reason':'FULL4 does not faithfully reproduce archived counterpart; stop quantitative channel attribution','reconciliation':r.astype(object).where(r.notna(),None).to_dict('records')});return
    gc.collect()
 score=pd.concat(scorelist,ignore_index=True);metrics=evaluate_scores(score,y);csv(R/'D2_ABLATION_BY_EXPERIMENT.csv',metrics);date=independent(metrics,['dataset','scope','model_id','variant','input_mode'],['gain_pp','rho','overlap']);csv(R/'D2_ABLATION_BY_DATE.csv',date);csv(R/'D2_ABLATION_MACRO.csv',macro(date,['dataset','scope','model_id','variant','input_mode'],['gain_pp','rho','overlap']));csv(R/'D2_ABLATION_HISTORY.csv',metrics[metrics.scope.str.contains('HISTORY')]);csv(R/'D2_TRAINING_PAIR_AUDIT.csv',pd.concat(pairaudits,ignore_index=True));csv(R/'D2_ABLATION_FAILURE_GROUPS.csv',metrics[(metrics.gain_pp<0)|(metrics.rho<0)|metrics.rho.isna()]);ablation_contrasts(date,meta)
 import psutil
 mem=psutil.Process().memory_info();dump(B/'RUN_RECEIPTS/ablation_resources.json',{'wall_seconds':time.perf_counter()-start,'fits_completed':len(fits),'peak_working_set_bytes':getattr(mem,'peak_wset',mem.rss),'threads':4,'original_preprocessor_block_and_transform_executed':True,'original_pair_constructor_executed':True,'D1_fits':0,'random_seed':SEED,'protocol_sha256':sha(B/'FROZEN_EXPERIMENTS.json')});print('Ablation finished',len(fits),'fits',flush=True)
def ablation_contrasts(date,meta):
 ref=[]
 for (scope,u),g in meta.groupby(['scope','unit_id']):ref.append({'scope':scope,'split_group':str(g.split_group.iloc[0]),'gain_pp':gain(g.sample_id,g.target,g.ID_PAIRWISE)['gain_pp']})
 ref=pd.DataFrame(ref).groupby(['scope','split_group']).gain_pp.mean();rows=[]
 for scope,g in date.groupby('scope'):
  for mode in g.input_mode.unique():
   dd=g[g.input_mode==mode].set_index(['variant','split_group']);pairs=[('PL3','FULL4'),('ND1','PL3'),('LEVEL8','SLOPE4')]
   for v,w in pairs:
    if v not in set(g.variant) or w not in set(g.variant):continue
    for m in ['gain_pp','rho','overlap']:
     delta=dd.loc[v,m]-dd.loc[w,m];val,lo,hi,n=ci(delta);rows.append({'dataset':'D2','scope':scope,'input_mode':mode,'method_a':v,'method_b':w,'metric':m,'value':val,'CI_low':lo,'CI_high':hi,'n_dates':n,'status':'PASS'})
   if mode.startswith('POSITION'):
    for v in g.variant.unique():
     delta=dd.loc[v,'gain_pp']-ref.loc[scope];val,lo,hi,n=ci(delta);rows.append({'dataset':'D2','scope':scope,'input_mode':mode,'method_a':v,'method_b':'ARCHIVED_ID_PAIRWISE','metric':'gain_pp','value':val,'CI_low':lo,'CI_high':hi,'n_dates':n,'status':'PASS'})
 csv(R/'D2_ABLATION_PAIRED_CONTRASTS.csv',pd.DataFrame(rows))
if __name__=='__main__':run()
