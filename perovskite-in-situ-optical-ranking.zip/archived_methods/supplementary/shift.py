"""Frozen ABS12 date distance, constructed and hashed before outcome joining."""
from scipy.stats import pearsonr,spearmanr
from common import *
def date_vectors(opt):
 if set(opt)!=set(KEYS+F2):raise PermissionError('Drift accepts optical whitelist only')
 unit=opt.groupby(['split_group','unit_id'],sort=True)[F2].mean().reset_index();return unit.groupby('split_group',sort=True)[F2].mean()
def distance(vector,training):
 mu=training.mean(axis=0);sd=training.std(axis=0,ddof=1);floor=np.maximum(1e-12,.01*np.median(abs(training.to_numpy()),axis=0));z=abs(vector.to_numpy()-mu.to_numpy())/np.maximum(sd.to_numpy(),floor);return z,mu.to_numpy(),sd.to_numpy(),floor
def run(out=R):
 start=time.perf_counter();out.mkdir(exist_ok=True,parents=True);p=read(B/'FROZEN_EXPERIMENTS.json');f=pd.read_csv(CACHE);opt=pd.DataFrame({'sample_id':f.sample_id,'unit_id':f.date.astype(str)+'::'+f.expID,'split_group':f.date.astype(str),'patchID':f.patchID.astype(int)});opt=pd.concat([opt,f[F2]],axis=1);m=date_vectors(opt);rows=[];details=[];all_dates=list(map(str,p['d2_development_dates']+p['d2_history_dates']))
 for d in all_dates:
  historical=int(d) in p['d2_history_dates'];valdates=next((v for v in p['d2_outer_date_folds'] if int(d) in v),[]);trdates=list(map(str,p['d2_development_dates'])) if historical else [str(x) for x in p['d2_development_dates'] if x not in valdates];assert d not in trdates;z,mu,sd,floor=distance(m.loc[d],m.loc[trdates]);rows.append({'dataset':'D2','date':int(d),'split_group':d,'scope':'D2_HISTORY_PREVIOUSLY_INSPECTED' if historical else 'D2_DEVELOPMENT_REUSED_DATES','D_all12':float(z.mean()),'D_PL9':float(z[:9].mean()),'D_ND3':float(z[9:].mean()),'training_dates':'|'.join(trdates),'n_training_dates':len(trdates),'n_optical_regions':int(opt.split_group.eq(d).sum()),'n_optical_experiments':opt[opt.split_group==d].unit_id.nunique(),'PCE_used_for_distance':False,'status':'PASS'})
  for i,name in enumerate(F2):details.append({'dataset':'D2','date':int(d),'feature_name':name,'date_optical_mean':float(m.loc[d,name]),'training_mu':float(mu[i]),'training_sigma_ddof1':float(sd[i]),'training_floor':float(floor[i]),'absolute_standardized_distance':float(z[i]),'training_dates':'|'.join(trdates),'PCE_used':False})
 outdf=pd.DataFrame(rows);csv(out/'D2_DATE_SHIFT.csv',outdf);csv(out/'D2_DATE_SHIFT_REFERENCE_DETAILS.csv',pd.DataFrame(details));dump(out/'D2_SHIFT_PRE_LABEL_HASH.json',{'shift_sha256':sha(out/'D2_DATE_SHIFT.csv'),'reference_sha256':sha(out/'D2_DATE_SHIFT_REFERENCE_DETAILS.csv'),'no_targets_used':True,'formula_fixed':True})
 f=archived();f=f[f.dataset=='D2'];met=[]
 for (scope,unit),g in f.groupby(['scope','unit_id']):met.append({'dataset':'D2','scope':scope,'split_group':str(g.split_group.iloc[0]),'unit_id':unit,'ID_gain_pp':gain(g.sample_id,g.target,g.ID_PAIRWISE)['gain_pp'],'ID_PLUS_OPTICAL_gain_pp':gain(g.sample_id,g.target,g.ID_PLUS_PL_PAIRWISE)['gain_pp']})
 md=pd.DataFrame(met).groupby(['scope','split_group'])[['ID_gain_pp','ID_PLUS_OPTICAL_gain_pp']].mean().reset_index();md['archived_optical_increment_pp']=md.ID_PLUS_OPTICAL_gain_pp-md.ID_gain_pp;j=outdf.merge(md,on=['scope','split_group'],validate='one_to_one');csv(out/'D2_SHIFT_VS_GAIN.csv',j);cor=[]
 for scope,g in j.groupby('scope'):
  for col in ['D_all12','D_PL9','D_ND3']:
   valid=np.ptp(g[col])>0 and np.ptp(g.archived_optical_increment_pp)>0;cor.append({'dataset':'D2','scope':scope,'distance':col,'n_independent_dates':len(g),'Pearson':float(pearsonr(g[col],g.archived_optical_increment_pp).statistic) if valid else np.nan,'Spearman':float(spearmanr(g[col],g.archived_optical_increment_pp).statistic) if valid else np.nan,'status':'EXPLORATORY_DESCRIPTIVE' if valid else 'UNDEFINED_CONSTANT','historical_tuning':False})
 csv(out/'D2_SHIFT_CORRELATIONS.csv',pd.DataFrame(cor));dump(out/'shift_receipt.json',{'wall_seconds':time.perf_counter()-start,'new_models':0,'distance_uses_all_optical_experiments_in_date':True,'labels_joined_after_distance_hash':True});print('Shift complete,17 dates; no model or threshold fit',flush=True)
if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('--output',type=Path,default=R);args=a.parse_args();run(args.output.resolve())
