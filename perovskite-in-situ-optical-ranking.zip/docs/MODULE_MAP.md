# Source map

| Paper component | Portable command / implementation | Scientific reference |
|---|---|---|
| D1/D2 raw optical preparation | `src/prepare_data.py`, `src/dataset.py`, `src/rebuild_d2_cache.py` | `configs/frozen_p6_protocol.json` |
| Absolute/relative descriptors, Ridge, trees, LambdaRank and pairwise ranking | `src/train.py`, `src/portable_models.py`, `frozen_sources/P6/src/p6_core.py` | frozen model grid |
| Raw vs centered TabPFN training | `src/train_tabpfn.py`, `src/bar_rank/core.py` | `configs/bar_rank_protocol.json` |
| Fixed optical / joint fusion | `src/fuse_scores.py`, `src/bar_rank/core.py` | 0.5/0.5, unit-wise population z-scaling |
| Top25% gain, Spearman and overlap | `src/evaluate.py`, `src/reproduce_results.py` | substrate/date aggregation |
| Matched objective comparison | `src/run_controlled_objectives.py`, `archived_methods/extensions/exp5_controlled_loss_ablation.py` | archived fixed grids, not a new search |
| Channel ablation, multi-budget selection, AEM sensitivity and drift | `src/run_supplementary.py`, `archived_methods/supplementary/` | `configs/supplementary_experiments.json` |
| Regret and feature/target sign diagnostics | `archived_methods/extensions/exp6_conditional_utility_regret_and_sign_drift.py` | original source retained; see reproduction guide |
| Latest plotting | `src/reproduce_figures.py`, `analysis/manuscript5/src/` | exact manuscript5 input CSVs |
| Earlier complete figure set and exploratory algorithms | `paper_analysis/`, `frozen_sources/P7`, `P8`, `P9` | retained as supplementary sources |

Original frozen implementations preserve their historical function and model IDs. Public entry points use repository-relative paths or explicit input arguments. Standalone archived scripts may retain original workstation paths; use the portable commands above.
