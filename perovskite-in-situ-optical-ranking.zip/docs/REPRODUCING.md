# Reproduction guide

Run commands from the repository root and use a fresh output directory for each attempt. This release has three distinct paths: archived-result verification, supervised training from original inputs, and figure rendering.

## 1. Archived-result verification

```bash
python -m pip install -r requirements.txt
python src/reproduce_results.py --output outputs/check_01
python -m pytest tests -q
```

The result command regenerates target-free component/fusion scores, comparison-unit metrics, independent-group means and paired intervals. `reproduction_check.json` checks 18 baseline/raw/centered/optical-fusion/joint mean values against the archived results. It does not fit models or infer new predictions. Source targets are restored at full precision for D1 before evaluation.

## 2. Raw input preparation

```bash
python src/prepare_data.py --d1-train DATA/training_extracted_features_and_labels.h5 --d1-test DATA/test_extracted_features_and_labels.h5 --d2-h5 DATA/data.h5 --output outputs/prepared
```

Preparation checks H5 SHA256 values, original identities and frozen folds. D1 LP725 has 719 recorded frames. D2 contains LP725, LP780 and SP775 photoluminescence plus ND diffuse reflection; ND is not a PL channel. D1 uses `pce_mean`; the paper's D2 ranking task uses `PCE_backward`. The datasets are neither pooled nor relabeled into a common target.

D1: 780 development regions / 26 substrates / five original folds; 349 historical regions / 12 substrates. D2: 4,707 development regions / 158 experiments / 14 dates / seven date folds; 1,150 historical regions / 36 experiments / three dates. Zero-PCE samples remain.

## 3. Pairwise and classical model training

```bash
python src/train.py --prepared outputs/prepared --dataset D1 --models PAIR_ABS --output outputs/D1_pairwise --dry-run
python src/train.py --prepared outputs/prepared --dataset D2 --models PAIR_ABS --output outputs/D2_pairwise --dry-run
```

Remove `--dry-run` to train. Use `--models all` for all frozen baselines and inherited controls; use `--phase full` to additionally reproduce the previously viewed historical cohorts. No configuration is selected using historical labels. Classical estimators use the original frozen settings and one CPU thread.

Training writes saved model artifacts, target-free OOF scores and evaluation tables. An independent saved-model predictor is provided in `src/predict.py`; full usage is in `docs/legacy_training_guide.md`. Original supplementary P7/P8/P9 sources and explicit `src/run_extension.py` entrypoints are retained, with their original convergence/failure outcomes.

## 4. TabPFN raw, centered and joint branches

Use a separate Python environment. Install PyTorch 2.6.0 with the CPU/CUDA/ROCm build appropriate for your machine, then:

```bash
python -m pip install -r environments/requirements-tabpfn.txt
```

The original replay used `torch==2.6.0+rocm6.2.4` on Ubuntu and `tabpfn==9.2.0`. The complete recorded package list is retained as `environments/tabpfn_gpu_original.lock.txt`; it is a provenance record, not a platform-independent install recipe. TabPFN's adapter imports only its separate environment dependencies.

Obtain `tabpfn-v3.5-20260909.safetensors` from the [original model repository](https://huggingface.co/Prior-Labs/tabpfn_3_5), revision `06bf2ba35c80a92a3b9abb436b99cf49e7a0365e`, under its terms. Expected size: 876,027,932 bytes; SHA256: `ece4d67eadfea42eb0e610df5189bea60cb7f31073d81e9c7a019b76eacf0be3`. Model weights are not redistributed.

```bash
python src/train_tabpfn.py --prepared outputs/prepared --dataset D1 --variant centered --output outputs/D1_centered_plan --dry-run
python src/train_tabpfn.py --prepared outputs/prepared --dataset D2 --variant centered --device cuda --checkpoint MODELS/tabpfn-v3.5-20260909.safetensors --output outputs/D2_centered
python src/train_tabpfn.py --prepared outputs/prepared --dataset D2 --variant raw --device cuda --checkpoint MODELS/tabpfn-v3.5-20260909.safetensors --output outputs/D2_raw
python src/train_tabpfn.py --prepared outputs/prepared --dataset D2 --variant joint --device cuda --checkpoint MODELS/tabpfn-v3.5-20260909.safetensors --output outputs/D2_joint
```

`cuda` is the PyTorch device interface for the archived AMD ROCm build as well. `--device cpu` is available, with a substantially longer runtime. D1 supports raw/centered ABS12. D2 additionally supports the original `relative-slope` and `copula-slope` supplementary configurations. These are enumerated choices, not a search. The fixed settings are in `configs/bar_rank_protocol.json`.

Centering subtracts each training comparison unit's mean training target. Validation PCE never enters X, y, centering or prediction. Position-augmented D2 adds the fixed 32-category one-hot patch identity block. Each fold saves its scores before evaluation labels are merged. Scores can vary slightly across accelerator libraries; compare ranking metrics as well as numerical scores.

## 5. Fixed fusion and evaluation

```bash
python src/fuse_scores.py --pair-scores outputs/D2_pairwise/predictions_BEFORE_label_merge.csv --tabpfn-scores outputs/D2_centered/predictions_BEFORE_label_merge.csv --tabpfn-model D2_TABPFN_CTR_ABS12 --output outputs/D2_optical_fusion
python src/evaluate.py --prepared outputs/prepared --dataset D2 --predictions outputs/D2_optical_fusion/predictions_BEFORE_label_merge.csv --output outputs/D2_optical_evaluation
```

For joint fusion use `D2_TABPFN_CTR_IDPL44`. For D1 use `D1_TABPFN_CTR_ABS12`. Both components must contain the same identities, phases, scopes and outer folds. Fusion rejects target columns and cohort mismatches. Each component is standardized independently within the current comparison unit using population standard deviation (`ddof=0`, floor `1e-12`), then averaged with weights 0.5/0.5.

## 6. Controlled comparisons and supplementary analyses

```bash
python src/run_controlled_objectives.py --prepared outputs/prepared --output outputs/controlled_plan --dry-run
python src/run_supplementary.py --analysis channel-ablation --output outputs/channel_plan --dry-run
python src/run_supplementary.py --analysis decisions-and-drift --output outputs/decision_plan --dry-run
```

Remove `--dry-run` to execute the selected archived experiment. The controlled-objective command preserves the original fixed DEFAULT settings and bounded inner-CV grids; it can take hours. Channel ablation needs `--d2-h5 DATA/data.h5` and runs the original pairwise fits. Decision/AEM/drift analysis needs `--d1-directory DATA` containing both D1 H5 files and uses archived predictions. No experiment starts automatically.

The original regret/sign-diagnostic implementation is retained under `archived_methods/extensions/exp6_conditional_utility_regret_and_sign_drift.py`, including its original supplementary slope fits. Its historical workstation paths are provenance; use the portable wrappers for the main tasks. The exact derived diagnostic CSVs used by manuscript5 are bundled in `analysis/manuscript5/EVIDENCE/extensions/`. Outcome-conditioned stratification is descriptive; its originally reported unit-bootstrap intervals remain archived without being reinterpreted as date-cluster inference.

## 7. Figure rendering

```bash
python src/reproduce_figures.py --output outputs/figures_01
```

The command reuses the latest plotting functions and retained original plate functions. It exports PDF, editable SVG and 600-dpi PNG to a new directory. Manuscript5's workflow/graphical-abstract acquisition asset is an archived generated schematic, not an experimental image; its use is recorded, and an Elsevier-ready graphical abstract needs a replacement created with an appropriate illustration workflow. Rendering this archive does not certify publisher image compliance. Text layout uses Arial when installed; a different font environment can alter label placement.

## Evaluation and data roles

- Top25% count: `max(1, ceil(0.25*n))`; ties use stable sample identity.
- Gain: selected mean measured PCE minus the comparison-unit mean, in percentage points.
- Spearman uses average ranks; constant scores or targets give an undefined correlation.
- Overlap: intersection of predicted and actual top-quarter sets divided by the selection count.
- D1 independent bootstrap unit: substrate. D2: date after averaging experiments equally.
- Bootstrap: 10,000 draws, seed 20261019; development and history are reported separately.
- Historically viewed groups retain their original identities and are not a new blind test.

## Validation record

See `VALIDATION_STATUS.json` for the checks actually completed during packaging. This task did not rerun supervised training. The new portable adapters preserve the archived features, model arguments, targets and fusion formula; dry-run and label-intervention tests check their interfaces and isolation. Original replay scripts are included for comparison.
