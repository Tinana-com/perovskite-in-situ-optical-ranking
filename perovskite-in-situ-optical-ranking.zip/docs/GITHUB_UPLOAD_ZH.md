# 将解压后的源码上传到现有GitHub仓库

目标仓库：https://github.com/Tinana-com/perovskite-in-situ-optical-ranking

本次ZIP用于下载和传输。GitHub中应显示解压后的README、src、configs、analysis、tests等文件和目录。

## 推荐：使用GitHub Desktop一次上传完整目录

1. 打开GitHub Desktop并登录你的GitHub账号。
2. 选择 **File → Clone repository → URL**，输入上面的仓库地址，将其克隆到一个新的本地目录。
3. 解压本次交付ZIP，打开里面的 `perovskite-in-situ-optical-ranking` 文件夹。
4. 将这个文件夹**里面的全部内容**复制到刚克隆的仓库目录。README.md应位于仓库根目录，和src、configs等文件夹并列。保留克隆产生的 `.git` 文件夹。
5. 回到GitHub Desktop，在Changes中检查改动。不要选择原始H5、模型权重、账号凭据或运行缓存；本包已不包含这些文件，并提供.gitignore。
6. 在Summary填写 `Add complete BAR-Rank training and reproduction source`，点击 **Commit to main**，然后 **Push origin**。若你采用分支审查，也可先创建分支后合并。
7. 打开网页刷新。确认首页显示新的README；能点击查看 `src/train.py`、`src/train_tabpfn.py`、`src/fuse_scores.py` 和 `configs/bar_rank_protocol.json`。

原有V1 ZIP可以暂时保留，不影响新版文件浏览。需要整理时可将旧ZIP作为历史Release附件保留；本次没有删除或覆盖云端历史文件。

## 发布一个可引用版本

确认源码已进入默认分支后，在仓库网页选择 **Releases → Draft a new release**，创建标签 `v2.0.0`，标题可用 `BAR-Rank manuscript5 reproduction release`。说明本版新增完整训练、中心化目标、固定融合、逐样本结果复算和绘图入口。发布前确认仓库还没有同名标签；有则选用下一个未使用版本号。

论文中可以引用仓库地址，并标明实际发布的版本/提交。获得软件归档DOI后再补入，不能预先填写不存在的DOI。

## 仅用网页上传

在仓库首页选择 **Add file → Upload files**，拖入解压后的文件和文件夹，保持目录层级。不要拖入整个ZIP，也不要多套一层同名文件夹。

GitHub网页每次最多上传100个文件、单文件限制25 MiB。本包文件数量超过100，网页需要按模块分批上传；因此完整发布更适合GitHub Desktop。每批上传后填写提交说明并确认保存。

官方说明：https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository

## 最后核对

- 仓库首页直接呈现README，复现命令可复制。
- 训练源码、配置、测试和逐样本参考结果均可浏览。
- Code Availability中的链接打开后能找到本文新增中心化与融合实现。
- 没有将原始H5和876 MB预训练权重上传到Git历史。
- LICENSE、第三方许可、数据来源和CITATION.cff都已保留。

本交付只准备了发布材料，没有代你向远端仓库提交。
