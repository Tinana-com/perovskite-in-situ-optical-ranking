"""Run the original channel ablation or archived-score decision analyses."""
from pathlib import Path
import argparse,shutil,sys,time
from release_common import B,fresh_output,dump

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--analysis',choices=['channel-ablation','decisions-and-drift'],required=True)
    p.add_argument('--d1-directory',type=Path);p.add_argument('--d2-h5',type=Path)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--dry-run',action='store_true');args=p.parse_args()
    out=fresh_output(args.output)
    if args.dry_run:
        dump(out/'plan.json',{'analysis':args.analysis,'model_fits':0,
            'fits_on_execution':args.analysis=='channel-ablation','protocol':'configs/supplementary_experiments.json'})
        return
    if args.analysis=='channel-ablation' and (not args.d2_h5 or not args.d2_h5.is_file()):
        raise FileNotFoundError('Channel ablation requires the original D2 H5')
    if args.analysis=='decisions-and-drift' and not args.d1_directory:
        raise ValueError('AEM trace audit requires --d1-directory with the original D1 feature H5 files')
    (out/'results').mkdir();(out/'RUN_RECEIPTS').mkdir()
    shutil.copyfile(B/'configs/supplementary_experiments.json',out/'FROZEN_EXPERIMENTS.json')
    dump(out/'RUN_RECEIPTS/start.json',{'unix_time':time.time()})
    sys.path.insert(0,str(B/'archived_methods/supplementary'))
    import common
    common.B=out;common.R=out/'results';common.REF=B/'paper_analysis';common.P6=B/'reference_results/P6'
    common.CACHE=B/'data_cache/d2_extracted_features.csv';common.RAW=args.d2_h5
    common.D1DIR=args.d1_directory
    if args.analysis=='channel-ablation':
        import ablation
        ablation.run()
    else:
        import postprocess,shift
        postprocess.run(common.R);shift.run(common.R)

if __name__=='__main__':main()
