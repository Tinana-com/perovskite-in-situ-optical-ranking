"""Portable adapter for the archived matched-objective experiment."""
from pathlib import Path
import argparse,sys
from release_common import B,fresh_output,dump

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepared',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--dry-run',action='store_true');args=p.parse_args()
    out=fresh_output(args.output)
    if args.dry_run:
        dump(out/'plan.json',{'experiment':'archived matched-objective comparison','model_fits':0,
            'prepared':str(args.prepared.resolve()),'source':'archived_methods/extensions/exp5_controlled_loss_ablation.py',
            'grid':'original DEFAULT and INNER_CV_TUNED settings, unchanged'})
        return
    sys.path.insert(0,str(B/'archived_methods/extensions'))
    import common as cm
    import os
    os.environ['NUMBA_CACHE_DIR']=str(out/'cache/numba')
    os.environ['MPLCONFIGDIR']=str(out/'cache/matplotlib')
    cm.GEMINI_DIR=out;cm.SOURCE_P6=B/'reference_results/P6';cm.ANALYSIS_DIR=B/'analysis/manuscript5/INPUTS/legacy'
    import exp5_controlled_loss_ablation as experiment
    experiment.PREPARED_DIR=args.prepared.resolve()
    experiment.OUT_CSV=out/'exp5_controlled_loss_ablation.csv'
    experiment.OUT_PREDS_SUMMARY=out/'exp5_inner_cv_selected_params.csv'
    experiment.run_exp5()

if __name__=='__main__':main()
