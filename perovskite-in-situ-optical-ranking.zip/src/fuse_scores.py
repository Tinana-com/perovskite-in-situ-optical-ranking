"""Fuse target-free pairwise and TabPFN predictions with fixed equal weights."""
from pathlib import Path
import argparse
import pandas as pd
from release_common import fresh_output,dump
from bar_rank.core import KEYS,fuse_scores,validate_scores

def select(frame,model):
    if 'model_id' in frame:
        frame=frame[frame.model_id==model].copy()
    elif 'method_id' in frame:
        frame=frame[frame.method_id==model].copy()
    if frame.empty:raise ValueError('Requested predictor is absent: '+model)
    validate_scores(frame)
    return frame

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--pair-scores',type=Path,required=True)
    p.add_argument('--tabpfn-scores',type=Path,required=True);p.add_argument('--pair-model',default='PAIR_ABS')
    p.add_argument('--tabpfn-model',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    read=lambda f:pd.read_csv(f,dtype={'split_group':str},float_precision='round_trip')
    pair=select(read(args.pair_scores),args.pair_model);aux=select(read(args.tabpfn_scores),args.tabpfn_model)
    q=fuse_scores(pair,aux)
    meta=['dataset','scope','outer_fold','phase']
    missing=set(meta)-set(pair)
    if missing or not set(meta)<=set(aux):raise ValueError('Prediction files need dataset/scope/outer_fold/phase')
    check=pair[KEYS+meta].merge(aux[KEYS+meta],on=KEYS,validate='one_to_one',suffixes=('_pair','_aux'))
    for c in meta:
        if not check[c+'_pair'].equals(check[c+'_aux']):raise ValueError('Fusion folds or cohorts differ: '+c)
    q=q.merge(pair[KEYS+meta],on=KEYS,validate='one_to_one')
    q['model_id']='BAR_JOINT' if args.tabpfn_model.endswith('IDPL44') else 'BAR_OPTICAL'
    out=fresh_output(args.output);q.to_csv(out/'predictions_BEFORE_label_merge.csv',index=False,float_format='%.17g')
    dump(out/'fusion_receipt.json',{'weights':[0.5,0.5],'population_std_ddof':0,'std_floor':1e-12,
        'label_columns_read':False,'model_fits':0,'rows':len(q)})
    print('Fused',len(q),'regions with fixed weights')

if __name__=='__main__':main()
