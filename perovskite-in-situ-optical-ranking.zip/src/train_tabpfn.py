"""Train one frozen TabPFN configuration using the original outer groups."""
from pathlib import Path
import argparse,hashlib,json,time,warnings,sys
import numpy as np
import pandas as pd
from dataset import Dataset
from release_common import B,fresh_output,dump,sha,read_json
from bar_rank.core import SEED,KEYS,VARIANTS,fold_inputs

def frame_csv(frame,path):frame.to_csv(path,index=False,float_format='%.17g',lineterminator='\n')

def run(args):
    data=Dataset(args.prepared,args.dataset);data.validate_cohort()
    if args.dataset=='D1' and args.variant not in ['raw','centered']:
        raise ValueError('Only raw/centered ABS12 are defined for D1')
    out=fresh_output(args.output);plans=[]
    phases=['development','history'] if args.phase=='full' else ['development']
    for phase in phases:
        for fold,tr,ev in data.cases(phase):
            x,y,v,keys,train,columns=fold_inputs(data,tr,ev,args.variant)
            plans.append({'phase':phase,'fold':fold,'train_groups':sorted(tr),'evaluation_groups':sorted(ev),
                          'training_rows':len(train),'evaluation_rows':len(keys),'input_columns':columns,
                          'n_features':x.shape[1],'zero_training_targets':int((train.target==0).sum()),
                          'training_X_y_sha256':hashlib.sha256(x.tobytes()+y.tobytes()).hexdigest(),
                          'validation_labels_used_for_fitting':False})
    dump(out/'training_plan.json',plans)
    if args.dry_run:
        dump(out/'run_receipt.json',{'status':'DRY_RUN_NO_MODEL_FITS','model_fits':0,'cases':len(plans)})
        print('Validated',len(plans),'outer cases; zero fits');return
    if not args.checkpoint or not args.checkpoint.is_file():
        raise FileNotFoundError('Supply the licensed tabpfn-v3.5-20260909.safetensors checkpoint')
    protocol=read_json(B/'configs/bar_rank_protocol.json')
    checkpoint_hash=sha(args.checkpoint)
    if checkpoint_hash!=protocol['checkpoint']['sha256']:
        raise ValueError('Checkpoint SHA256 does not match the archived model')
    import importlib.metadata
    import torch
    from tabpfn import TabPFNRegressor
    from tabpfn.constants import ModelVersion
    if importlib.metadata.version('tabpfn')!='9.2.0':
        raise ValueError('The frozen replay uses tabpfn==9.2.0')
    torch.set_num_threads(4);torch.set_num_interop_threads(1)
    if args.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA-compatible device unavailable; select --device cpu')
    name={'raw':'RAW_ABS12','centered':'CTR_ABS12','joint':'CTR_IDPL44',
          'relative-slope':'CTR_SLOPE_REL4','copula-slope':'CTR_SLOPE_COPULA4'}[args.variant]
    mid=f'{args.dataset}_TABPFN_{name}';scores=[];start=time.perf_counter()
    for case in plans:
        tr=set(case['train_groups']);ev=set(case['evaluation_groups']);phase=case['phase'];fold=case['fold']
        x,y,v,keys,train,_=fold_inputs(data,tr,ev,args.variant)
        dest=out/f'{phase}_fold{fold}';dest.mkdir();np.random.seed(SEED);torch.manual_seed(SEED);t=time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            model=TabPFNRegressor.create_default_for_version(ModelVersion.V3_5,model_path=args.checkpoint,
                device=args.device,random_state=SEED,n_estimators='auto',ignore_pretraining_limits=True,
                memory_saving_mode=True,n_preprocessing_jobs=1)
            model.fit(x,y)
            pred=np.concatenate([np.asarray(model.predict(v[i:i+64]),float) for i in range(0,len(v),64)])
        if not np.isfinite(pred).all():raise ValueError('Nonfinite predictions')
        result=keys.copy();result['score']=pred;result['dataset']=args.dataset;result['model_id']=mid
        result['outer_fold']=fold;result['phase']=phase
        result['scope']=read_json(B/'configs/frozen_p6_protocol.json')[args.dataset]['scope_dev' if phase=='development' else 'scope_test']
        frame_csv(result,dest/'scores_BEFORE_label_merge.csv');scores.append(result)
        dump(dest/'fit_receipt.json',{**case,'wall_seconds':time.perf_counter()-t,'checkpoint_sha256':checkpoint_hash,
            'n_estimators_resolved':getattr(model,'n_estimators_',None),
            'warnings':[str(w.message) for w in caught],'prediction_sha256':sha(dest/'scores_BEFORE_label_merge.csv')})
        del model
        if args.device=='cuda':torch.cuda.empty_cache()
        print(mid,phase,fold,'COMPLETE',flush=True)
    frame_csv(pd.concat(scores,ignore_index=True),out/'predictions_BEFORE_label_merge.csv')
    dump(out/'run_receipt.json',{'status':'COMPLETE','model_fits':len(plans),'wall_seconds':time.perf_counter()-start,
        'seed':SEED,'device':args.device,'history_status':'PREVIOUSLY_INSPECTED','model_id':mid})

def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--prepared',type=Path,required=True);p.add_argument('--dataset',choices=['D1','D2'],required=True)
    p.add_argument('--variant',choices=list(VARIANTS),default='centered');p.add_argument('--phase',choices=['development','full'],default='development')
    p.add_argument('--checkpoint',type=Path);p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    p.add_argument('--output',type=Path,required=True);p.add_argument('--dry-run',action='store_true');return p

if __name__=='__main__':run(parser().parse_args())
