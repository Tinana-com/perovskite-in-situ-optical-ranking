"""Recompute manuscript5 ranking and fusion results from archived sample scores."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
from release_common import B,fresh_output,dump
from bar_rank.core import KEYS,fuse_scores,score_units,bootstrap

def read(path):return pd.read_csv(path,dtype={'split_group':str},float_precision='round_trip')

def baseline(dataset,phase):
    name={('D1','development'):'d1_train_oof_predictions.csv',('D1','historical'):'d1_author_test_predictions.csv',
          ('D2','development'):'d2_dev_oof_predictions.csv',('D2','historical'):'d2_history_predictions.csv'}[(dataset,phase)]
    frame=read(B/'reference_results/P6'/name)
    if dataset=='D1':
        name='d1_development_targets_full_precision.csv' if phase=='development' else 'd1_historical_targets_full_precision.csv'
        target=read(B/'reference_results/P6'/name)
        frame=frame.drop(columns=['target']).merge(target[['sample_id','raw_target']],on='sample_id',validate='one_to_one').rename(columns={'raw_target':'target'})
    return frame

def recompute(output):
    out=fresh_output(output);center=read(B/'reference_results/centered/scores_before_labels.csv')
    raw=read(B/'reference_results/raw_control/RAW_SCORES_BEFORE_LABELS.csv')
    part2=read(B/'reference_results/part2/predictions_WITH_scoring_targets.csv')
    macros=[];allunits=[];allgroups=[];contrasts=[];checks=[];saved_scores=[]
    expected=read(B/'reference_results/centered/model_summary.csv')
    raw_expected=read(B/'reference_results/raw_control/MODEL_SUMMARY.csv')
    joint_expected=read(B/'analysis/manuscript5/INPUTS/extensions/tabpfn_results_summary_part2.csv')
    for dataset in ['D1','D2']:
        for phase in ['development','historical']:
            original=baseline(dataset,phase);labels=original[KEYS+['target']]
            pair=original[KEYS+['PAIR_ABS']].rename(columns={'PAIR_ABS':'score'})
            ctr=center[(center.dataset==dataset)&(center.phase==phase)][KEYS+['score']]
            model_scores={'PAIR_ABS':pair,'TABPFN_CENTERED':ctr,'BAR_OPTICAL':fuse_scores(pair,ctr)[KEYS+['score']]}
            if dataset=='D2':
                rr=raw[raw.phase==phase][KEYS+['score']];model_scores['TABPFN_RAW']=rr
                jj=part2[(part2.phase==phase)&part2.method_id.eq('D2_TABPFN_CTR_IDPL44')][KEYS+['score']]
                model_scores['TABPFN_JOINT']=jj;model_scores['BAR_JOINT']=fuse_scores(pair,jj)[KEYS+['score']]
            groups_by_model={}
            for name,scores in model_scores.items():
                if set(scores.sample_id)!=set(labels.sample_id):raise ValueError('Archived predictor cohort differs')
                before=scores.copy();before['dataset']=dataset;before['phase']=phase;before['model_id']=name;saved_scores.append(before)
                scored=scores.merge(labels,on=KEYS,validate='one_to_one');units=score_units(scored)
                groups=units.groupby('split_group',sort=True)[['gain_pp','rho','overlap']].mean().reset_index()
                row={'dataset':dataset,'phase':phase,'model_id':name,'n_regions':len(scored),'n_units':len(units),'n_independent_groups':len(groups)}
                for metric in ['gain_pp','rho','overlap']:
                    value,lo,hi=bootstrap(groups[metric]);row.update({metric:value,metric+'_ci95_low':lo,metric+'_ci95_high':hi})
                macros.append(row);groups_by_model[name]=groups.set_index('split_group').gain_pp
                for frame,collection in [(units,allunits),(groups,allgroups)]:
                    frame=frame.copy();frame['dataset']=dataset;frame['phase']=phase;frame['model_id']=name;collection.append(frame)
                reference_id={'PAIR_ABS':'P6_PAIR_ABS','TABPFN_CENTERED':f'{dataset}_TABPFN_CTR_ABS12','BAR_OPTICAL':f'{dataset}_TABPFN_CTR_ABS12_BLEND50_PAIR_ABS'}.get(name)
                if reference_id:
                    target=expected[(expected.dataset==dataset)&(expected.phase==phase)&(expected.method_id==reference_id)].iloc[0]
                    error=abs(row['gain_pp']-float(target.top25_gain_pp));checks.append({'dataset':dataset,'phase':phase,'model_id':name,'gain_error':error,'pass':bool(error<1e-10)})
                elif name=='TABPFN_RAW':
                    target=raw_expected[(raw_expected.phase==phase)&raw_expected.model.eq('RAW')].iloc[0]
                    error=abs(row['gain_pp']-float(target.gain_pp));checks.append({'dataset':dataset,'phase':phase,'model_id':name,'gain_error':error,'pass':bool(error<1e-10)})
                elif name in ['TABPFN_JOINT','BAR_JOINT']:
                    reference_id='D2_TABPFN_CTR_IDPL44'+('_BLEND50_PAIR_ABS' if name=='BAR_JOINT' else '')
                    target=joint_expected[(joint_expected.phase==phase)&joint_expected.method_id.eq(reference_id)].iloc[0]
                    error=abs(row['gain_pp']-float(target.top25_gain_pp));checks.append({'dataset':dataset,'phase':phase,'model_id':name,'gain_error':error,'pass':bool(error<1e-9)})
            pairs=[('BAR_OPTICAL','PAIR_ABS')]
            if dataset=='D2':pairs += [('TABPFN_CENTERED','TABPFN_RAW'),('BAR_JOINT','PAIR_ABS')]
            for a,b in pairs:
                aa=groups_by_model[a];bb=groups_by_model[b]
                if set(aa.index)!=set(bb.index):raise ValueError('Unpaired evaluation groups')
                delta=(aa-bb).sort_index();mean,lo,hi=bootstrap(delta)
                contrasts.append({'dataset':dataset,'phase':phase,'contrast':a+' minus '+b,'delta_gain_pp':mean,
                    'ci95_low':lo,'ci95_high':hi,'improved_groups':int((delta>1e-12).sum()),
                    'worsened_groups':int((delta<-1e-12).sum()),'tied_groups':int((delta.abs()<=1e-12).sum())})
    for name,frame in [('macro_metrics',pd.DataFrame(macros)),('paired_deltas',pd.DataFrame(contrasts)),
                       ('unit_metrics',pd.concat(allunits,ignore_index=True)),('independent_group_metrics',pd.concat(allgroups,ignore_index=True)),
                       ('scores_BEFORE_label_merge',pd.concat(saved_scores,ignore_index=True))]:
        frame.to_csv(out/(name+'.csv'),index=False,float_format='%.17g',lineterminator='\n')
    dump(out/'reproduction_check.json',{'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL',
        'model_fits':0,'archived_mean_checks':checks,'resampling_unit':{'D1':'substrate','D2':'date after experiment means'},
        'bootstrap_draws':10000,'seed':20261019})
    if not all(x['pass'] for x in checks):raise AssertionError('Archived result mismatch')
    print('PASS:',len(checks),'archived mean checks; zero fits;',out)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=B/'outputs/manuscript5_results');recompute(p.parse_args().output)
