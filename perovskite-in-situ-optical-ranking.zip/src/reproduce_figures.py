"""Render manuscript5 plates from the original plot sources and archived CSVs."""
from pathlib import Path
import argparse,importlib.util,types,json
import pandas as pd
from release_common import B,fresh_output

def load(path,name,replace=()):
    source=path.read_text(encoding='utf-8')
    for old,new in replace:
        if old not in source:raise ValueError('Archived drawing source layout changed: '+old)
        source=source.replace(old,new)
    m=types.ModuleType(name);m.__file__=str(path);exec(compile(source,str(path),'exec'),m.__dict__);return m

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=B/'outputs/manuscript5_figures')
    p.add_argument('--set',choices=['latest','all'],default='all');args=p.parse_args();out=fresh_output(args.output)
    root=B/'analysis/manuscript5';(out/'MAIN').mkdir();(out/'SI').mkdir()
    import matplotlib.pyplot as plt
    records=[]
    def save(fig,name,folder='MAIN',close=True):
        dest=out/folder;dest.mkdir(exist_ok=True)
        for ext in ['pdf','svg','png']:
            fig.savefig(dest/f'{name}.{ext}',dpi=600)
        records.append({'figure':name,'folder':folder,'source':'archived plot CSVs','dpi':600})
        if close:plt.close(fig)
    current=load(root/'src/make_figures_v5.py','manuscript5')
    current.save=save
    for fn in ['figure1','figure2','figure3','figure_s2','figure_s10','figure_s11','graphical_abstract']:
        getattr(current,fn)()
    if args.set=='all':
        middle=load(root/'src/manuscript4_plates.py','retained_plates',[
            ('JOINT,JOINT_DATES=prepare_joint()','JOINT,JOINT_DATES=pd.DataFrame(),pd.DataFrame()')]);middle.save=save
        middle.figure5();middle.figure_s9()
        legacy=load(root/'src/original_legacy_figures.py','legacy',[
            ("B/'DATA/SUP/OUTPUT/source_code/make_figures.py'","B/'src/legacy_plates.py'"),
            ("S.DATA=B/'DATA/SUP/INPUT/DATA/CODEX'","S.DATA=B/'legacy_plot_data'")])
        def legacy_read(rel,**kwargs):
            if rel.startswith('DATA/CODE/ANALYSIS/'):
                name=rel.split('/')[-1];path=B/'paper_analysis/ANALYSIS'/name
                if not path.exists():path=root/'INPUTS/legacy'/name
            elif rel.startswith('DATA/CODE/SOURCE_DATA/'):
                path=B/'paper_analysis/SOURCE_DATA'/rel.split('DATA/CODE/SOURCE_DATA/')[1]
            elif rel.startswith('DATA/SUP/INPUT/DATA/CODEX/'):
                path=root/'legacy_plot_data'/rel.split('/')[-1]
            else:path=root/rel
            d=pd.read_csv(path,float_precision='round_trip',**kwargs);d['_row']=range(2,len(d)+2);d.attrs['source']=rel;return d
        legacy.read=legacy_read;legacy.save=save;legacy.S.save=save
        legacy.figure_s1();legacy.group_figure('development','FigureS3');legacy.group_figure('historical','FigureS4')
        legacy.figure_s5();legacy.figure_s6();legacy.figure_s7()
        old=load(root/'src/original_polish_figures.py','old_optical',[
            ("R2 = Path(r'D:\\论文\\PL\\manuscript2_polish_r2')","R2 = Path(__file__).resolve().parents[1]"),
            ("R1 = Path(r'D:\\论文\\PL\\figure1_redesign_r1')","R1 = R2 / 'INPUTS/workflow'"),
            ("ASSETS = Path(r'D:\\论文\\PL\\manuscript2_assets')","ASSETS = R2"),
            ("ASSETS / 'DATA/SUP/OUTPUT/source_code/make_figures.py'","ASSETS / 'src/legacy_plates.py'")])
        old.read_code=lambda name,**kw:pd.read_csv(root/'INPUTS/legacy'/name,float_precision='round_trip',**kw)
        old.read_sup=lambda name,**kw:pd.read_csv(root/'legacy_plot_data'/name,float_precision='round_trip',**kw)
        old.S.save=save;old.draw_figure4_r2()
        legacy.S.curves(legacy.S.read('CULLING_MACRO_MICRO.csv'),'kept_gain_pp',('kept_gain_pp_ci_low','kept_gain_pp_ci_high'),
            'micro_recall_low_pce',('micro_recall_CI_low','micro_recall_CI_high'),'FigureS8',True)
    (out/'figure_manifest.json').write_text(json.dumps({'model_fits':0,'figures':records,
        'note':'Figure1 and graphical abstract preserve the archived illustrative raster; replace it before an Elsevier submission.'},indent=2),encoding='utf-8')
    print('Rendered',len(records),'plates from saved data; zero fits')

if __name__=='__main__':main()
