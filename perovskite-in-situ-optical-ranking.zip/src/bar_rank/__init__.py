"""Batch-centered targets and fixed score fusion for regional ranking."""
__version__ = '2.0.0'
