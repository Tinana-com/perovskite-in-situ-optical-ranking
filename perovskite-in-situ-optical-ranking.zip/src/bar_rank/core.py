"""Optical representations, training-only centering and label-free score fusion."""
import numpy as np
import pandas as pd
from scipy.stats import norm, spearmanr

SEED = 20261019
KEYS = ['sample_id', 'unit_id', 'split_group', 'patchID']
CATEGORIES = [10*r+c for r in range(1, 9) for c in range(1, 5)]
VARIANTS = {'raw': ('ABS', False, False), 'centered': ('ABS', False, True),
            'joint': ('ABS', True, True), 'relative-slope': ('REL', False, True),
            'copula-slope': ('COPULA', False, True)}

def center_targets(training_labels):
    """Use only labels supplied by the outer training fold."""
    return (training_labels.target - training_labels.groupby('unit_id').target.transform('mean')).to_numpy(float)

def features(optical, columns, representation='ABS', include_position=False, floor=None):
    x = optical[columns].to_numpy(float)
    blocks = []
    if include_position:
        blocks.append((optical.patchID.to_numpy()[:, None] == np.asarray(CATEGORIES)[None, :]).astype(float))
    if representation == 'ABS':
        blocks.append(x)
    elif representation == 'REL':
        if floor is None:
            floor = np.maximum(1e-12, 0.01*np.median(np.abs(x), axis=0))
        med = optical.groupby('unit_id', sort=False)[columns].transform('median').to_numpy(float)
        mad = (optical[columns]-med).abs().groupby(optical.unit_id, sort=False).transform('median').to_numpy(float)
        blocks.append((x-med)/np.maximum(1.4826*mad, floor))
    elif representation == 'COPULA':
        block = np.zeros_like(x)
        for _, indices in optical.groupby('unit_id', sort=False).indices.items():
            indices = np.asarray(indices)
            for j in range(len(columns)):
                ranks = pd.Series(x[indices, j]).rank(method='average').to_numpy()
                block[indices, j] = norm.ppf(np.clip((ranks-0.375)/(len(indices)+0.25), 1e-4, 1-1e-4))
        blocks.append(block)
    else:
        raise ValueError('Unknown representation')
    result = np.column_stack(blocks)
    if not np.isfinite(result).all():
        raise ValueError('Nonfinite optical input')
    return result, floor

def fold_inputs(data, train_groups, evaluation_groups, variant):
    """Construct supervised X/y and target-free evaluation keys for one outer fold."""
    if set(train_groups) & set(evaluation_groups):
        raise ValueError('Training and evaluation groups overlap')
    if variant not in VARIANTS or (variant in ['joint','relative-slope','copula-slope'] and data.name != 'D2'):
        raise ValueError('Variant is not part of this dataset protocol')
    rep, position, centered = VARIANTS[variant]
    columns = list(data.spec['feature_names'])
    if rep != 'ABS':
        columns = [f'{c}_slope' for c in ['LP725','LP780','SP775','ND']]
    train_opt = data.optical(groups=train_groups)
    eval_opt = data.optical(groups=evaluation_groups)
    train = data.labels.loc[(data.labels.role == 'development') & data.labels.split_group.isin(train_groups)].sort_values(['split_group','unit_id','sample_id']).reset_index(drop=True)
    evaluation = data.y(evaluation_groups)[KEYS].sort_values(['split_group','unit_id','sample_id']).reset_index(drop=True)
    if set(train.split_group) != set(train_groups):
        raise ValueError('Every training group must have development supervision')
    tx, floor = features(train_opt, columns, rep, position)
    vx, _ = features(eval_opt, columns, rep, position, floor)
    x = pd.DataFrame(tx, index=train_opt.sample_id).loc[train.sample_id].to_numpy(float)
    v = pd.DataFrame(vx, index=eval_opt.sample_id).loc[evaluation.sample_id].to_numpy(float)
    y = center_targets(train) if centered else train.target.to_numpy(float)
    return x, y, v, evaluation, train, columns

def validate_scores(frame):
    if {'target','pce_mean','PCE_backward','y_true'} & set(frame):
        raise ValueError('Fusion accepts scores before label merge')
    if not set(KEYS+['score']) <= set(frame):
        raise ValueError('Missing score/identity columns')
    if frame.sample_id.duplicated().any() or not np.isfinite(frame.score).all():
        raise ValueError('Duplicate identity or nonfinite score')
    if frame.groupby('unit_id').split_group.nunique().gt(1).any():
        raise ValueError('Comparison unit spans independent groups')

def within_unit_z(frame, column):
    return frame.groupby('unit_id')[column].transform(lambda v:(v-v.mean())/max(float(v.std(ddof=0)),1e-12)).to_numpy(float)

def fuse_scores(pair_scores, auxiliary_scores):
    """Fixed 50/50 component-wise population-z fusion. No label or fitted weight."""
    validate_scores(pair_scores); validate_scores(auxiliary_scores)
    if set(pair_scores.sample_id) != set(auxiliary_scores.sample_id):
        raise ValueError('Fusion inputs use different sample cohorts')
    q = pair_scores[KEYS+['score']].rename(columns={'score':'pair_score'}).merge(
        auxiliary_scores[KEYS+['score']].rename(columns={'score':'auxiliary_score'}),on=KEYS,validate='one_to_one')
    if len(q) != len(pair_scores):
        raise ValueError('Fusion identity mismatch')
    q['pair_z'] = within_unit_z(q, 'pair_score')
    q['auxiliary_z'] = within_unit_z(q, 'auxiliary_score')
    q['score'] = 0.5*q.pair_z+0.5*q.auxiliary_z
    return q

def score_units(scored):
    rows = []
    for uid,g in scored.groupby('unit_id',sort=True):
        y=g.target.to_numpy(float);s=g.score.to_numpy(float);ids=g.sample_id.to_numpy(str)
        k=max(1,int(np.ceil(len(g)*0.25)));order=np.lexsort((ids,-s));truth=np.lexsort((ids,-y))
        rho=float(spearmanr(y,s).statistic) if np.unique(y).size>1 and np.unique(s).size>1 else np.nan
        rows.append({'unit_id':uid,'split_group':str(g.split_group.iloc[0]),'n_regions':len(g),
                     'gain_pp':float(y[order[:k]].mean()-y.mean()),'rho':rho,
                     'overlap':len(set(ids[order[:k]])&set(ids[truth[:k]]))/k})
    return pd.DataFrame(rows)

def bootstrap(values):
    v=np.asarray(values,float);v=v[np.isfinite(v)]
    if not len(v):return np.nan,np.nan,np.nan
    b=np.random.default_rng(SEED).choice(v,(10000,len(v)),replace=True).mean(axis=1)
    lo,hi=np.quantile(b,[0.025,0.975]);return float(v.mean()),float(lo),float(hi)
