# Data availability

D1: Laufer and coauthors, In Situ Photoluminescence Imaging Dataset of Blade-Coated Perovskite Photovoltaics, Zenodo, https://doi.org/10.5281/zenodo.7503391.

D2: Laufer, Götz and Paetzold, In Situ Photoluminescence Dataset for Exploring Material and Processing Variabilities in Blade-Coated Perovskite Photovoltaics, Zenodo, https://doi.org/10.5281/zenodo.14609789.

The original records define the data terms and attribution. This package contains derived prediction/evaluation tables, identities, frozen configurations and measured D1 trajectory excerpts needed for the paper figures. It excludes the original large H5/image collections and all borrowed publication images. MIT covers code, not the underlying public datasets. Refer to the original records for data reuse terms.

D1 targets are mean forward/backward PCE; D2 targets are backward-sweep PCE. D1 uses LP725; D2 uses LP725, LP780, SP775 and ND reflection. Separate models and evaluation structures are retained. These inputs do not constitute a common full optical spectrum.
