# GitHub upload

Suggested repository name: in-situ-optical-regional-ranking.

Upload the CONTENTS of this ZIP as the repository root. It includes training entrypoints, original sources, fixed settings, licenses, tests and the prior paper-analysis layer. Do not upload local outputs/, AUDIT/, raw H5 data, caches or virtual environments; these are excluded from the release ZIP.

Create the repository in your own GitHub account and upload the root files/directories. Retain LICENSE, THIRD_PARTY_NOTICES.md, README and SHA256_MANIFEST.json. Verify the published tree and create a v1.0 code release. Once a real URL exists, insert that verified URL into the manuscript Code Availability Statement.

No remote GitHub repository has been created by this session. The repository-ready package is complete, while full new training replay is marked NOT_RUN. Do not describe the release checks as a new scientific validation run.
