# Licenses and attribution

The complete training distribution is released under GPL-3.0; LICENSE contains the full text. MiniRocket by Angus Dempster, Daniel F. Schmidt and Geoffrey I. Webb is included byte-for-byte under frozen_sources/P9/sources/minirocket with its original GPLv3 LICENSE, README and source-provenance commit. Its algorithms were not rewritten.

The separately supplied paper_analysis component retains its MIT LICENSE and author notice. Scientific Python dependencies retain their own licenses and are installed separately. Dataset-derived tables and real test excerpts retain attribution to the two CC BY4.0 KIT Zenodo records. They are not covered by a claim of exclusive ownership of the original experimental data. No borrowed publication images are included.
